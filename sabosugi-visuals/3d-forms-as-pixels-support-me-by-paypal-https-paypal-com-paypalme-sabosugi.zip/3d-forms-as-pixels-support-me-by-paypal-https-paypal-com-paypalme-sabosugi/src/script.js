        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import GUI from 'lil-gui';

        // --- Core Variables ---
        let scene, camera, renderer, controls;
        let ambientLight, dirLight, backLight;
        let instancedMesh;
        let currentImage = null;
        let imgData = null;
        let gridW = 0, gridH = 0;
        let positions = []; // Store base positions of instances
        const dummy = new THREE.Object3D();
        const clock = new THREE.Clock();

        // --- Configuration / GUI Parameters ---
        const params = {
            uploadImage: () => document.getElementById('fileInput').click(),
            imageUrl: 'https://ik.imagekit.io/sqiqig7tz/loonyleo._a_photography_of_a_pop_trio_-_two_men_and_a_woman_of__8ff7a6ab-2dd2-4f7a-857b-f29019e4820a.png',
            loadImageFromUrl: () => handleImageSource(params.imageUrl),
            resolution: 60, // Maximum grid size
            shape: 'Cube',
            shapeScale: 0.75, // Pixel shape size
            rotationSpeed: 0.5,
            bgColor: '#111111',
            // Lighting parameters
            ambientIntensity: 0.8,
            ambientColor: '#ffffff',
            dirIntensity: 0.75,
            dirColor: '#ffffff',
            backIntensity: 0.3,
            backColor: '#545454'
        };

        // --- Geometries Dictionary ---
        // Setup predefined geometries
        const geometries = {};
        
        // 1. Cube
        geometries['Cube'] = new THREE.BoxGeometry(1, 1, 1);
        
        // 2. Pyramid
        const pyramidGeo = new THREE.CylinderGeometry(0, 0.7, 1, 4);
        pyramidGeo.rotateY(Math.PI / 4); // Align faces
        geometries['Pyramid'] = pyramidGeo;
        
        // 3. Vertical 3D Hexagon
        geometries['Hexagon'] = new THREE.CylinderGeometry(0.6, 0.6, 1, 6);
        
        // 4. Octahedron
        geometries['Octahedron'] = new THREE.OctahedronGeometry(0.7);
        
        // 5. Ring
        geometries['Ring'] = new THREE.TorusGeometry(0.5, 0.2, 16, 32);
        
        // 6. Diamond (stretched octahedron)
        const diamondGeo = new THREE.OctahedronGeometry(0.5);
        diamondGeo.scale(1, 2, 1); // Make it taller on the Y axis
        geometries['Diamond'] = diamondGeo;

        // Shared material
        const material = new THREE.MeshStandardMaterial({
            roughness: 0.3,
            metalness: 0.2
        });

        // --- Initialization ---
        init();
        handleImageSource(params.imageUrl); // Load the URL image at startup instead of the default pattern
        setupGUI();
        setupDragAndDrop();
        animate();

        function init() {
            const container = document.getElementById('canvas-container');

            // Scene setup
            scene = new THREE.Scene();
            scene.background = new THREE.Color(params.bgColor);

            // Camera setup
            camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 0, 75); // Moved back slightly from 60

            // Renderer setup
            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            container.appendChild(renderer.domElement);

            // Camera controls (orbital)
            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;

            // Lighting
            ambientLight = new THREE.AmbientLight(params.ambientColor, params.ambientIntensity);
            scene.add(ambientLight);

            dirLight = new THREE.DirectionalLight(params.dirColor, params.dirIntensity);
            dirLight.position.set(20, 20, 30);
            scene.add(dirLight);
            
            backLight = new THREE.DirectionalLight(params.backColor, params.backIntensity);
            backLight.position.set(-20, -20, -30);
            scene.add(backLight);

            // Window resize handler
            window.addEventListener('resize', onWindowResize);
            
            // File selection handler
            document.getElementById('fileInput').addEventListener('change', handleFileUpload);
        }

        function setupGUI() {
            const gui = new GUI({ title: 'Effect Settings' });

            const fileFolder = gui.addFolder('Image Loading');
            fileFolder.add(params, 'uploadImage').name('Upload Local Image');
            fileFolder.add(params, 'imageUrl').name('Image URL');
            fileFolder.add(params, 'loadImageFromUrl').name('Load from URL');
            fileFolder.add(params, 'resolution', 10, 150, 1).name('Grid Resolution').onChange(rebuildGrid);

            const shapeFolder = gui.addFolder('Shape Properties');
            shapeFolder.add(params, 'shape', ['Cube', 'Pyramid', 'Hexagon', 'Octahedron', 'Ring', 'Diamond'])
                       .name('Shape Type').onChange(rebuildGrid);
            shapeFolder.add(params, 'shapeScale', 0.1, 2.0, 0.05).name('Shape Size');
            shapeFolder.add(params, 'rotationSpeed', 0.0, 2.0, 0.1).name('Rotation Speed');

            const colorFolder = gui.addFolder('Colors');
            colorFolder.addColor(params, 'bgColor').name('Background').onChange(v => scene.background.set(v));

            const lightFolder = gui.addFolder('Lighting');
            lightFolder.add(params, 'ambientIntensity', 0, 3, 0.1).name('Ambient Intensity').onChange(v => ambientLight.intensity = v);
            lightFolder.addColor(params, 'ambientColor').name('Ambient Color').onChange(v => ambientLight.color.set(v));
            lightFolder.add(params, 'dirIntensity', 0, 1, 0.01).name('Main Light Intensity').onChange(v => dirLight.intensity = v);
            lightFolder.addColor(params, 'dirColor').name('Main Light Color').onChange(v => dirLight.color.set(v));
            lightFolder.add(params, 'backIntensity', 0, 1, 0.01).name('Back Light Intensity').onChange(v => backLight.intensity = v);
            lightFolder.addColor(params, 'backColor').name('Back Light Color').onChange(v => backLight.color.set(v));
        }

        // --- Core Logic: Image and Grid Processing ---
        function rebuildGrid() {
            if (!currentImage) return;

            // 1. Calculate grid dimensions preserving proportions
            const maxRes = params.resolution;
            const aspect = currentImage.width / currentImage.height;

            if (currentImage.width > currentImage.height) {
                gridW = maxRes;
                gridH = Math.floor(maxRes / aspect);
            } else {
                gridH = maxRes;
                gridW = Math.floor(maxRes * aspect);
            }

            // 2. Draw image on hidden canvas to extract pixels
            const canvas = document.createElement('canvas');
            canvas.width = gridW;
            canvas.height = gridH;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(currentImage, 0, 0, gridW, gridH);
            imgData = ctx.getImageData(0, 0, gridW, gridH).data;

            // 3. Clear existing InstancedMesh
            if (instancedMesh) {
                scene.remove(instancedMesh);
                instancedMesh.dispose();
            }

            // 4. Create new InstancedMesh
            const instanceCount = gridW * gridH;
            const geo = geometries[params.shape];
            instancedMesh = new THREE.InstancedMesh(geo, material, instanceCount);
            
            // 5. Calculate offset to center the grid
            const cellSize = 1.0;
            const offsetX = (gridW * cellSize) / 2 - (cellSize / 2);
            const offsetY = (gridH * cellSize) / 2 - (cellSize / 2);

            positions = [];
            let idx = 0;

            for (let y = 0; y < gridH; y++) {
                for (let x = 0; x < gridW; x++) {
                    // Position mapping: WebGL Y is up, Canvas Y is down
                    const posX = x * cellSize - offsetX;
                    const posY = -(y * cellSize - offsetY);
                    
                    positions.push(new THREE.Vector3(posX, posY, 0));
                    
                    // Initial transformations (rotation and scale are updated in the animation loop)
                    dummy.position.set(posX, posY, 0);
                    dummy.updateMatrix();
                    instancedMesh.setMatrixAt(idx, dummy.matrix);
                    
                    idx++;
                }
            }

            scene.add(instancedMesh);
            
            // 6. Apply colors and setup camera
            updateColors();
            
            const maxDim = Math.max(gridW, gridH);
            camera.position.z = maxDim * 1.15; // Increased from 0.9 to 1.15 to move the camera back a bit
        }

        // --- Update Colors ---
        function updateColors() {
            if (!instancedMesh || !imgData) return;
            
            let idx = 0;
            const tempColor = new THREE.Color();

            for (let y = 0; y < gridH; y++) {
                for (let x = 0; x < gridW; x++) {
                    // Extract pixel colors from image data
                    const pixelIndex = (y * gridW + x) * 4;
                    const r = imgData[pixelIndex] / 255;
                    const g = imgData[pixelIndex + 1] / 255;
                    const b = imgData[pixelIndex + 2] / 255;
                    
                    // Set color and convert from sRGB to Linear 
                    // for correct rendering in Three.js 0.160+
                    tempColor.setRGB(r, g, b);
                    tempColor.convertSRGBToLinear();
                    
                    instancedMesh.setColorAt(idx, tempColor);
                    idx++;
                }
            }
            // Notify Three.js about color changes
            instancedMesh.instanceColor.needsUpdate = true;
        }

        // --- Animation Loop ---
        function animate() {
            requestAnimationFrame(animate);

            const time = clock.getElapsedTime();

            // Update rotation for all instances
            if (instancedMesh && positions.length > 0) {
                for (let i = 0; i < positions.length; i++) {
                    dummy.position.copy(positions[i]);
                    
                    // Rotate shapes based on time
                    // Add a slight offset by index 'i' to make rotation look organic
                    dummy.rotation.x = time * params.rotationSpeed + i * 0.001;
                    dummy.rotation.y = time * params.rotationSpeed + i * 0.002;
                    dummy.rotation.z = time * (params.rotationSpeed * 0.5);
                    
                    // Apply dynamic scale
                    dummy.scale.setScalar(params.shapeScale);
                    
                    dummy.updateMatrix();
                    instancedMesh.setMatrixAt(i, dummy.matrix);
                }
                // Notify Three.js about transformation matrix changes
                instancedMesh.instanceMatrix.needsUpdate = true;
            }

            controls.update();
            renderer.render(scene, camera);
        }

        // --- Event Handlers and Utilities ---
        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }

        function handleImageSource(src) {
            const img = new Image();
            img.crossOrigin = "Anonymous"; // Required to read pixel data from external URLs (CORS)
            img.onload = () => {
                currentImage = img;
                rebuildGrid();
            };
            img.onerror = () => {
                console.error("Failed to load image. CORS policy might be blocking it.");
            };
            img.src = src;
        }

        function handleFileUpload(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => handleImageSource(event.target.result);
                reader.readAsDataURL(file);
            }
        }

        function setupDragAndDrop() {
            const overlay = document.getElementById('dragOverlay');
            
            window.addEventListener('dragover', (e) => {
                e.preventDefault();
                overlay.classList.add('active');
            });
            
            window.addEventListener('dragleave', (e) => {
                e.preventDefault();
                if(e.relatedTarget === null) overlay.classList.remove('active');
            });
            
            window.addEventListener('drop', (e) => {
                e.preventDefault();
                overlay.classList.remove('active');
                
                if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    const file = e.dataTransfer.files[0];
                    if (file.type.startsWith('image/')) {
                        const reader = new FileReader();
                        reader.onload = (event) => handleImageSource(event.target.result);
                        reader.readAsDataURL(file);
                    }
                }
            });
        }

        // Generate default color pattern on load
        function createDefaultImage() {
            const canvas = document.createElement('canvas');
            canvas.width = 512;
            canvas.height = 512;
            const ctx = canvas.getContext('2d');
            
            // Background gradient
            const gradient = ctx.createLinearGradient(0, 0, 512, 512);
            gradient.addColorStop(0, '#ff2a5f');
            gradient.addColorStop(0.5, '#00d0ff');
            gradient.addColorStop(1, '#ffc800');
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, 512, 512);

            // Central circle
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(256, 256, 120, 0, Math.PI * 2);
            ctx.fill();

            // Text
            ctx.fillStyle = '#111111';
            ctx.font = 'bold 40px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('THREE.JS', 256, 240);
            ctx.fillText('PIXELS', 256, 290);

            handleImageSource(canvas.toDataURL());
        }