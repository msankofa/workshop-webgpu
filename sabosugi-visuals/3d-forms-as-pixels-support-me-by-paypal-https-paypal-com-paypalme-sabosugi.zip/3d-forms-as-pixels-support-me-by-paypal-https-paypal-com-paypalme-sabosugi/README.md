# 3D Forms as Pixels  – Support me by PayPal: https://paypal.com/paypalme/sabosugi

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/JoRpVeO](https://codepen.io/sabosugi/pen/JoRpVeO).

