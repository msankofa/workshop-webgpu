        import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- Application State & Parameters ---
        const params = {
            // Colors
            color1: '#6619cc', // Purple
            color2: '#e63380', // Pink
            color3: '#1accff', // Cyan
            
            // Animation
            speed: 0.062,
            
            // Deformation / Geometry
            angleCos: -2.57,
            angleSin: 1.73,
            
            // Magnetic Poles Deformation
            pole1Radius: -0.97,
            pole1Wave: -0.366,
            pole2Radius: 2.71,
            pole2Wave: 0.156,
            baseWaveAmplitude: 1.24,
            
            // Lines
            frequency: 19.05,
            thickness: 0.4842,
            power: 0.4921,
            
            // Effects
            holoIntensity: 2.0,
            
            // Renderer
            dpr: 1.0,
            aaLevel: 2 // Anti-Aliasing samples (1 = Off, 2 = 2x2, 3 = 3x3)
        };

        // --- Three.js Setup ---
        const canvas = document.createElement('canvas');
        document.body.appendChild(canvas);

        const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
        renderer.setPixelRatio(params.dpr);
        renderer.setSize(window.innerWidth, window.innerHeight);

        const scene = new THREE.Scene();

        // Use Orthographic camera for full-screen 2D shader rendering
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

        // --- Shader Material ---
        const uniforms = {
            u_time: { value: 0.0 },
            u_resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            u_color1: { value: new THREE.Color(params.color1) },
            u_color2: { value: new THREE.Color(params.color2) },
            u_color3: { value: new THREE.Color(params.color3) },
            u_speed: { value: params.speed },
            u_angleCos: { value: params.angleCos },
            u_angleSin: { value: params.angleSin },
            u_pole1Radius: { value: params.pole1Radius },
            u_pole1Wave: { value: params.pole1Wave },
            u_pole2Radius: { value: params.pole2Radius },
            u_pole2Wave: { value: params.pole2Wave },
            u_baseWaveAmplitude: { value: params.baseWaveAmplitude },
            u_freq: { value: params.frequency },
            u_thick: { value: params.thickness },
            u_power: { value: params.power },
            u_holoIntensity: { value: params.holoIntensity }
        };

        const vertexShader = `
            void main() {
                // Pass standard position for full screen quad
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform float u_time;
            uniform vec2 u_resolution;
            
            uniform vec3 u_color1;
            uniform vec3 u_color2;
            uniform vec3 u_color3;
            
            uniform float u_speed;
            uniform float u_angleCos;
            uniform float u_angleSin;
            
            uniform float u_pole1Radius;
            uniform float u_pole1Wave;
            uniform float u_pole2Radius;
            uniform float u_pole2Wave;
            uniform float u_baseWaveAmplitude;
            
            uniform float u_freq;
            uniform float u_thick;
            uniform float u_power;
            
            uniform float u_holoIntensity;

            // Define default Anti-Aliasing level if not injected by material
            #ifndef AA
            #define AA 2
            #endif

            // 1. Helper function to create a smooth 3-color gradient
            vec3 getGradient(float t) {
                t = clamp(t, 0.0, 1.0); 
                
                vec3 blend1 = mix(u_color1, u_color2, smoothstep(0.0, 0.5, t));
                vec3 blend2 = mix(u_color2, u_color3, smoothstep(0.5, 1.0, t));
                
                return mix(blend1, blend2, step(0.5, t));
            }

            // 2. CENTRALIZED DOMAIN WARPING ("Magnetic Poles" Edition)
            vec2 getWarpedDomain(vec2 p) {
                float t = u_time * u_speed;
                
                // Base diagonal rotation based on uniforms
                float c = cos(u_angleCos), s = sin(u_angleSin);
                p *= mat2(c, -s, s, c);
                
                // Pole 1: Moving focal point
                vec2 pole1 = vec2(sin(t * -2.1), cos(t * 0.4)) * u_pole1Radius;
                float d1 = sqrt(dot(p - pole1, p - pole1) + 1.0); 
                p.y += sin(d1 * 2.4 - t * 3.0) * u_pole1Wave;

                // Pole 2: Opposing moving focal point
                vec2 pole2 = vec2(cos(t * 0.7), -sin(t * 1.1)) * u_pole2Radius;
                float d2 = sqrt(dot(p - pole2, p - pole2) + 1.0);
                p.x += cos(d2 * 2.0 + t * 1.2) * u_pole2Wave;

                // A broad, gentle wave to keep the global diagonal flow unified
                p.y += sin(p.x * 1.5 + t * -2.0) * u_baseWaveAmplitude;
                
                return p;
            }

            // 3. Geometry / Heightmap Definition
            float map(vec2 p) {
                vec2 warpedP = getWarpedDomain(p);

                // --- LINE SHAPING ---
                float wave = sin(warpedP.y * u_freq); 
                
                float normalizedWave = wave * u_thick + 0.5;
                // clamp used to prevent NaN in pow() on some GPUs
                float height = pow(clamp(normalizedWave, 0.0, 1.0), u_power); 
                
                return height * 0.25; 
            }

            // 4. Normal Calculation
            vec3 getNormal(vec2 p) {
                vec2 e = vec2(0.01, 0.0);
                float h = map(p);
                
                return normalize(vec3(
                    map(p + e.xy) - h,
                    map(p + e.yx) - h,
                    0.017
                ));
            }

            // Encapsulate the entire scene rendering for a single sub-pixel
            vec3 getSceneColor(vec2 fragCoord) {
                vec2 uv = (fragCoord * 3.6 - u_resolution.xy) / u_resolution.y;
                
                vec3 n = getNormal(uv);
                
                // GET SYNCED LINE ID FOR HOLOGRAPHIC SHIFT
                vec2 warpedP = getWarpedDomain(uv);
                
                // Sync the ID using the exact uniform frequency
                float lineID = floor((warpedP.y * (u_freq * 0.934)) / 7.1931853);
                
                vec2 rotP = uv * mat2(cos(0.0), -sin(0.4), sin(0.7), cos(1.3));
                float gradPos = rotP.y * 0.35 + 0.3; 

                // Lighting Setup
                vec3 viewDir = normalize(vec3(0.0, 0.0, 1.0)); 
                vec3 lightDir1 = normalize(vec3(0.4, 0.7, 0.6)); 
                vec3 lightDir2 = normalize(vec3(-0.6, -0.4, 0.3)); 
                
                // Color Palettes
                vec3 baseColor = getGradient(gradPos);

                // Internal Gradients & Shading
                float internalGrad = smoothstep(-0.6, 1.0, n.y + n.x * 0.3);
                vec3 lineVolumeColor = mix(baseColor * 0.2, baseColor, internalGrad);

                float diff1 = max(dot(n, lightDir1), 0.0);
                float diff2 = max(dot(n, lightDir2), 0.0);
                
                vec3 refDir1 = reflect(-lightDir1, n);
                float spec1 = pow(max(dot(viewDir, refDir1), 0.0), 40.0) * 1.5;

                // SYNCED HOLOGRAPHIC EDGES
                float fresnel = pow(1.0 - max(dot(n, viewDir), 0.0), 2.4);
                
                vec3 holographicSpectrum = 0.5 + 0.5 * cos(u_time + warpedP.x * 3.0 + lineID * 1.2 + vec3(0.0, 2.0, 4.0));

                // Composition for this sample
                vec3 color = lineVolumeColor * (diff1 * 0.8 + 0.1); 
                color += baseColor * diff2 * 0.3; 
                color += vec3(1.0, 0.95, 1.0) * spec1; 
                color += holographicSpectrum * fresnel * u_holoIntensity;
                
                return color;
            }

            void main() {
                vec3 totalColor = vec3(0.0);
                
                // SSAA (Super Sample Anti-Aliasing) Loop
                for(int y = 0; y < AA; y++) {
                    for(int x = 0; x < AA; x++) {
                        // Calculate sub-pixel offset
                        vec2 offset = (vec2(float(x), float(y)) + 0.5) / float(AA) - 0.5;
                        totalColor += getSceneColor(gl_FragCoord.xy + offset);
                    }
                }
                
                // Average the multi-sampled colors
                totalColor /= float(AA * AA);

                // Smooth contrast / Gamma correction is applied AFTER averaging linear colors
                totalColor = pow(totalColor, vec3(0.85)); 

                gl_FragColor = vec4(totalColor, 1.0);
            }
        `;

        const material = new THREE.ShaderMaterial({
            vertexShader: vertexShader,
            fragmentShader: fragmentShader,
            uniforms: uniforms,
            defines: {
                AA: params.aaLevel // Inject Anti-Aliasing level
            }
        });

        // Full screen quad
        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- lil-gui Setup ---
        const gui = new GUI({ title: 'Shader Settings' });
        
        // Colors Folder
        const colorFolder = gui.addFolder('Gradient Colors');
        colorFolder.addColor(params, 'color1').name('Color 1 (Top)').onChange(val => uniforms.u_color1.value.set(val));
        colorFolder.addColor(params, 'color2').name('Color 2 (Mid)').onChange(val => uniforms.u_color2.value.set(val));
        colorFolder.addColor(params, 'color3').name('Color 3 (Bot)').onChange(val => uniforms.u_color3.value.set(val));
        
        // Animation Folder
        const animFolder = gui.addFolder('Animation');
        animFolder.add(params, 'speed', -0.5, 0.5).name('Flow Speed').onChange(val => uniforms.u_speed.value = val);
        
        // Geometry Folder
        const geoFolder = gui.addFolder('Deformation & Rotation');
        geoFolder.add(params, 'angleCos', -5.0, 5.0).name('Angle Cosine').onChange(val => uniforms.u_angleCos.value = val);
        geoFolder.add(params, 'angleSin', -5.0, 5.0).name('Angle Sine').onChange(val => uniforms.u_angleSin.value = val);
        
        // Magnetic Poles Folder
        const polesFolder = gui.addFolder('Magnetic Poles');
        polesFolder.add(params, 'pole1Radius', -5.0, 5.0).name('Pole 1 Radius').onChange(val => uniforms.u_pole1Radius.value = val);
        polesFolder.add(params, 'pole1Wave', -3.0, 3.0).name('Pole 1 Wave Amp').onChange(val => uniforms.u_pole1Wave.value = val);
        polesFolder.add(params, 'pole2Radius', -5.0, 5.0).name('Pole 2 Radius').onChange(val => uniforms.u_pole2Radius.value = val);
        polesFolder.add(params, 'pole2Wave', -3.0, 3.0).name('Pole 2 Wave Amp').onChange(val => uniforms.u_pole2Wave.value = val);
        polesFolder.add(params, 'baseWaveAmplitude', -5.0, 5.0).name('Base Wave Amp').onChange(val => uniforms.u_baseWaveAmplitude.value = val);
        
        // Lines Folder
        const linesFolder = gui.addFolder('Lines / Blinds');
        linesFolder.add(params, 'frequency', 5.0, 30.0).name('Frequency').onChange(val => uniforms.u_freq.value = val);
        linesFolder.add(params, 'thickness', 0.1, 1.0).name('Thickness').onChange(val => uniforms.u_thick.value = val);
        linesFolder.add(params, 'power', 0.1, 2.0).name('Sharpness (Power)').onChange(val => uniforms.u_power.value = val);
        
        // Effects Folder
        const effectsFolder = gui.addFolder('Effects');
        effectsFolder.add(params, 'holoIntensity', 0.0, 5.0).name('Holo Intensity').onChange(val => uniforms.u_holoIntensity.value = val);

        // Render Folder (Added AA setting)
        const renderFolder = gui.addFolder('Render Quality');
        renderFolder.add(params, 'aaLevel', { 'Off (1x)': 1, 'Good (2x2)': 2, 'High (3x3)': 3, 'Ultra (4x4)': 4 })
            .name('Anti-Aliasing')
            .onChange(val => {
                // Update material define and recompile
                material.defines.AA = parseInt(val);
                material.needsUpdate = true;
            });
            
        renderFolder.add(params, 'dpr', [0.5, 1, 1.5, 2]).name('Pixel Ratio (DPR)').onChange(val => {
            renderer.setPixelRatio(parseFloat(val));
        });

        // Close GUI by default as requested
        gui.close();

        // --- Resize Handler ---
        window.addEventListener('resize', () => {
            const width = window.innerWidth;
            const height = window.innerHeight;
            
            renderer.setSize(width, height);
            uniforms.u_resolution.value.set(width, height);
        });

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            // Update time uniform for the shader
            uniforms.u_time.value = clock.getElapsedTime();
            
            renderer.render(scene, camera);
        }

        animate();