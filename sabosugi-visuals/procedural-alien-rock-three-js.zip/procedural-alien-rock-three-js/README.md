# Procedural Alien Rock – Three.js

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/XJKPvyg](https://codepen.io/sabosugi/pen/XJKPvyg).

