        // Setup basic Three.js scene
        const scene = new THREE.Scene();
        
        // Use an orthographic camera for a full-screen shader quad
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        
        const renderer = new THREE.WebGLRenderer({ antialias: false });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // GUI Parameters state
        const params = {
            dpr: 0.4,
            speed: 1.5,
            glowIntensity: 15.8,
            exposure: 256.5,
            voxelResolution: 55.0,
            
            // Color phases (these act as offsets for the procedural sine wave colors)
            color1R: 0.1, color1G: 2.0, color1B: 4.0,
            color2R: 0.0, color2G: 1.0, color2B: 2.0,
            
            // Space folding rotation axes (dictates the fractal shape)
            foldingX: 3.145, foldingY: 1.79, foldingZ: 7.81
        };

        // Apply initial DPR
        const initialDPR = window.devicePixelRatio * params.dpr;
        renderer.setPixelRatio(initialDPR);

        // Shader Uniforms
        const uniforms = {
            iTime: { value: 0.0 },
            iResolution: { value: new THREE.Vector2(window.innerWidth * initialDPR, window.innerHeight * initialDPR) },
            u_speed: { value: params.speed },
            u_glowIntensity: { value: params.glowIntensity },
            u_exposure: { value: params.exposure },
            u_voxelResolution: { value: params.voxelResolution },
            u_colorPhasePrimary: { value: new THREE.Vector3(params.color1R, params.color1G, params.color1B) },
            u_colorPhaseSecondary: { value: new THREE.Vector3(params.color2R, params.color2G, params.color2B) },
            u_foldingAxis: { value: new THREE.Vector3(params.foldingX, params.foldingY, params.foldingZ) }
        };

        // Vertex Shader (Simple full-screen quad)
        const vertexShader = `
            void main() {
                gl_Position = vec4(position, 1.0);
            }
        `;

        // Fragment Shader (Adapted from Shadertoy optimized code)
        const fragmentShader = `
            // Uniforms passed from Three.js
            uniform float iTime;
            uniform vec2 iResolution;
            uniform float u_speed;
            uniform float u_glowIntensity;
            uniform float u_exposure;
            uniform float u_voxelResolution;
            uniform vec3 u_colorPhasePrimary;
            uniform vec3 u_colorPhaseSecondary;
            uniform vec3 u_foldingAxis;

            // Rendering constants
            #define MAX_RAY_STEPS 110
            #define STEP_MULTIPLIER 0.23

            // Polyfill for tanh just in case WebGL1 is used
            vec3 custom_tanh(vec3 x) {
                vec3 e = exp(2.0 * x);
                return (e - 1.0) / (e + 1.0);
            }

            // Helper: Reflects the space around a specific axis
            vec3 applySpaceReflection(vec3 position, vec3 axis) {
                return 36.4 * dot(axis, position) * axis - position;
            }

            // Helper: Generates procedural turbulence
            // OPTIMIZATION: Switched division to multiplication for better GPU performance
            vec3 calculateDisplacement(vec3 pos, float scale) {
                return (1.1 / scale) * sin(pos.zxy * scale + 3.0 * scale);
            }

            void main() {
                // Normalize coordinates
                vec2 uv = (gl_FragCoord.xy * 2.0 - iResolution.xy) / iResolution.y;

                // Setup ray for infinite straight tunnel 
                vec3 rayOrigin = vec3(0.0, 0.0, iTime * u_speed);
                vec3 rayDir = normalize(vec3(uv, 1.0)); 

                vec3 foldingAxis = normalize(tan(u_foldingAxis));

                float traveledDistance = 0.5;
                vec3 accumulatedColor = vec3(0.0);
                
                // --- OPTIMIZATIONS: PRECOMPUTED VARIABLES ---
                
                // 1. Calculate time-dependent rotation matrix ONCE instead of per-step
                float tRot = iTime * 0.3;
                mat2 timeRotation = mat2(cos(tRot), cos(tRot + 8.0), cos(tRot + 30.0), cos(tRot));
                
                // 2. Calculate base core emission animation ONCE
                vec3 precomputedCoreAnim = u_glowIntensity * exp(sin(iTime * 2.0 + u_colorPhaseSecondary));

                // 3. Setup incremental phase for primary emission (faster than multiplication inside loop)
                vec3 currentPhase = u_colorPhasePrimary;

                // Main Raymarching Loop
                for (int stepIndex = 0; stepIndex < MAX_RAY_STEPS; stepIndex++) {
                    vec3 currentPos = rayOrigin + rayDir * traveledDistance;

                    // 1. Base Tunnel Geometry 
                    float tunnelDist = max(abs(currentPos.x), abs(currentPos.y)) - 3.3;

                    // 2. Fractal Space Folding for Textures
                    vec3 fractalPos = currentPos;

                    // Seamlessly fold space along Z 
                    fractalPos.z = abs(mod(fractalPos.z, 7.0) - 3.5);
                    fractalPos = applySpaceReflection(fractalPos, foldingAxis);
                    
                    // Logarithmic space warp
                    fractalPos = log(abs(fractalPos) + 1.03);

                    // Voxel grid quantization
                    fractalPos = ceil(fractalPos * u_voxelResolution) / u_voxelResolution;

                    // --- OPTIMIZATION: Level of Detail (LOD) ---
                    // Drastically reduce fractal iterations for distant points to save GPU
                    float maxIter = 21.0 - clamp(traveledDistance * 0.7, 0.0, 16.0);

                    // Turbulence iterations
                    for (float iter = 2.0; iter <= 20.9; iter += 1.6) {
                        if (iter > maxIter) break; // Early exit for distant geometry
                        fractalPos += calculateDisplacement(fractalPos, iter);
                    }
                    
                    // Rotate the noise using PRECOMPUTED matrix
                    fractalPos.yz *= timeRotation;
                    fractalPos += calculateDisplacement(fractalPos, 1.0);

                    // 3. Volumetric Density
                    float localDensity = abs(tunnelDist) + abs(fractalPos.x) * 0.15 + 0.04;

                    // 4. Lighting Accumulation
                    // Walls emission (OPTIMIZED: incremental phase vector addition)
                    vec3 primaryEmission = exp(sin(currentPhase)) / localDensity;
                    currentPhase += 0.2; // Advance phase for the next step

                    // Center light ray emission (optimized distance calculation using dot product)
                    float sqDistToCenter = dot(currentPos.xy, currentPos.xy);
                    vec3 coreEmission = precomputedCoreAnim / (sqDistToCenter + 1.5);

                    accumulatedColor += primaryEmission * 0.5 + coreEmission * 0.05;

                    // Advance ray
                    traveledDistance += localDensity * STEP_MULTIPLIER;

                    // OPTIMIZATION: Early Ray Termination & Max Distance Cutoff
                    // Stop if pixel is fully saturated or ray flew too deep into the tunnel
                    if (traveledDistance > 45.0 || max(accumulatedColor.x, max(accumulatedColor.y, accumulatedColor.z)) > 1000.0) {
                        break;
                    }
                }

                // Tone mapping
                gl_FragColor = vec4(custom_tanh(accumulatedColor / u_exposure), 1.0);
            }
        `;

        // Create material and mesh
        const material = new THREE.ShaderMaterial({
            vertexShader: vertexShader,
            fragmentShader: fragmentShader,
            uniforms: uniforms
        });

        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // Resize handler
        window.addEventListener('resize', () => {
            const currentDPR = window.devicePixelRatio * params.dpr;
            renderer.setSize(window.innerWidth, window.innerHeight);
            uniforms.iResolution.value.set(window.innerWidth * currentDPR, window.innerHeight * currentDPR);
        });

        // Initialize lil-gui
        const gui = new lil.GUI({ title: 'Fractal Settings' });
        
        // Performance
        const perfFolder = gui.addFolder('Performance');
        perfFolder.add(params, 'dpr', 0.1, 2.0, 0.1).name('Resolution (DPR)').onChange(v => {
            const currentDPR = window.devicePixelRatio * v;
            renderer.setPixelRatio(currentDPR);
            uniforms.iResolution.value.set(window.innerWidth * currentDPR, window.innerHeight * currentDPR);
        });

        // Environment
        const envFolder = gui.addFolder('Environment');
        envFolder.add(params, 'speed', 0.0, 10.0, 0.1).name('Flight Speed').onChange(v => uniforms.u_speed.value = v);
        envFolder.add(params, 'glowIntensity', 0.0, 50.0, 0.1).name('Core Glow').onChange(v => uniforms.u_glowIntensity.value = v);
        envFolder.add(params, 'exposure', 50.0, 500.0, 1.0).name('Exposure').onChange(v => uniforms.u_exposure.value = v);
        envFolder.add(params, 'voxelResolution', 10.0, 150.0, 1.0).name('Voxel Res').onChange(v => uniforms.u_voxelResolution.value = v);

        // Fractal Shape (Folding Axes)
        const shapeFolder = gui.addFolder('Fractal Shape');
        const updateFolding = () => {
            uniforms.u_foldingAxis.value.set(params.foldingX, params.foldingY, params.foldingZ);
        };
        shapeFolder.add(params, 'foldingX', 0.0, 10.0, 0.01).name('Fold X').onChange(updateFolding);
        shapeFolder.add(params, 'foldingY', 0.0, 10.0, 0.01).name('Fold Y').onChange(updateFolding);
        shapeFolder.add(params, 'foldingZ', 0.0, 10.0, 0.01).name('Fold Z').onChange(updateFolding);

        // Color Phases
        const colorFolder = gui.addFolder('Color Phases');
        const updateColor1 = () => uniforms.u_colorPhasePrimary.value.set(params.color1R, params.color1G, params.color1B);
        const updateColor2 = () => uniforms.u_colorPhaseSecondary.value.set(params.color2R, params.color2G, params.color2B);
        
        colorFolder.add(params, 'color1R', 0.0, 10.0, 0.1).name('Primary Phase R').onChange(updateColor1);
        colorFolder.add(params, 'color1G', 0.0, 10.0, 0.1).name('Primary Phase G').onChange(updateColor1);
        colorFolder.add(params, 'color1B', 0.0, 10.0, 0.1).name('Primary Phase B').onChange(updateColor1);
        
        colorFolder.add(params, 'color2R', 0.0, 10.0, 0.1).name('Core Phase R').onChange(updateColor2);
        colorFolder.add(params, 'color2G', 0.0, 10.0, 0.1).name('Core Phase G').onChange(updateColor2);
        colorFolder.add(params, 'color2B', 0.0, 10.0, 0.1).name('Core Phase B').onChange(updateColor2);

        // Collapse GUI by default
        gui.close();

        // Animation Loop
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            // Update time uniform
            uniforms.iTime.value = clock.getElapsedTime();
            // Render scene
            renderer.render(scene, camera);
        }

        animate();