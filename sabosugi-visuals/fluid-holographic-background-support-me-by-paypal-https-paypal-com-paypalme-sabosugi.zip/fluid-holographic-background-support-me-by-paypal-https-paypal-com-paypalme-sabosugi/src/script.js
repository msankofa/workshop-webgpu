// --- Setup Scene, Camera, and Renderer ---
        const scene = new THREE.Scene();
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
        camera.position.z = 1;

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        document.body.appendChild(renderer.domElement);

        // --- Shader Parameters ---
        const config = {
            timeScale: 0.6,
            viewScale: 0.9193,
            detail: 0.7007,
            shiftRate: 0.834,
            shiftAmp: 0.7005,
            palette: 'Neon Fluid'
        };

        // --- Color Palettes ---
        const palettes = {
            'Neon Fluid': { angle: 0.0, sat: 1.0, lum: 1.0, weights: [1.0, 1.0, 1.0] },
            'Monochrome': { angle: 0.0, sat: 0.0, lum: 1.0, weights: [1.0, 1.0, 1.0] }
        };

        // =====================================================================
        // CORE SHADER IMPLEMENTATION
        // =====================================================================
        const coreShaderCode = `
            uniform float u_time_scale;
            uniform float u_view_scale;
            uniform float u_detail;
            uniform float u_shift_rate;
            uniform float u_shift_amp;
            
            // Color Uniforms
            uniform float u_tint_angle;
            uniform float u_color_sat;
            uniform float u_lum_factor;
            uniform vec3 u_rgb_weights;

            void computeSurface(out vec4 fragColor, vec2 fragCoord) {
                vec2 resolution = uResolution.xy;
                float minRes = min(resolution.x, resolution.y);
                vec2 normCoord = (fragCoord * 2.0 - resolution) / minRes;
                
                // Scale viewport
                normCoord *= u_view_scale;

                // Time evolution variables
                float t = uTime * u_time_scale * 0.3;
                float shiftT = uTime * u_shift_rate * 0.5;

                // Phase accumulators (replacing old a/d logic)
                vec2 phase = vec2(-t * 0.5, 0.0);
                vec2 pos = normCoord;
                
                // Warping loop
                for (float j = 0.0; j < 8.0; j += 1.0) {
                    vec2 offset = vec2(sin(shiftT + j * 1.3), cos(shiftT - j * 1.1)) * u_shift_amp;
                    vec2 p = pos + offset;
                    
                    phase.y += cos(j - phase.x - p.x * u_detail);
                    phase.x += sin(p.y * u_detail + phase.y);
                }
                phase.x += t * 0.5;
                
                // Base color generation
                vec3 color = vec3(
                    cos(normCoord.x * phase.x + normCoord.y * phase.y) * 0.6 + 0.4, 
                    cos(phase.y + phase.x) * 0.5 + 0.5,
                    cos(normCoord.x * phase.y) * 0.0 // This zero effectively matches the original vec3 construction behavior 
                );
                
                // Channel scrambling
                color.b = cos(phase.y + phase.x) * 0.5 + 0.5; // Override to match original visual math
                color = cos(color * cos(vec3(phase.x, phase.y, 2.5)) * 0.5 + 0.5);
                
                // Apply theme scaling
                color *= u_rgb_weights;
                
                // Rec. 709 luminance (different from original 0.299/0.587/0.114)
                float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
                color = mix(vec3(luma), color, u_color_sat);
                
                // Quaternion-based hue rotation
                vec3 k = vec3(0.577350269);
                float cA = cos(u_tint_angle);
                color = color * cA + cross(k, color) * sin(u_tint_angle) + k * dot(k, color) * (1.0 - cA);
                
                // Final exposure/lightness
                color *= u_lum_factor;
                
                fragColor = vec4(color, 1.0);
            }
        `;
        // =====================================================================

        // --- GLSL Shaders ---
        const vertexShader = `
            void main() {
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform vec3 uResolution;
            uniform float uTime;
            uniform vec4 u_pointer; // Renamed from uMouse
            
            ${coreShaderCode}

            void main() {
                computeSurface(gl_FragColor, gl_FragCoord.xy);
            }
        `;

        // --- Material & Mesh ---
        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms: {
                uResolution: { value: new THREE.Vector3(window.innerWidth, window.innerHeight, 1.0) },
                uTime: { value: 0.0 },
                u_pointer: { value: new THREE.Vector4() },
                u_time_scale: { value: config.timeScale },
                u_view_scale: { value: config.viewScale },
                u_detail: { value: config.detail },
                u_shift_rate: { value: config.shiftRate },
                u_shift_amp: { value: config.shiftAmp },
                u_tint_angle: { value: palettes[config.palette].angle },
                u_color_sat: { value: palettes[config.palette].sat },
                u_lum_factor: { value: palettes[config.palette].lum },
                u_rgb_weights: { value: new THREE.Vector3(...palettes[config.palette].weights) }
            }
        });

        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- Interaction ---
        let pointerDown = false;
        window.addEventListener('mousedown', (e) => {
            pointerDown = true;
            material.uniforms.u_pointer.value.z = e.clientX;
            material.uniforms.u_pointer.value.w = window.innerHeight - e.clientY;
        });
        window.addEventListener('mouseup', () => { pointerDown = false; });
        window.addEventListener('mousemove', (e) => {
            if (pointerDown) {
                material.uniforms.u_pointer.value.x = e.clientX;
                material.uniforms.u_pointer.value.y = window.innerHeight - e.clientY;
            }
        });

        // --- GUI Setup (lil-gui) ---
        window.onload = () => {
            const gui = new lil.GUI({ title: 'Environment Settings' });
            
            const motionFolder = gui.addFolder('Motion Dynamics');
            motionFolder.add(config, 'timeScale', 0.0, 3.0).name('Time Scale').onChange(v => material.uniforms.u_time_scale.value = v);
            motionFolder.add(config, 'viewScale', 0.1, 3.0).name('View Scale').onChange(v => material.uniforms.u_view_scale.value = v);
            
            const fractalFolder = gui.addFolder('Fractal Properties');
            fractalFolder.add(config, 'detail', 0.1, 5.0).name('Detail Level').onChange(v => material.uniforms.u_detail.value = v);
            fractalFolder.add(config, 'shiftRate', 0.0, 2.0).name('Shift Rate').onChange(v => material.uniforms.u_shift_rate.value = v);
            fractalFolder.add(config, 'shiftAmp', 0.0, 1.5).name('Shift Amplitude').onChange(v => material.uniforms.u_shift_amp.value = v);
            
            const visualFolder = gui.addFolder('Visuals');
            visualFolder.add(config, 'palette', Object.keys(palettes)).name('Active Palette').onChange(paletteName => {
                const p = palettes[paletteName];
                material.uniforms.u_tint_angle.value = p.angle;
                material.uniforms.u_color_sat.value = p.sat;
                material.uniforms.u_lum_factor.value = p.lum;
                material.uniforms.u_rgb_weights.value.set(...p.weights);
            });
            
            animate();
        };

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            material.uniforms.uTime.value = clock.getElapsedTime();
            renderer.render(scene, camera);
        }

        // --- Window Resize Handling ---
        window.addEventListener('resize', () => {
            renderer.setSize(window.innerWidth, window.innerHeight);
            material.uniforms.uResolution.value.set(window.innerWidth, window.innerHeight, 1.0);
        });