        // --- SHADERS ---

        // Simplex 3D Noise function for the vertex shader
        const noiseChunk = `
            vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
            vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
            vec4 permute(vec4 x) { return mod289(((x*34.0)+1.0)*x); }
            vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }
            float snoise(vec3 v) { 
                const vec2  C = vec2(1.0/6.0, 1.0/3.0) ;
                const vec4  D = vec4(0.0, 0.5, 1.0, 2.0);
                vec3 i  = floor(v + dot(v, C.yyy) );
                vec3 x0 = v - i + dot(i, C.xxx) ;
                vec3 g = step(x0.yzx, x0.xyz);
                vec3 l = 1.0 - g;
                vec3 i1 = min( g.xyz, l.zxy );
                vec3 i2 = max( g.xyz, l.zxy );
                vec3 x1 = x0 - i1 + C.xxx;
                vec3 x2 = x0 - i2 + C.yyy;
                vec3 x3 = x0 - D.yyy;
                i = mod289(i); 
                vec4 p = permute( permute( permute( 
                            i.z + vec4(0.0, i1.z, i2.z, 1.0 ))
                        + i.y + vec4(0.0, i1.y, i2.y, 1.0 )) 
                        + i.x + vec4(0.0, i1.x, i2.x, 1.0 ));
                float n_ = 0.142857142857;
                vec3  ns = n_ * D.wyz - D.xzx;
                vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
                vec4 x_ = floor(j * ns.z);
                vec4 y_ = floor(j - 7.0 * x_ );
                vec4 x = x_ *ns.x + ns.yyyy;
                vec4 y = y_ *ns.x + ns.yyyy;
                vec4 h = 1.0 - abs(x) - abs(y);
                vec4 b0 = vec4( x.xy, y.xy );
                vec4 b1 = vec4( x.zw, y.zw );
                vec4 s0 = floor(b0)*2.0 + 1.0;
                vec4 s1 = floor(b1)*2.0 + 1.0;
                vec4 sh = -step(h, vec4(0.0));
                vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy ;
                vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww ;
                vec3 p0 = vec3(a0.xy,h.x);
                vec3 p1 = vec3(a0.zw,h.y);
                vec3 p2 = vec3(a1.xy,h.z);
                vec3 p3 = vec3(a1.zw,h.w);
                vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3)));
                p0 *= norm.x;
                p1 *= norm.y;
                p2 *= norm.z;
                p3 *= norm.w;
                vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
                m = m * m;
                return 42.0 * dot( m*m, vec4( dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3) ) );
            }
        `;

        const hairVertexShader = `
            uniform float uTime;
            uniform float uMinBrightness;
            uniform float uMaxBrightness;
            uniform float uHairLength;
            uniform float uWindForce;
            uniform float uNoiseFreq;
            uniform float uNoiseSpeed;
            uniform vec3 uMouseWorld;
            uniform float uMouseRadius;
            uniform float uMouseForce;

            attribute float aProgress;
            attribute float aBrightness;
            attribute vec3 aColor;

            varying vec3 vColor;

            ${noiseChunk}

            void main() {
                // Discard hairs outside the brightness threshold
                if (aBrightness < uMinBrightness || aBrightness > uMaxBrightness) {
                    gl_Position = vec4(2.0, 2.0, 2.0, 1.0); // Move out of clip space
                    return;
                }

                vec3 pos = position;

                // Create organic movement using 3D noise
                vec3 noisePos = vec3(pos.xy * uNoiseFreq, uTime * uNoiseSpeed);
                float nX = snoise(noisePos);
                float nY = snoise(noisePos + vec3(100.0));

                // Bend the hair non-linearly towards the tip
                float bendFactor = pow(aProgress, 1.5); 
                
                // Scale wind displacement by uHairLength so at 0 length there is no movement
                pos.x += nX * uWindForce * bendFactor * uHairLength;
                pos.y += nY * uWindForce * bendFactor * uHairLength;
                
                // Grow along the Z axis
                pos.z += aProgress * uHairLength;

                // Transform to world space to calculate mouse interaction
                vec4 worldPos = modelMatrix * vec4(pos, 1.0);

                // Mouse attraction
                vec2 mouseDir = uMouseWorld.xy - worldPos.xy;
                float distToMouse = length(mouseDir);
                float attraction = smoothstep(uMouseRadius, 0.0, distToMouse);
                
                // Pull tips towards the mouse, scaled by hair length
                worldPos.xy += mouseDir * attraction * uMouseForce * aProgress * uHairLength;

                gl_Position = projectionMatrix * viewMatrix * worldPos;

                // Darken the root, keep the tip original color
                float shading = mix(0.2, 1.2, aProgress);
                vColor = aColor * shading;
            }
        `;

        const hairFragmentShader = `
            varying vec3 vColor;
            void main() {
                gl_FragColor = vec4(vColor, 1.0);
            }
        `;

        // --- GLOBAL VARIABLES ---
        let scene, camera, renderer;
        let hairMesh, bgPlane;
        let imageAspect = 1;
        let group = new THREE.Group();
        
        let mouseX = 0;
        let mouseY = 0;
        let targetX = 0;
        let targetY = 0;

        const clock = new THREE.Clock();
        const raycaster = new THREE.Raycaster();
        const mouse = new THREE.Vector2(-999, -999); // Start off-screen
        const targetMouseWorld = new THREE.Vector3(9999, 9999, 9999); // Target position for smooth transition
        
        // GUI Parameters
        const params = {
            imageUrl: 'https://ik.imagekit.io/sqiqig7tz/villi.jpg',
            minBrightness: 0.0,
            maxBrightness: 1.0,
            hairLength: 0.529,
            windForce: 0.0705,
            noiseFreq: 2.242,
            noiseSpeed: 0.188,
            mouseRadius: 2.9403,
            mouseForce: 0.234,
            uploadNew: () => document.getElementById('file-input').click()
        };

        let gui;
        let hairMaterial;
        let currentTexture = null;

        // --- INITIALIZATION ---
        function init() {
            const container = document.getElementById('canvas-container');

            // Scene setup
            scene = new THREE.Scene();
            scene.add(group); // We'll rotate the group for parallax

            // Camera setup
            camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.z = 10;

            // Renderer setup
            renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            container.appendChild(renderer.domElement);

            // GUI setup
            gui = new lil.GUI({ title: 'Effect Settings' });
            gui.hide(); // Hide until image is uploaded

            // Event Listeners
            window.addEventListener('resize', onWindowResize);
            document.addEventListener('mousemove', onMouseMove);
            document.getElementById('file-input').addEventListener('change', handleFileUpload);

            // Start animation loop
            animate();

            // Load default image on startup
            if (params.imageUrl) {
                loadImageFromUrl(params.imageUrl);
            }
        }

        // --- IMAGE PROCESSING & GEOMETRY GENERATION ---
        function processImage(imageObj) {
            // Remove previous objects to prevent memory leaks
            if (hairMesh) {
                group.remove(hairMesh);
                hairMesh.geometry.dispose();
            }
            if (bgPlane) {
                group.remove(bgPlane);
                bgPlane.geometry.dispose();
                bgPlane.material.dispose();
            }
            if (currentTexture) {
                currentTexture.dispose();
            }

            // Create texture for background
            currentTexture = new THREE.Texture(imageObj);
            currentTexture.needsUpdate = true;
            imageAspect = imageObj.width / imageObj.height;

            // Calculate sampling grid (cap max dimension to ~200 to save performance)
            const MAX_GRID = 200;
            let gridW = imageObj.width;
            let gridH = imageObj.height;
            
            if (gridW > gridH && gridW > MAX_GRID) {
                gridH = Math.floor((MAX_GRID * gridH) / gridW);
                gridW = MAX_GRID;
            } else if (gridH > MAX_GRID) {
                gridW = Math.floor((MAX_GRID * gridW) / gridH);
                gridH = MAX_GRID;
            }

            // Draw to a tiny offscreen canvas to read pixel data
            const canvas = document.createElement('canvas');
            canvas.width = gridW;
            canvas.height = gridH;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(imageObj, 0, 0, gridW, gridH);
            const imgData = ctx.getImageData(0, 0, gridW, gridH).data;

            // Prepare BufferGeometry arrays
            const segmentsPerHair = 4; // 5 points per hair
            const verticesPerHair = segmentsPerHair * 2; // for LineSegments
            const totalHairs = gridW * gridH;
            const totalVertices = totalHairs * verticesPerHair;

            const positions = new Float32Array(totalVertices * 3);
            const progresses = new Float32Array(totalVertices);
            const brightnesses = new Float32Array(totalVertices);
            const colors = new Float32Array(totalVertices * 3);

            let vIdx = 0;

            for (let y = 0; y < gridH; y++) {
                for (let x = 0; x < gridW; x++) {
                    const pxIdx = (y * gridW + x) * 4;
                    const r = imgData[pxIdx] / 255;
                    const g = imgData[pxIdx + 1] / 255;
                    const b = imgData[pxIdx + 2] / 255;
                    
                    // Standard luminance/brightness calculation
                    const brightness = r * 0.299 + g * 0.587 + b * 0.114;

                    // Map X and Y from [0, width] to [-0.5, 0.5]
                    // Y is inverted because Canvas Y is top-down, Three.js Y is bottom-up
                    const nx = (x / gridW) - 0.5;
                    const ny = -(y / gridH) + 0.5;

                    // Generate LineSegments
                    for (let s = 0; s < segmentsPerHair; s++) {
                        const p1 = s / segmentsPerHair;
                        const p2 = (s + 1) / segmentsPerHair;

                        // Vertex 1
                        positions[vIdx * 3] = nx;
                        positions[vIdx * 3 + 1] = ny;
                        positions[vIdx * 3 + 2] = 0;
                        progresses[vIdx] = p1;
                        brightnesses[vIdx] = brightness;
                        colors[vIdx * 3] = r;
                        colors[vIdx * 3 + 1] = g;
                        colors[vIdx * 3 + 2] = b;
                        vIdx++;

                        // Vertex 2
                        positions[vIdx * 3] = nx;
                        positions[vIdx * 3 + 1] = ny;
                        positions[vIdx * 3 + 2] = 0;
                        progresses[vIdx] = p2;
                        brightnesses[vIdx] = brightness;
                        colors[vIdx * 3] = r;
                        colors[vIdx * 3 + 1] = g;
                        colors[vIdx * 3 + 2] = b;
                        vIdx++;
                    }
                }
            }

            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
            geometry.setAttribute('aProgress', new THREE.BufferAttribute(progresses, 1));
            geometry.setAttribute('aBrightness', new THREE.BufferAttribute(brightnesses, 1));
            geometry.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));

            hairMaterial = new THREE.ShaderMaterial({
                vertexShader: hairVertexShader,
                fragmentShader: hairFragmentShader,
                transparent: true,
                depthWrite: false,
                blending: THREE.AdditiveBlending, // Looks better for overlapping fine lines
                uniforms: {
                    uTime: { value: 0 },
                    uMinBrightness: { value: params.minBrightness },
                    uMaxBrightness: { value: params.maxBrightness },
                    uHairLength: { value: params.hairLength },
                    uWindForce: { value: params.windForce },
                    uNoiseFreq: { value: params.noiseFreq },
                    uNoiseSpeed: { value: params.noiseSpeed },
                    uMouseWorld: { value: new THREE.Vector3(9999, 9999, 9999) },
                    uMouseRadius: { value: params.mouseRadius },
                    uMouseForce: { value: params.mouseForce }
                }
            });

            hairMesh = new THREE.LineSegments(geometry, hairMaterial);

            // Setup Background Plane (so the original image sits underneath)
            const planeGeo = new THREE.PlaneGeometry(1, 1);
            const planeMat = new THREE.MeshBasicMaterial({ 
                map: currentTexture, 
                color: 0xffffff // Display the background with original brightness
            });
            bgPlane = new THREE.Mesh(planeGeo, planeMat);
            bgPlane.position.z = -0.01; // Slightly behind the hairs

            group.add(bgPlane);
            group.add(hairMesh);

            updateCoverScale();
            setupGUI();

            // Hide initial overlay
            document.getElementById('ui-overlay').style.opacity = '0';
            setTimeout(() => {
                document.getElementById('ui-overlay').style.display = 'none';
                gui.show();
            }, 500);
        }

        // --- RESIZE AND COVER CALCULATION ---
        function updateCoverScale() {
            if (!bgPlane || !hairMesh) return;

            const windowAspect = window.innerWidth / window.innerHeight;
            
            // Calculate view size at Z=0
            const fov = camera.fov * (Math.PI / 180);
            const visibleHeight = 2 * Math.tan(fov / 2) * camera.position.z;
            const visibleWidth = visibleHeight * windowAspect;

            let scaleX, scaleY;

            // Logic for "object-fit: cover"
            if (windowAspect > imageAspect) {
                // Window is wider than image
                scaleX = visibleWidth;
                scaleY = visibleWidth / imageAspect;
            } else {
                // Window is taller than image
                scaleY = visibleHeight;
                scaleX = visibleHeight * imageAspect;
            }

            bgPlane.scale.set(scaleX, scaleY, 1);
            hairMesh.scale.set(scaleX, scaleY, 1);
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            updateCoverScale();
        }

        // --- INTERACTION ---
        function onMouseMove(event) {
            // Normalized coordinates from -1 to 1
            mouseX = (event.clientX / window.innerWidth) * 2 - 1;
            mouseY = -(event.clientY / window.innerHeight) * 2 + 1;

            mouse.x = mouseX;
            mouse.y = mouseY;
        }

        function handleFileUpload(event) {
            const file = event.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(e) {
                const img = new Image();
                img.onload = function() {
                    processImage(img);
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
            
            // Reset input so the same file can be uploaded again if needed
            event.target.value = '';
        }

        function loadImageFromUrl(url) {
            const img = new Image();
            img.crossOrigin = "Anonymous"; // Required for CORS when drawing to canvas
            img.onload = function() {
                processImage(img);
            };
            img.onerror = function() {
                console.error("Failed to load image from URL. It might be blocked by CORS.");
            };
            img.src = url;
        }

        function setupGUI() {
            // Prevent adding multiple folders if uploading multiple times
            if (gui.controllers.length > 0) return;

            gui.add(params, 'imageUrl').name('Image URL').onFinishChange(v => loadImageFromUrl(v));
            gui.add(params, 'minBrightness', 0.0, 1.0).name('Min Brightness').onChange(v => hairMaterial.uniforms.uMinBrightness.value = v);
            gui.add(params, 'maxBrightness', 0.0, 1.0).name('Max Brightness').onChange(v => hairMaterial.uniforms.uMaxBrightness.value = v);
            // Added explicit step of 0.001 to allow micro-adjustments
            gui.add(params, 'hairLength', 0.0, 3.0, 0.001).name('Villi Length').onChange(v => hairMaterial.uniforms.uHairLength.value = v);
            gui.add(params, 'windForce', 0.0, 0.1).name('Wind Force').onChange(v => hairMaterial.uniforms.uWindForce.value = v);
            gui.add(params, 'noiseFreq', 1.0, 3.5).name('Noise Detail').onChange(v => hairMaterial.uniforms.uNoiseFreq.value = v);
            gui.add(params, 'noiseSpeed', 0.0, 0.5).name('Animation Speed').onChange(v => hairMaterial.uniforms.uNoiseSpeed.value = v);
            gui.add(params, 'mouseRadius', 0.1, 10.0).name('Mouse Radius').onChange(v => hairMaterial.uniforms.uMouseRadius.value = v);
            gui.add(params, 'mouseForce', 0.0, 1.0).name('Mouse Force').onChange(v => hairMaterial.uniforms.uMouseForce.value = v);
            gui.add(params, 'uploadNew').name('Upload New Image');
        }

        // --- RENDER LOOP ---
        function animate() {
            requestAnimationFrame(animate);

            // Smooth parallax effect
            targetX = mouseX * 0.1;
            targetY = mouseY * 0.1;
            group.rotation.y += (targetX - group.rotation.y) * 0.05;
            group.rotation.x += (-targetY - group.rotation.x) * 0.05;

            // Update shader time & mouse raycast
            if (hairMaterial && bgPlane) {
                hairMaterial.uniforms.uTime.value = clock.getElapsedTime();

                // Raycast mouse position onto the image plane
                raycaster.setFromCamera(mouse, camera);
                const intersects = raycaster.intersectObject(bgPlane);
                
                if (intersects.length > 0) {
                    // Instead of setting it directly, set the target
                    targetMouseWorld.copy(intersects[0].point);
                } else {
                    // Reset target if mouse is off the image
                    targetMouseWorld.set(9999, 9999, 9999);
                }

                // Smoothly interpolate the mouse world position uniform towards the target
                // The 0.08 factor controls the smoothness. Lower = smoother/slower.
                hairMaterial.uniforms.uMouseWorld.value.lerp(targetMouseWorld, 0.08);
            }

            renderer.render(scene, camera);
        }

        // Boot
        window.onload = init;