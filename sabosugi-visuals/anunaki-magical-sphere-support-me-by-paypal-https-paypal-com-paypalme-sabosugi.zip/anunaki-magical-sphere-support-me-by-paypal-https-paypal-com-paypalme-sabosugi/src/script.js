    // --- Vertex Shader ---
        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = vec4(position, 1.0);
            }
        `;

        // --- Fragment Shader ---
        const fragmentShader = `
            #ifdef GL_ES
            precision highp float;
            #endif

            uniform vec2 uResolution;
            uniform float uTime;
            uniform int uMaxSteps;
            uniform int uFoldSteps;
            uniform float uKifsScale;
            uniform float uKifsOffset;
            uniform float uTextureScale;
            uniform float uBrightness;
            uniform float uSphereRadius;
            uniform float uInnerRadius;
            uniform vec3 uSphereCenter;
            uniform vec3 uBaseColor;
            uniform float uLightSpeed;
            uniform float uAutoRotationSpeed;
            uniform mat3 uInverseRotationMatrix;
            uniform float uZoom;

            varying vec2 vUv;

            // Helper function for 2D rotation matrix
            mat2 rotate2D(float angle) {
                float s = sin(angle);
                float c = cos(angle);
                return mat2(c, -s, s, c);
            }

            // Exact analytical ray-sphere intersection
            vec2 intersectSphere(vec3 rayOrigin, vec3 rayDir, vec3 center, float radius) {
                vec3 oc = rayOrigin - center;
                float b = dot(oc, rayDir);
                float c = dot(oc, oc) - radius * radius;
                float h = b * b - c;
                
                if(h < 0.0) return vec2(-1.0);
                h = sqrt(h);
                return vec2(-b - h, -b + h);
            }

            void main() {
                // Normalize coordinates and setup camera applying zoom factor
                vec2 uvCenter = (2.0 * gl_FragCoord.xy - uResolution.xy) / uResolution.y;
                
                // 1. Setup camera ray in world space
                vec3 rayOriginWorld = vec3(0.0, 0.0, 0.0);
                vec3 rayDirectionWorld = normalize(vec3(uvCenter * uZoom, -1.0));
                
                // 2. Transform ray to sphere-local space
                // This perfectly links the physical sphere geometry AND the fractal depth layers 
                // to the manual rotation, making it rotate as one solid rigid body.
                vec3 localRayOrigin = rayOriginWorld - uSphereCenter;
                localRayOrigin = uInverseRotationMatrix * localRayOrigin;
                vec3 localRayDirection = uInverseRotationMatrix * rayDirectionWorld;
                
                // 3. Intersect with the sphere which is now at origin (0,0,0) in local space
                vec2 hitOuter = intersectSphere(localRayOrigin, localRayDirection, vec3(0.0), uSphereRadius);
                
                if (hitOuter.x < 0.0) {
                    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
                    return;
                }
                
                float tStart = max(0.0, hitOuter.x);
                float tEnd = hitOuter.y;
                
                // Constant step size prevents Moire noise and sliced artifacts completely
                float stepSize = (tEnd - tStart) / float(uMaxSteps);
                float currentDistance = tStart;
                
                vec4 accumulatedColor = vec4(0.0);
                
                // Volumetric raymarching exactly through the sphere bounds
                for (int i = 0; i < 250; i++) {
                    if (i >= uMaxSteps) break;
                    
                    // Position in local unrotated object space
                    vec3 localPos = localRayOrigin + localRayDirection * currentDistance;
                    float distFromCenter = length(localPos);
                    
                    // Soft hollow shell mask: 1.0 inside the walls, fading to 0.0 at the edges
                    float wallMask = smoothstep(uInnerRadius, uInnerRadius + 1.0, distFromCenter) * smoothstep(uSphereRadius, uSphereRadius - 0.2, distFromCenter);
                    
                    // Optimization: Only compute the heavy KIFS math if we are inside the solid wall
                    if (wallMask > 0.01) {
                        
                        vec3 currentPos = localPos * uTextureScale;
                        
                        // Auto-rotation morphing for the "alive" feeling
                        currentPos.xy *= rotate2D(uTime * 0.15 * uAutoRotationSpeed);
                        currentPos.xz *= rotate2D(uTime * 0.10 * uAutoRotationSpeed);
                        
                        // Seamless mirroring exactly from code-final
                        currentPos = abs(currentPos);
                        
                        // Exact logic from code-final.txt using the true step index 'i'
                        // This perfectly preserves the deep complex visual structure.
                        float timeVal = 2.6 + float(i) * 0.356;
                        vec3 reflectionAxis = normalize(tan(timeVal + vec3(2.5, 1.0, 0.0)));
                        currentPos = reflect(-currentPos, reflectionAxis) - vec3(-2.6, -1.0, 0.2);
                        
                        float accumulatedScale = 0.1;
                        
                        // Base symmetry fold
                        if (currentPos.x < currentPos.z) {
                            currentPos = currentPos.zyx;
                        }
                        
                        // KIFS loop strictly from your preferred parameters
                        for (int k = 0; k < 16; k++) {
                            if (k >= uFoldSteps) break;
                            currentPos *= uKifsScale;
                            accumulatedScale *= uKifsScale;
                            currentPos.y += uKifsOffset;
                            
                            if (currentPos.y > currentPos.z) currentPos = currentPos.xzy;
                            
                            currentPos *= uKifsScale;
                            accumulatedScale *= uKifsScale;
                            currentPos.y += uKifsOffset;
                            
                            if (currentPos.x < currentPos.y) currentPos = currentPos.yxz;
                        }
                        
                        // Density calculation
                        float currentDensity = max(length(currentPos.xz) / accumulatedScale, 0.001);
                        
                        // Volumetric color formula using configured base color
                        vec3 spatialPhase = currentPos.xyz;
                        vec3 lightIntensity = exp(sin(uTime * uLightSpeed + spatialPhase)) / currentDensity;
                        
                        // Accumulate glow colors inside the sphere container
                        accumulatedColor.rgb += uBaseColor * lightIntensity * stepSize * uBrightness * wallMask;
                    }
                    
                    currentDistance += stepSize;
                }
                
                // Final tone mapping for glowing neon colors
                gl_FragColor.rgb = tanh(accumulatedColor.rgb);
                gl_FragColor.a = 1.0;
                
                // Add a subtle blue rim light to cleanly define the outer glass edge in local space
                vec3 localHitPoint = localRayOrigin + localRayDirection * hitOuter.x;
                vec3 surfaceNormalLocal = normalize(localHitPoint);
                float edgeHighlight = 0.7 - max(dot(-localRayDirection, surfaceNormalLocal), 0.5);
                gl_FragColor.rgb += vec3(0.05, 0.1, 0.3) * pow(edgeHighlight, 4.0);
            }
        `;

        // --- JavaScript Scene Setup ---
        const canvas = document.getElementById('webgl-canvas');
        const loader = document.getElementById('loader');

        // Scene, camera, and renderer instantiation
        const scene = new THREE.Scene();
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: false, powerPreference: "high-performance" });
        
        // Configuration Parameters Object
        const config = {
            maxSteps: 148,
            foldSteps: 6,
            kifsScale: 1.26,
            kifsOffset: 8.9,
            textureScale: 1.45,
            brightness: 1.423,
            coreColor: '#7780ff',
            colorBoost: 3.0,
            lightSpeed: 5.5,
            sphereRadius: 15.0,
            innerRadius: 14.0,
            sphereCenterZ: -25.0,
            autoRotationSpeed: 1.0,
            dpr: 1.0
        };

        // Material uniforms initialization
        const uniforms = {
            uResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            uTime: { value: 0.0 },
            uMaxSteps: { value: config.maxSteps },
            uFoldSteps: { value: config.foldSteps },
            uKifsScale: { value: config.kifsScale },
            uKifsOffset: { value: config.kifsOffset },
            uTextureScale: { value: config.textureScale },
            uBrightness: { value: config.brightness },
            uSphereRadius: { value: config.sphereRadius },
            uInnerRadius: { value: config.innerRadius },
            uSphereCenter: { value: new THREE.Vector3(0.0, 0.0, config.sphereCenterZ) },
            uBaseColor: { value: new THREE.Vector3() },
            uLightSpeed: { value: config.lightSpeed },
            uAutoRotationSpeed: { value: config.autoRotationSpeed },
            uInverseRotationMatrix: { value: new THREE.Matrix3() },
            uZoom: { value: 1.0 }
        };

        // Parse hex color & scale with color boost
        function updateBaseColorUniform() {
            const tempColor = new THREE.Color(config.coreColor);
            uniforms.uBaseColor.value.set(
                tempColor.r * config.colorBoost,
                tempColor.g * config.colorBoost,
                tempColor.b * config.colorBoost
            );
        }
        updateBaseColorUniform();

        // Render Quad Setup
        const geometry = new THREE.PlaneGeometry(2, 2);
        const material = new THREE.ShaderMaterial({
            vertexShader: vertexShader,
            fragmentShader: fragmentShader,
            uniforms: uniforms,
            depthWrite: false,
            depthTest: false
        });
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- Interaction Mechanics (Inertia & Gestures) ---
        let isDragging = false;
        let previousPointerPosition = { x: 0, y: 0 };
        let velocityX = 0, velocityY = 0;
        let currentZoom = 1.0;
        let targetZoom = 1.0;

        // Quaternions used for infinite, gimbal-lock-free 3D rotation
        const targetRotation = new THREE.Quaternion();
        const currentRotation = new THREE.Quaternion();
        const axisX = new THREE.Vector3(1, 0, 0);
        const axisY = new THREE.Vector3(0, 1, 0);

        // Pointer event registration (Unified mouse and mobile single-touch)
        window.addEventListener('pointerdown', (e) => {
            if (e.target.closest('.lil-gui')) return;
            isDragging = true;
            previousPointerPosition = { x: e.clientX, y: e.clientY };
            velocityX = 0;
            velocityY = 0;
        });

        window.addEventListener('pointermove', (e) => {
            if (!isDragging) return;
            const deltaX = e.clientX - previousPointerPosition.x;
            const deltaY = e.clientY - previousPointerPosition.y;

            // Inverted vertical rotation, kept horizontal. 
            // Switched to rad/pixel speed for quaternions.
            velocityX = deltaX * 0.0035;
            velocityY = deltaY * 0.0035;

            // Apply rotation directly to target quaternion in world space
            const qY = new THREE.Quaternion().setFromAxisAngle(axisY, velocityX);
            const qX = new THREE.Quaternion().setFromAxisAngle(axisX, velocityY);
            targetRotation.premultiply(qX).premultiply(qY);
            targetRotation.normalize();

            previousPointerPosition = { x: e.clientX, y: e.clientY };
        });

        window.addEventListener('pointerup', () => { isDragging = false; });
        window.addEventListener('pointercancel', () => { isDragging = false; });

        // Wheel Zoom Support
        window.addEventListener('wheel', (e) => {
            if (e.target.closest('.lil-gui')) return;
            targetZoom += e.deltaY * 0.001;
            targetZoom = Math.max(0.3, Math.min(4.0, targetZoom));
        }, { passive: true });

        // Mobile Double Touch (Pinch-to-zoom) Support
        let touchStartDist = 0;
        let baseZoom = 1.0;

        window.addEventListener('touchstart', (e) => {
            if (e.touches.length === 2) {
                touchStartDist = Math.hypot(
                    e.touches[0].clientX - e.touches[1].clientX,
                    e.touches[0].clientY - e.touches[1].clientY
                );
                baseZoom = targetZoom;
            }
        }, { passive: true });

        window.addEventListener('touchmove', (e) => {
            if (e.touches.length === 2 && touchStartDist > 0) {
                const dist = Math.hypot(
                    e.touches[0].clientX - e.touches[1].clientX,
                    e.touches[0].clientY - e.touches[1].clientY
                );
                const factor = dist / touchStartDist;
                targetZoom = Math.max(0.3, Math.min(4.0, baseZoom / factor));
            }
        }, { passive: true });

        window.addEventListener('touchend', () => { touchStartDist = 0; });

        // --- Core Update Matrix Calculations ---
        const rotationMatrix4 = new THREE.Matrix4();
        const rotationMatrix3 = new THREE.Matrix3();

        function updateRotationAndZoom() {
            if (!isDragging) {
                // Apply inertia decay over frames
                velocityX *= 0.95;
                velocityY *= 0.95;

                // Continue applying inertia to the target rotation
                const qY = new THREE.Quaternion().setFromAxisAngle(axisY, velocityX);
                const qX = new THREE.Quaternion().setFromAxisAngle(axisX, velocityY);
                targetRotation.premultiply(qX).premultiply(qY);
                targetRotation.normalize();
            }

            // Smooth interpolation (Slerp) for cinematic rotation feeling
            currentRotation.slerp(targetRotation, 0.1);
            currentZoom += (targetZoom - currentZoom) * 0.15;

            // Construct exact Three.js Matrix from quaternion
            rotationMatrix4.makeRotationFromQuaternion(currentRotation);
            rotationMatrix4.invert(); 
            rotationMatrix3.setFromMatrix4(rotationMatrix4);

            uniforms.uInverseRotationMatrix.value.copy(rotationMatrix3);
            uniforms.uZoom.value = currentZoom;
        }

        // --- Setup lil-gui Control Panel ---
        const gui = new lil.GUI({ title: "Control Panel" });
        gui.close();

        // Folder: Fractal Geometry
        const fGeometry = gui.addFolder("Fractal Core");
        fGeometry.add(config, "foldSteps", 1, 15, 1).name("Detail Steps").onChange(v => uniforms.uFoldSteps.value = v);
        fGeometry.add(config, "kifsScale", 1.0, 1.8, 0.01).name("KIFS Scale").onChange(v => uniforms.uKifsScale.value = v);
        fGeometry.add(config, "kifsOffset", 1.0, 15.0, 0.1).name("KIFS Offset").onChange(v => uniforms.uKifsOffset.value = v);
        fGeometry.add(config, "textureScale", 0.1, 4.0, 0.05).name("Pattern Scale").onChange(v => uniforms.uTextureScale.value = v);

        // Folder: Light & Emission
        const fLight = gui.addFolder("Light & Glow");
        fLight.add(config, "brightness", 0.1, 4.0, 0.01).name("Brightness").onChange(v => uniforms.uBrightness.value = v);
        fLight.addColor(config, "coreColor").name("Base Tint").onChange(updateBaseColorUniform);
        fLight.add(config, "colorBoost", 0.5, 6.0, 0.1).name("Glow Intensity").onChange(updateBaseColorUniform);
        fLight.add(config, "lightSpeed", 0.0, 15.0, 0.1).name("Pulse Speed").onChange(v => uniforms.uLightSpeed.value = v);

        // Folder: Container Geometry
        const fSphere = gui.addFolder("Outer Sphere");
        fSphere.add(config, "sphereRadius", 5.0, 25.0, 0.1).name("Outer Radius").onChange(v => {
            uniforms.uSphereRadius.value = v;
            if (config.innerRadius >= v) {
                config.innerRadius = v - 1.0;
                uniforms.uInnerRadius.value = config.innerRadius;
                fSphere.controllers.find(c => c.property === "innerRadius").updateDisplay();
            }
        });
        fSphere.add(config, "innerRadius", 4.0, 24.0, 0.1).name("Inner Radius").onChange(v => {
            if (v >= config.sphereRadius) {
                config.innerRadius = config.sphereRadius - 1.0;
                uniforms.uInnerRadius.value = config.innerRadius;
                fSphere.controllers.find(c => c.property === "innerRadius").updateDisplay();
            } else {
                uniforms.uInnerRadius.value = v; 
            }
        });
        fSphere.add(config, "maxSteps", 20, 250, 1).name("Raymarching Detail").onChange(v => uniforms.uMaxSteps.value = v);

        // Folder: System and Dynamics
        const fSystem = gui.addFolder("System Config");
        fSystem.add(config, "autoRotationSpeed", 0.0, 3.0, 0.05).name("Auto Spin").onChange(v => uniforms.uAutoRotationSpeed.value = v);
        fSystem.add(config, "dpr", 0.25, 2.0, 0.25).name("Screen DPR").onChange(v => {
            renderer.setPixelRatio(v);
        });

        // --- Handling Canvas Resizing ---
        function onWindowResize() {
            const width = window.innerWidth;
            const height = window.innerHeight;
            renderer.setSize(width, height);
            uniforms.uResolution.value.set(width, height);
        }
        window.addEventListener('resize', onWindowResize);
        
        // Initial setup run
        onWindowResize();
        renderer.setPixelRatio(config.dpr);

        // Clear Loader spinner
        setTimeout(() => {
            loader.style.opacity = 0;
            setTimeout(() => loader.style.display = 'none', 1000);
        }, 500);

        // --- Infinite Render Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            // Advance uniforms time
            uniforms.uTime.value = clock.getElapsedTime();
            
            // Re-evaluate rotations and manual mouse inertia matrices
            updateRotationAndZoom();
            
            // Render the screen space quad
            renderer.render(scene, camera);
        }

        animate();