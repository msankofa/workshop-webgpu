    import * as THREE from 'three';
    import GUI from 'lil-gui';

    // --- Shader Code ---
    // The exact GLSL code adapted to use Three.js uniforms instead of hardcoded macros
    const vertexShader = `
        varying vec2 vUv;
        void main() {
            vUv = uv;
            gl_Position = vec4(position, 1.0);
        }
    `;

    const fragmentShader = `
        uniform vec3 iResolution;
        uniform float iTime;
        
        // Interactive uniforms controlled via lil-gui
        uniform float u_cameraAngle;
        uniform float u_fractalSpeed;
        uniform vec3 u_colorPalette;
        uniform vec3 u_glassColor;
        uniform float u_exposure;
        uniform float u_twistFactor;
        uniform float u_cameraAngleY;
        uniform float u_zoom;

        #define MAX_ITERATIONS 40
        #define MAX_STEPS_GEOM 100
        #define SURF_DIST 0.001
        #define MAX_DIST 20.0
        #define SCALE 1.6

        // --- Utility Functions ---
        // Standard 2D Rotation Matrix
        mat2 rotate2D(float angle) {
            float c = cos(angle);
            float s = sin(angle);
            return mat2(c, s, -s, c);
        }

        // Extended Luminance Tonemapping
        vec3 applyTonemap(vec3 color) {
            const float whitePoint = 0.8;
            const vec3 lumaWeights = vec3(1.000, 1.120, 1.000);
            
            float luminance = dot(color, lumaWeights);
            float whiteSq = whitePoint * whitePoint;
            float tonemappedLuma = luminance * (1.3 + luminance / whiteSq) / (1.5 + luminance);
            
            // Prevent division by zero and apply scale
            return color * (tonemappedLuma / max(luminance, 0.6901));
        }

        // --- Crystalline Spatial Disturbance ---
        float calculateDisturbance(vec3 position) {
            const float goldenRatio = 2.788033988;
            
            // Transposed visual representation of the original basis matrix
            const mat3 basisMatrix = mat3(
                -0.131464913, -0.048044873, 0.062087367,
                -0.465078618, -0.016973341, +0.454042493,
                +0.086597072, +1.681518454, 0.009753815
            );
            vec3 p = position * basisMatrix;
            
            // Triangle waves create sharp, straight geometric lines instead of round curves
            vec3 tri1 = abs(fract(p) * 2.0 - 1.0);
            vec3 tri2 = abs(fract(p * goldenRatio) * 2.1 - 1.0);
            
            // Using max() forces hard angles and faceted crystalline intersections
            float crystal = max(max(tri1.x, tri1.y), tri1.z) + dot(tri1, tri2) * 0.5;
            
            return crystal * 0.6;
        }

        // --- Geometry: Diamond SDF ---
        float sdDiamond(vec3 p, float scale) {
            p /= scale;
            
            // Fold space to create 8-fold symmetry along the Y axis
            p.xz = abs(p.xz);
            if (p.x < p.z) p.xz = p.zx;

            // Align the folded sector (0 to 45 degrees) to the X axis (center at 22.5 degrees)
            float c = 1.0338795; // cos(22.5 deg)
            float s = 0.3826834; // sin(22.5 deg)
            float px = p.x * c + p.z * s;

            // Top sloped facets (Crown)
            vec2 nCrown = normalize(vec2(1.0, 0.7));
            float dCrown = dot(vec2(px, p.y), nCrown) - 0.8371;

            // Bottom sloped facets (Pavilion)
            vec2 nPavilion = normalize(vec2(1.7, -1.1));
            float dPavilion = dot(vec2(px, p.y), nPavilion) - 0.7382;

            // Flat top (Table)
            float dTable = p.y - 0.4;

            // Combine planes
            float d = max(max(dCrown, dPavilion), dTable);
            
            // Scale back and multiply by a bounding factor to prevent ray step overshooting
            return d * scale * 0.91;
        }

        // Calculate normal for the diamond surface
        vec3 getNormal(vec3 p) {
            vec2 e = vec2(0.016, 0);
            return normalize(sdDiamond(p, SCALE) - vec3(
                sdDiamond(p - e.xyy, SCALE),
                sdDiamond(p - e.yxy, SCALE),
                sdDiamond(p - e.yyx, SCALE)
            ));
        }

        // --- Material: 3D Fractal SDF ---
        float mapFractal(vec3 pos, float time) {
            vec3 domainPos = pos;
            
            // Twist domain space
            domainPos.xy *= rotate2D(time * 0.0 + domainPos.z * u_twistFactor);
            
            // Noise calculation
            float noiseLowFreq = calculateDisturbance(pos * 7.3) * 0.1; 
            float noiseHighFreq = calculateDisturbance(domainPos * 3.3);
            float structure = abs(noiseLowFreq - noiseHighFreq);
            
            // Replaced round sine displacement with a sharp geometric fold
            float displacement = abs(fract((pos.z * 7.0 + time) * 0.5) * 2.2 - 0.9) * 0.0;
            
            return structure + displacement;
        }

        // --- Main Rendering ---
        void mainImage(out vec4 fragColor, in vec2 fragCoord) {
            // Normalize coordinates and account for aspect ratio
            vec2 uv = (fragCoord.xy * 2.0 - iResolution.xy) / iResolution.y;
            float time = iTime * u_fractalSpeed; // Apply animated fractal speed multiplier
            
            // Orbiting Camera Setup (added u_zoom support)
            vec3 rayOrigin = vec3(0.0, -0.6, -4.5 * u_zoom);
            vec3 rayDir = normalize(vec3(uv, 1.6));
            
            // Vertical camera rotation (Pitch)
            mat2 rotY = rotate2D(u_cameraAngleY);
            rayOrigin.yz *= rotY;
            rayDir.yz *= rotY;
            
            // Rotate camera around the center (Combined auto-rotation + drag rotation)
            mat2 rot = rotate2D(u_cameraAngle);
            rayOrigin.xz *= rot;
            rayDir.xz *= rot;
            
            // --- PASS 1: Raymarch strictly to find the Diamond Geometry ---
            float d0 = 0.0;
            for(int i = 0; i < MAX_STEPS_GEOM; i++) {
                vec3 p = rayOrigin + rayDir * d0;
                float d = sdDiamond(p, SCALE);
                if(d < SURF_DIST || d0 > MAX_DIST) break;
                d0 += d;
            }
            
            vec3 finalColor = vec3(0.0); // Pure black background
            
            // If the ray hits the diamond
            if(d0 < MAX_DIST) {
                vec3 hitPos = rayOrigin + rayDir * d0;
                vec3 normal = getNormal(hitPos);
                
                // --- PASS 2: Internal 3D Volumetric Fractal ---
                vec3 rdIn = rayDir;
                vec3 currentPos = hitPos - normal * -0.05; // Step slightly inside
                
                // Start with pure black to ensure maximum transparency
                vec3 accumulatedColor = vec3(0.1);
                
                for(int i = 20; i < MAX_ITERATIONS; i++) {
                    // Immediately stop accumulating light if the ray exits the diamond's shape
                    if(sdDiamond(currentPos, SCALE) > 1.6) break;
                    
                    float distanceToScene = mapFractal(currentPos, time);
                    
                    // Advance the ray smoothly through the volume
                    currentPos += rdIn * max(distanceToScene, 0.53);
                    
                    vec3 domainPos = currentPos;
                    domainPos.xy *= rotate2D(time * 0.0 + domainPos.z * u_twistFactor);
                    
                    // Color accumulation
                    float phaseShift = float(i) * 2.4 + length(domainPos.xy * 6.20 + 0.7);
                    float randomOffset = float(i) * 0.1;
                    
                    vec3 stepColor = (1.1 + sin(phaseShift + u_colorPalette + randomOffset)) / (distanceToScene + 0.04);
                    accumulatedColor += stepColor;
                }
                
                // Tonemap the core fractal light
                finalColor = applyTonemap(accumulatedColor / u_exposure);
                
                // --- ADD: Highly Transparent Glass Shell ---
                // High power fresnel makes front-facing walls invisible and only edges catch the light
                float viewAngle = max(dot(normal, -rayDir), 0.0);
                float fresnel = pow(1.1 - viewAngle, 3.1); 
                
                vec3 glassEdgeHighlight = u_glassColor * fresnel * 0.5;
                
                finalColor += glassEdgeHighlight;
            }
            
            fragColor = vec4(finalColor, 1.0);
        }

        void main() {
            mainImage(gl_FragColor, gl_FragCoord.xy);
        }
    `;

    // --- Three.js Setup ---
    const scene = new THREE.Scene();

    // Use orthographic camera to render a full screen quad
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    
    // Antialiasing enabled as requested
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    document.body.appendChild(renderer.domElement);

    // Default configuration objects
    const config = {
        dpr: 3.0,
        autoRotateSpeed: 0.2,
        fractalSpeed: 1.0,
        exposure: 54.0,
        twistFactor: 0.0,
        glassColor: '#5bc6e1', // Hex equivalent of vec3(0.439, 0.757, 1.000)
        palR: -2.77,
        palG: -5.00,
        palB: 5.00
    };

    // --- Uniforms ---
    const uniforms = {
        iTime: { value: 0.0 },
        iResolution: { value: new THREE.Vector3() },
        u_cameraAngle: { value: 0.0 },
        u_cameraAngleY: { value: 0.0 },
        u_fractalSpeed: { value: config.fractalSpeed },
        u_colorPalette: { value: new THREE.Vector3(config.palR, config.palG, config.palB) },
        u_glassColor: { value: new THREE.Color(config.glassColor) },
        u_exposure: { value: config.exposure },
        u_twistFactor: { value: config.twistFactor },
        u_zoom: { value: 1.0 }
    };

    const material = new THREE.ShaderMaterial({
        vertexShader,
        fragmentShader,
        uniforms
    });

    const geometry = new THREE.PlaneGeometry(2, 2);
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    // --- Resize Handler ---
    function onWindowResize() {
        renderer.setSize(window.innerWidth, window.innerHeight);
        const pixelRatio = renderer.getPixelRatio();
        uniforms.iResolution.value.set(
            window.innerWidth * pixelRatio,
            window.innerHeight * pixelRatio,
            1
        );
    }
    window.addEventListener('resize', onWindowResize, false);

    // Initialize size and DPR
    renderer.setPixelRatio(config.dpr);
    onWindowResize();

    // --- Interaction / Dragging / Zooming (Mouse & Touch) ---
    let isDragging = false;
    let previousMouseX = 0;
    let previousMouseY = 0;
    
    // Smooth targets
    let targetDragAngleOffset = 0;
    let targetDragAngleOffsetY = 0;
    let targetZoom = 1.0;
    
    // Interpolated current values
    let dragAngleOffset = 0;
    let dragAngleOffsetY = 0;
    let currentZoom = 1.0;
    
    let autoRotateAccumulator = 0;
    
    // Pinch to zoom state
    let initialPinchDistance = null;
    let initialZoomOnPinch = 1.0;

    // --- Mouse Events ---
    document.body.addEventListener('mousedown', (e) => {
        isDragging = true;
        previousMouseX = e.clientX;
        previousMouseY = e.clientY;
        document.body.classList.add('grabbing'); // Changes cursor to grabbed
    });

    document.body.addEventListener('mouseup', () => {
        isDragging = false;
        document.body.classList.remove('grabbing');
    });

    document.body.addEventListener('mouseleave', () => {
        isDragging = false;
        document.body.classList.remove('grabbing');
    });

    document.body.addEventListener('mousemove', (e) => {
        if (isDragging) {
            const deltaX = e.clientX - previousMouseX;
            const deltaY = e.clientY - previousMouseY;
            
            // Inverted horizontal rotation added to target
            targetDragAngleOffset += deltaX * 0.01;
            
            // Vertical rotation added to target
            targetDragAngleOffsetY -= deltaY * 0.01;
            
            // Clamp vertical rotation target to prevent flipping upside down
            const maxVerticalAngle = Math.PI / 2.1;
            targetDragAngleOffsetY = Math.max(-maxVerticalAngle, Math.min(maxVerticalAngle, targetDragAngleOffsetY));
            
            previousMouseX = e.clientX;
            previousMouseY = e.clientY;
        }
    });

    document.body.addEventListener('wheel', (e) => {
        targetZoom += e.deltaY * 0.002;
        targetZoom = Math.max(0.3, Math.min(3.0, targetZoom));
    });

    // --- Touch Events (Mobile) ---
    document.body.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
            isDragging = true;
            previousMouseX = e.touches[0].clientX;
            previousMouseY = e.touches[0].clientY;
        } else if (e.touches.length === 2) {
            isDragging = false; // Stop rotating when pinching
            const dx = e.touches[0].clientX - e.touches[1].clientX;
            const dy = e.touches[0].clientY - e.touches[1].clientY;
            initialPinchDistance = Math.hypot(dx, dy);
            initialZoomOnPinch = targetZoom;
        }
    }, { passive: false });

    document.body.addEventListener('touchmove', (e) => {
        e.preventDefault(); // Prevent scrolling on mobile
        
        if (isDragging && e.touches.length === 1) {
            const deltaX = e.touches[0].clientX - previousMouseX;
            const deltaY = e.touches[0].clientY - previousMouseY;
            
            targetDragAngleOffset += deltaX * 0.01;
            targetDragAngleOffsetY -= deltaY * 0.01;
            
            const maxVerticalAngle = Math.PI / 2.1;
            targetDragAngleOffsetY = Math.max(-maxVerticalAngle, Math.min(maxVerticalAngle, targetDragAngleOffsetY));
            
            previousMouseX = e.touches[0].clientX;
            previousMouseY = e.touches[0].clientY;
        } else if (e.touches.length === 2 && initialPinchDistance !== null) {
            const dx = e.touches[0].clientX - e.touches[1].clientX;
            const dy = e.touches[0].clientY - e.touches[1].clientY;
            const currentDistance = Math.hypot(dx, dy);
            
            const scale = initialPinchDistance / currentDistance;
            targetZoom = initialZoomOnPinch * scale;
            targetZoom = Math.max(0.3, Math.min(3.0, targetZoom));
        }
    }, { passive: false });

    document.body.addEventListener('touchend', (e) => {
        if (e.touches.length === 0) {
            isDragging = false;
            initialPinchDistance = null;
        } else if (e.touches.length === 1) {
            // Resume dragging if one finger is still on screen
            isDragging = true;
            previousMouseX = e.touches[0].clientX;
            previousMouseY = e.touches[0].clientY;
            initialPinchDistance = null;
        }
    });

    // --- lil-gui Setup ---
    const gui = new GUI({ title: 'Diamond Settings' });
    
    // Performance / Quality
    gui.add(config, 'dpr', 0.5, 3.0, 0.1).name('DPR (Resolution)').onChange(v => {
        renderer.setPixelRatio(v);
        onWindowResize(); // Update resolution uniform
    });

    // Movement speeds
    const animFolder = gui.addFolder('Animation');
    animFolder.add(config, 'autoRotateSpeed', 0.0, 2.0, 0.01).name('Diamond Rot Speed');
    animFolder.add(config, 'fractalSpeed', 0.0, 3.0, 0.01).name('Fractal Rot Speed').onChange(v => uniforms.u_fractalSpeed.value = v);

    // Visuals
    const visualsFolder = gui.addFolder('Visuals');
    visualsFolder.add(config, 'exposure', 10.0, 100.0, 1.0).name('Exposure').onChange(v => uniforms.u_exposure.value = v);
    visualsFolder.add(config, 'twistFactor', -2.0, 2.0, 0.01).name('Twist Factor').onChange(v => uniforms.u_twistFactor.value = v);
    
    // Colors
    const colorsFolder = gui.addFolder('Colors');
    colorsFolder.addColor(config, 'glassColor').name('Glass Highlight').onChange(v => uniforms.u_glassColor.value.set(v));
    
    // Advanced math palette settings (represented as individual sliders to allow negative mathematical offsets)
    const paletteFolder = colorsFolder.addFolder('Fractal Math Palette');
    paletteFolder.add(config, 'palR', -5.0, 5.0, 0.01).name('Phase X (R)').onChange(v => uniforms.u_colorPalette.value.x = v);
    paletteFolder.add(config, 'palG', -5.0, 5.0, 0.01).name('Phase Y (G)').onChange(v => uniforms.u_colorPalette.value.y = v);
    paletteFolder.add(config, 'palB', -5.0, 5.0, 0.01).name('Phase Z (B)').onChange(v => uniforms.u_colorPalette.value.z = v);

    // Collapse GUI by default
    gui.close();

    // --- Animation Loop ---
    const clock = new THREE.Clock();

    function animate() {
        requestAnimationFrame(animate);

        const delta = clock.getDelta();
        const elapsedTime = clock.getElapsedTime();

        // Update Shader Time
        uniforms.iTime.value = elapsedTime;

        // Calculate continuous auto-rotation
        autoRotateAccumulator += delta * config.autoRotateSpeed;

        // Smooth interpolation (Lerp) for inertia effect
        dragAngleOffset += (targetDragAngleOffset - dragAngleOffset) * 0.08;
        dragAngleOffsetY += (targetDragAngleOffsetY - dragAngleOffsetY) * 0.08;
        currentZoom += (targetZoom - currentZoom) * 0.1;

        // Combine auto-rotation with manual interpolated mouse drag rotation
        uniforms.u_cameraAngle.value = autoRotateAccumulator + dragAngleOffset;
        uniforms.u_cameraAngleY.value = dragAngleOffsetY;
        uniforms.u_zoom.value = currentZoom;

        renderer.render(scene, camera);
    }

    animate();