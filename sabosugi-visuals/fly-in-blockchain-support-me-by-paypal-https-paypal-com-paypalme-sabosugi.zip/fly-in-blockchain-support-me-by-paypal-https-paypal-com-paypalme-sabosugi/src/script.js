        import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- 1. Scene Setup ---
        const scene = new THREE.Scene();
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
        camera.position.z = 1;

        // --- 2. Renderer Configuration ---
        const renderer = new THREE.WebGLRenderer({ antialias: false });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(0.8); // Forced DPR for Raymarching performance
        document.body.appendChild(renderer.domElement);

        // --- 3. Uniforms Configuration ---
        const uniforms = {
            u_time: { value: 0.0 },
            u_resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            u_fogColor: { value: new THREE.Color(0x191c1f) },
            u_fogDensity: { value: 0.064 },
            u_speed: { value: 0.5 },
            u_flyDirection: { value: -1.0 },
            u_iterations: { value: 3 },
            u_fractalScale: { value: 2.6 },
            u_fractalRotation: { value: 0.1 },
            u_fractalOffset: { value: new THREE.Vector3(0.2, 0.45, 0.17) },
            u_carveSize: { value: 1.2 },
            u_colorKey: { value: new THREE.Color(0xb3e5ff) }, // Cool cyan base
            u_colorFill: { value: new THREE.Color(0xff8033) } // Warm orange base
        };

        // --- 4. Shaders ---
        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            precision highp float;

            uniform float u_time;
            uniform vec2 u_resolution;
            uniform vec3 u_fogColor;
            uniform float u_fogDensity;
            uniform float u_speed;
            uniform float u_flyDirection;
            uniform int u_iterations;
            uniform float u_fractalScale;
            uniform float u_fractalRotation;
            uniform vec3 u_fractalOffset;
            uniform float u_carveSize;
            uniform vec3 u_colorKey;
            uniform vec3 u_colorFill;

            varying vec2 vUv;

            // Increased MAX_STEPS heavily to allow precise distance calculation without artifacts
            #define MAX_STEPS 300
            #define MAX_DIST 60.0

            // 2D Rotation Matrix
            mat2 rot(float a) {
                float s = sin(a), c = cos(a);
                return mat2(c, -s, s, c);
            }

            // 2D Box SDF (For camera corridor)
            float sdBox2D(vec2 p, vec2 b) {
                vec2 d = abs(p) - b;
                return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
            }

            // 3D Box SDF
            float sdBox(vec3 p, vec3 b) {
                vec3 q = abs(p) - b;
                return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
            }

            // Global variable for optimization
            mat2 g_fractalRot;

            // --- MASSIVE INDUSTRIAL FRACTAL MATH ---
            float map(vec3 p) {
                // Optimization 2: Removed p.z offset from here. Handled by camera origin.
                
                // 1. Grid repeating cells
                vec3 q = mod(p, 4.0) - 2.0;
                
                // 2. Base structure
                float d = sdBox(q, vec3(2.0));
                
                // 3. Carve main intersections
            float baseCross = min(max(abs(q.x), abs(q.y)), min(max(abs(q.y), abs(q.z)), max(abs(q.x), abs(q.z)))) - u_carveSize;
            d = max(d, -baseCross);

            // 4. KIFS Details
            float s = 1.0;
            float invS = 1.0; // Optimization 3: using inverse scale
            vec3 fp = p; 
            
            // Dynamic iterations and parameters based on UI
            for(int i = 0; i < 6; i++) { 
                if(i >= u_iterations) break;
                
                vec3 a = mod(fp * s, 2.0) - 1.0;
                s *= u_fractalScale; 
                invS /= u_fractalScale; 
                vec3 r = abs(1.0 - 3.0 * abs(a));
                
                // Optimization 1: Using pre-calculated rotation matrix
                r.xy *= g_fractalRot; 
                r -= u_fractalOffset; 
                
                float da = max(r.x, r.y);
                float db = max(r.y, r.z);
                float dc = max(r.z, r.x);
                // Optimization 3: Multiply instead of divide
                float crossVolume = (min(da, min(db, dc)) - 1.0) * invS;
                d = max(d, -crossVolume);
            }

            // 5. Protected Camera Corridor
            float corridor = sdBox2D(p.xy, vec2(1.0)); 
                d = max(d, -corridor);
                
                return d;
            }

            // --- RAYMARCHING ---
            float rayMarch(vec3 ro, vec3 rd) {
                float dO = 0.0;
                for(int i = 0; i < MAX_STEPS; i++) {
                    vec3 p = ro + rd * dO;
                    float dS = map(p);
                    
                    // LIQUID DEFORMATION FIX:
                    // Strict, constant surface distance. Completely removes dynamic LOD scaling.
                    // This forces the engine to find the exact solid boundary, eliminating
                    // the melting/wobbling silhouette at grazing angles.
                    float surfDist = 0.0005; 
                    
                    if(dO > MAX_DIST || abs(dS) < surfDist) break;
                    
                    // Safe step multiplier
                    dO += dS * 0.55; 
                }
                return dO;
            }

            // --- NORMALS & AO ---
            // Removed distance parameter. Normals are now computed with absolute rigid precision.
            vec3 getNormal(vec3 p) {
                // Epsilon increased to 0.003 to create a micro-bevel effect.
                // This forces the crisp edges to catch highlights and look highly detailed.
                vec2 e = vec2(0.003, 0.0); 
                vec3 n = map(p) - vec3(
                    map(p - e.xyy),
                    map(p - e.yxy),
                    map(p - e.yyx)
                );
                return normalize(n);
            }

            float calcAO(vec3 p, vec3 n) {
                float occ = 0.0;
                float sca = 1.0;
                for(int i = 0; i < 5; i++) {
                    float hr = 0.05 + 0.15 * float(i); 
                    vec3 aopos = n * hr + p;
                    float dd = map(aopos);
                    occ += -(dd - hr) * sca;
                    sca *= 0.8;
                }
                return clamp(1.0 - 2.0 * occ, 0.0, 1.0);
            }

            void main() {
                // Optimization 1: Pre-calculate the rotation matrix ONCE per pixel
                g_fractalRot = rot(u_fractalRotation);

                vec2 uv = (vUv - 0.5) * 2.0;
                uv.x *= u_resolution.x / u_resolution.y;

                vec3 ro = vec3(0.0, 0.0, -3.0); 
                
                // Optimization 2: Translate camera origin instead of all space in map()
                ro.z -= u_time * u_speed * u_flyDirection;

                vec3 rd = normalize(vec3(uv, 1.0));
                rd.xy *= rot(sin(u_time * 0.2) * 0.05);

                float d = rayMarch(ro, rd);
                vec3 color = vec3(0.0);

                if(d < MAX_DIST) {
                    vec3 p = ro + rd * d;
                    // Normals calculate perfectly sharp structure
                    vec3 n = getNormal(p);
                    float ao = calcAO(p, n);

                    // Material
                    vec3 albedo = vec3(0.06, 0.065, 0.07);

                    // Lighting
                    vec3 l1_dir = normalize(vec3(1.0, 1.5, -0.5)); 
                    vec3 l1_col = u_colorKey * 1.5;
                    float dif1 = max(dot(n, l1_dir), 0.0);
                    
                    vec3 l2_dir = normalize(vec3(-1.0, -1.0, 1.0)); 
                    vec3 l2_col = u_colorFill * 0.8;
                    float dif2 = max(dot(n, l2_dir), 0.0);

                    // Specular
                    vec3 viewDir = normalize(ro - p);
                    vec3 h1 = normalize(l1_dir + viewDir);
                    float spec1 = pow(max(dot(n, h1), 0.0), 32.0);
                    
                    vec3 h2 = normalize(l2_dir + viewDir);
                    float spec2 = pow(max(dot(n, h2), 0.0), 32.0);

                    vec3 lighting = (dif1 * l1_col + dif2 * l2_col) * ao;
                    vec3 specular = (spec1 * l1_col + spec2 * l2_col) * ao;

                    color = albedo * lighting + specular;

                    // Atmospheric Colored Fog
                    float fogFactor = exp(-u_fogDensity * d);
                    color = mix(u_fogColor, color, fogFactor);
                } else {
                    color = u_fogColor;
                }

                // Post-Processing
                color *= 1.3; 
                color = color / (1.0 + color); 
                color = pow(color, vec3(1.0 / 2.2)); 

                gl_FragColor = vec4(color, 1.0);
            }
        `;

        // --- 5. Object Creation ---
        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms
        });

        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- 6. lil-gui Setup ---
        const gui = new GUI({ title: 'Scene Configuration' });
        
        const params = {
            fogColor: uniforms.u_fogColor.value.getHex(),
            fogDensity: uniforms.u_fogDensity.value,
            cameraSpeed: uniforms.u_speed.value,
            inverseFly: true,
            dpr: 0.8,
            iterations: uniforms.u_iterations.value,
            fractalScale: uniforms.u_fractalScale.value,
            fractalRotation: uniforms.u_fractalRotation.value,
            offsetX: uniforms.u_fractalOffset.value.x,
            offsetY: uniforms.u_fractalOffset.value.y,
            offsetZ: uniforms.u_fractalOffset.value.z,
            carveSize: uniforms.u_carveSize.value,
            colorKey: uniforms.u_colorKey.value.getHex(),
            colorFill: uniforms.u_colorFill.value.getHex()
        };

        const renderFolder = gui.addFolder('Rendering');
        renderFolder.add(params, 'dpr', 0.5, 2.0, 0.1).name('Pixel Ratio (DPR)').onChange(v => renderer.setPixelRatio(v));

        const envFolder = gui.addFolder('Environment & Fog');
        envFolder.addColor(params, 'fogColor').name('Atmosphere Color').onChange(v => uniforms.u_fogColor.value.setHex(v));
        envFolder.add(params, 'fogDensity', 0.0, 0.2, 0.001).name('Fog Density').onChange(v => uniforms.u_fogDensity.value = v);
        
        const lightFolder = gui.addFolder('Lighting');
        lightFolder.addColor(params, 'colorKey').name('Key Light').onChange(v => uniforms.u_colorKey.value.setHex(v));
        lightFolder.addColor(params, 'colorFill').name('Fill Light').onChange(v => uniforms.u_colorFill.value.setHex(v));
        
        const camFolder = gui.addFolder('Movement');
        camFolder.add(params, 'cameraSpeed', 0.0, 5.0, 0.1).name('Tunnel Speed').onChange(v => uniforms.u_speed.value = v);
        camFolder.add(params, 'inverseFly').name('Inverse Fly').onChange(v => uniforms.u_flyDirection.value = v ? -1.0 : 1.0);

        const fracFolder = gui.addFolder('Fractal Complexity');
        fracFolder.add(params, 'iterations', 1, 6, 1).name('Iterations').onChange(v => uniforms.u_iterations.value = v);
        fracFolder.add(params, 'fractalScale', 1.0, 4.0, 0.1).name('Scale Multiplier').onChange(v => uniforms.u_fractalScale.value = v);
        fracFolder.add(params, 'fractalRotation', 0.0, 1.0, 0.01).name('Chaos (Rotation)').onChange(v => uniforms.u_fractalRotation.value = v);
        fracFolder.add(params, 'offsetX', 0.0, 1.0, 0.01).name('Offset X').onChange(v => uniforms.u_fractalOffset.value.x = v);
        fracFolder.add(params, 'offsetY', 0.0, 1.0, 0.01).name('Offset Y').onChange(v => uniforms.u_fractalOffset.value.y = v);
        fracFolder.add(params, 'offsetZ', 0.0, 1.0, 0.01).name('Offset Z').onChange(v => uniforms.u_fractalOffset.value.z = v);
        fracFolder.add(params, 'carveSize', 0.5, 2.0, 0.01).name('Base Carve Size').onChange(v => uniforms.u_carveSize.value = v);

        // Collapse the GUI panel by default
        gui.close();

        // --- 7. Event Listeners ---
        window.addEventListener('resize', () => {
            renderer.setSize(window.innerWidth, window.innerHeight);
            uniforms.u_resolution.value.set(window.innerWidth, window.innerHeight);
        });

        // --- 8. Animation Loop ---
        const clock = new THREE.Clock();
        function animate() {
            requestAnimationFrame(animate);
            uniforms.u_time.value = clock.getElapsedTime();
            renderer.render(scene, camera);
        }
        
        animate();