        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
        import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
        import GUI from 'three/addons/libs/lil-gui.module.min.js';

        let scene, camera, renderer, composer, controls;
        let mainMesh, geometry, material, videoTexture, videoElement;
        let bloomPass;
        
        const params = {
            backgroundColor: '#0a0a0a',
            geometryType: 'Chamfer Cylinder', 
            
            // Texture Settings
            videoOpacity: 0.96,
            seamless: true,     
            texRepeatX: 5.0,    
            texRepeatY: 1.0,
            texOffsetX: 0.0,
            texOffsetY: 0,
            texRotation: 0,
            texCenterX: 0.5,
            texCenterY: 0.5,
            
            // Animation
            autoRotate: true,
            rotateSpeed: 0.3,
            
            // Bloom
            bloomEnabled: true,
            bloomThreshold: 0.06,
            bloomStrength: 0.177,
            bloomRadius: 0.12,
            
            uploadVideo: () => { document.getElementById('videoInput').click(); }
        };

        const geometryList = [
            'Box', 'Sphere', 'Plane', 'Circle', 
            'Cone', 'Cylinder', 'Capsule', 'Torus',
            'Icosahedron', 'Dodecahedron', 'Octahedron', 'Tetrahedron',
            'Rounded Box', 'Geodesic Sphere', 'Chamfer Cylinder',
            'Torus Knot (Standard)', 'Torus Knot (Complex)', 'Torus Knot (Flower)', 
            'Twisted Ring', 'Tube Spiral', 'Lathe Vase', 'Lathe Ripple', 'Star Extrusion', 'Cog Extrusion',
            'Diamond', 'Crystal', 'Abstract Knot 1', 'Abstract Knot 2'
        ];

        init();
        animate();

        function init() {
            // Scene
            scene = new THREE.Scene();
            scene.background = new THREE.Color(params.backgroundColor);

            // Camera
            camera = new THREE.PerspectiveCamera(30, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 0, 9);

            // Renderer
            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(window.devicePixelRatio);
            renderer.toneMapping = THREE.ReinhardToneMapping;
            document.body.appendChild(renderer.domElement);

            // Controls
            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.target.set(0, 0, 0); 

            // Video Texture
            setupVideo();

            // Material
            material = new THREE.MeshPhysicalMaterial({
                map: videoTexture,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: params.videoOpacity,
                roughness: 0.2,
                metalness: 0.1,
                clearcoat: 0.3,
                clearcoatRoughness: 0.1,
            });

            // Geometry
            updateGeometry();

            // Lights
            const ambient = new THREE.AmbientLight(0xffffff, 3.5);
            scene.add(ambient);
            const spot = new THREE.SpotLight(0xffffff, 70);
            spot.position.set(10, 15, 10);
            spot.angle = Math.PI / 5;
            spot.penumbra = 0.5;
            scene.add(spot);
            const rimLight = new THREE.PointLight(0x4444ff, 8);
            rimLight.position.set(-10, 0, -8);
            scene.add(rimLight);

            // Post Processing
            setupPostProcessing();

            // GUI
            setupGUI();

            // Listeners
            window.addEventListener('resize', onWindowResize);
            document.getElementById('videoInput').addEventListener('change', handleFileUpload);
            
            setTimeout(() => { document.getElementById('loading').style.opacity = 0; }, 800);
        }

        function setupVideo() {
            videoElement = document.createElement('video');
            videoElement.crossOrigin = 'anonymous';
            videoElement.loop = true;
            videoElement.muted = true;
            videoElement.playsInline = true;
            // A texture with lines works well to test seams
            videoElement.src = 'https://cdn-cf-east.streamable.com/video/mp4/bxvrh3.mp4?Expires=1769629369384&Key-Pair-Id=APKAIEYUVEN4EVB2OKEQ&Signature=A9DJXIdDYYAN0oMC4La2TaDtDDHX~U9nlE-63shdim8Yg2ZzMUfH2HVHWFQDFNQAllY9x6~25xdzIUVjnvEQlj9mYhzCgrE~-sWHY9s1GjDm6S3kDi~z4lToyGF0NqZLe7e~oUzzrzOGkhwtzIcGr6~zROZCtye4JLEwMVRlxAcFFyfMi7B082lVpzk2ge7v7rxSz2CYiBkNfUi2Dooog8GKWjZDAaD9B6bIb3mjaMFWbPsualWwC2AgWiCmOwqfr8zvxA95DxM9VCBktql0ZLoUQ6cpuUFYCsSJYA5ALwrot9v9~O-Q9VPvpW8IzOMmRDtT6255EViijmNyOIv8Sw__'; 
            videoElement.play();

            videoTexture = new THREE.VideoTexture(videoElement);
            videoTexture.colorSpace = THREE.SRGBColorSpace;
            videoTexture.minFilter = THREE.LinearFilter;
            videoTexture.magFilter = THREE.LinearFilter;
            
            // Initial Texture Update to apply repeat settings
            updateTex();
        }

        function handleFileUpload(event) {
            const file = event.target.files[0];
            if (file) {
                const url = URL.createObjectURL(file);
                videoElement.src = url;
                videoElement.play();
            }
        }

        function setupPostProcessing() {
            const renderScene = new RenderPass(scene, camera);
            bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 1.5, 0.4, 0.85);
            bloomPass.threshold = params.bloomThreshold;
            bloomPass.strength = params.bloomStrength;
            bloomPass.radius = params.bloomRadius;
            bloomPass.enabled = params.bloomEnabled;

            composer = new EffectComposer(renderer);
            composer.addPass(renderScene);
            composer.addPass(bloomPass);
        }

        function createStarShape(points = 5, outer = 2, inner = 1) {
            const shape = new THREE.Shape();
            const angleStep = Math.PI / points;
            for (let i = 0; i < 2 * points; i++) {
                const r = (i % 2 === 0) ? outer : inner;
                const a = i * angleStep;
                const x = Math.cos(a) * r;
                const y = Math.sin(a) * r;
                if (i === 0) shape.moveTo(x, y);
                else shape.lineTo(x, y);
            }
            shape.closePath();
            return shape;
        }

        function updateGeometry() {
            if (mainMesh) {
                scene.remove(mainMesh);
                geometry.dispose();
            }

            const sH = 128; // High segments for smooth surface

            switch (params.geometryType) {
                case 'Box': geometry = new THREE.BoxGeometry(3, 3, 3, 10, 10, 10); break;
                case 'Sphere': geometry = new THREE.SphereGeometry(2, sH, sH); break;
                case 'Plane': geometry = new THREE.PlaneGeometry(4, 3, 20, 20); break;
                case 'Circle': geometry = new THREE.CircleGeometry(2, sH); break;
                // Cone often shows the seam clearly
                case 'Cone': geometry = new THREE.ConeGeometry(1.8, 3.5, sH, 10, true); break; 
                case 'Cylinder': geometry = new THREE.CylinderGeometry(1.5, 1.5, 3, sH, 10, true); break;
                case 'Capsule': geometry = new THREE.CapsuleGeometry(1, 2, 10, 30); break;
                case 'Torus': geometry = new THREE.TorusGeometry(2, 0.6, 40, sH); break;
                case 'Icosahedron': geometry = new THREE.IcosahedronGeometry(2.2, 0); break;
                case 'Dodecahedron': geometry = new THREE.DodecahedronGeometry(2.2, 0); break;
                case 'Octahedron': geometry = new THREE.OctahedronGeometry(2.2, 0); break;
                case 'Tetrahedron': geometry = new THREE.TetrahedronGeometry(2.5, 0); break;
                case 'Rounded Box': geometry = new RoundedBoxGeometry(3, 3, 3, 8, 0.5); break;
                case 'Geodesic Sphere': geometry = new THREE.IcosahedronGeometry(2.2, 4); break;
                case 'Chamfer Cylinder': geometry = new THREE.CylinderGeometry(1.5, 1.5, 3, 5, 1); break;
                case 'Torus Knot (Standard)': geometry = new THREE.TorusKnotGeometry(1.5, 0.4, 250, 40); break;
                case 'Torus Knot (Complex)': geometry = new THREE.TorusKnotGeometry(1.5, 0.3, 300, 50, 4, 7); break;
                case 'Torus Knot (Flower)': geometry = new THREE.TorusKnotGeometry(1.2, 0.5, 300, 50, 3, 8); break;
                case 'Twisted Ring': geometry = new THREE.TorusGeometry(2, 0.5, 50, 200); break;
                case 'Tube Spiral':
                    const pathSpiral = new THREE.CatmullRomCurve3([
                        new THREE.Vector3(0, -3, 0), new THREE.Vector3(1.5, -1.5, 0),
                        new THREE.Vector3(-1.5, 0, 1.5), new THREE.Vector3(1.5, 1.5, 0), new THREE.Vector3(0, 3, 0)
                    ]);
                    geometry = new THREE.TubeGeometry(pathSpiral, 150, 0.6, 20, false); break;
                
                case 'Lathe Vase':
                    const ptsVase = [];
                    for (let i = 0; i < 20; i++) ptsVase.push(new THREE.Vector2(Math.sin(i * 0.3) * 0.8 + 0.5, (i - 10) * 0.3));
                    geometry = new THREE.LatheGeometry(ptsVase, 64); break;
                case 'Lathe Ripple':
                    const ptsRip = [];
                    for(let i=0; i<=20; i++) ptsRip.push(new THREE.Vector2(1 + Math.sin(i)*0.2, (i-10)*0.3));
                    geometry = new THREE.LatheGeometry(ptsRip, 64); break;
                case 'Star Extrusion':
                    const starShape = createStarShape(5, 2, 1);
                    geometry = new THREE.ExtrudeGeometry(starShape, { depth: 1, bevelEnabled: true, bevelSegments: 4, bevelSize: 0.1, bevelThickness: 0.1 });
                    geometry.center(); break;
                case 'Cog Extrusion':
                    const cogShape = createStarShape(8, 2, 1.8);
                    geometry = new THREE.ExtrudeGeometry(cogShape, { depth: 0.5, bevelEnabled: true, bevelSegments: 2 });
                    geometry.center(); break;
                case 'Diamond':
                    geometry = new THREE.OctahedronGeometry(2, 0); geometry.scale(1, 1.5, 1); break;
                case 'Crystal': geometry = new THREE.ConeGeometry(1.5, 4, 6); break;
                case 'Abstract Knot 1': geometry = new THREE.TorusKnotGeometry(1.2, 0.3, 300, 50, 5, 2); break;
                case 'Abstract Knot 2': geometry = new THREE.TorusKnotGeometry(1.2, 0.6, 300, 50, 2, 5); break;
                default: geometry = new THREE.BoxGeometry(3, 3, 3);
            }

            mainMesh = new THREE.Mesh(geometry, material);
            scene.add(mainMesh);
        }

        function setupGUI() {
            const gui = new GUI({ title: 'Scene Settings', width: 340 });

            const folderGeneral = gui.addFolder('General');
            folderGeneral.addColor(params, 'backgroundColor').name('Background').onChange(val => scene.background.set(val));
            folderGeneral.add(params, 'geometryType', geometryList).name('Geometry Shape').onChange(updateGeometry);
            folderGeneral.add(params, 'uploadVideo').name('📂 Select Local Video');

            const folderTexture = gui.addFolder('Texture / Video');
            folderTexture.add(params, 'videoOpacity', 0, 1).name('Opacity').onChange(val => material.opacity = val);
            
            // KEY FEATURE: SEAMLESS MIRROR
            folderTexture.add(params, 'seamless').name('Seamless (Mirror)').onChange(updateTex);
            
            folderTexture.add(params, 'texRepeatX', 0.1, 7).name('Repeat X').onChange(updateTex);
            folderTexture.add(params, 'texRepeatY', 0.1, 6).name('Repeat Y').onChange(updateTex);
            folderTexture.add(params, 'texOffsetX', -1, 1).name('Offset X').onChange(updateTex);
            folderTexture.add(params, 'texOffsetY', -1, 1).name('Offset Y').onChange(updateTex);
            folderTexture.add(params, 'texRotation', 0, Math.PI * 2).name('Rotation').onChange(updateTex);

            const folderAnim = gui.addFolder('Animation');
            folderAnim.add(params, 'autoRotate').name('Auto Spin (Y-Axis)');
            folderAnim.add(params, 'rotateSpeed', 0, 3).name('Speed');

            const folderBloom = gui.addFolder('Post Processing (Bloom)');
            folderBloom.add(params, 'bloomEnabled').name('Enable Effect').onChange(val => bloomPass.enabled = val);
            folderBloom.add(params, 'bloomStrength', 0, 3).name('Intensity').onChange(val => bloomPass.strength = val);
            folderBloom.add(params, 'bloomRadius', 0, 1).name('Radius').onChange(val => bloomPass.radius = val);
            folderBloom.add(params, 'bloomThreshold', 0, 1).name('Threshold').onChange(val => bloomPass.threshold = val);

            folderGeneral.open();
            folderTexture.open();
        }

        function updateTex() {
            if (!videoTexture) return;
            
            videoTexture.repeat.set(params.texRepeatX, params.texRepeatY);
            videoTexture.offset.set(params.texOffsetX, params.texOffsetY);
            videoTexture.rotation = params.texRotation;
            videoTexture.center.set(params.texCenterX, params.texCenterY);
            
            // MAGIC FIX FOR SEAMS
            if (params.seamless) {
                // MirroredRepeatWrapping flips the texture every other time it repeats
                // This makes the edges match perfectly (End of Image -> End of Mirrored Image)
                videoTexture.wrapS = THREE.MirroredRepeatWrapping;
                videoTexture.wrapT = THREE.MirroredRepeatWrapping;
            } else {
                // Standard repeating (can cause hard lines/seams)
                videoTexture.wrapS = THREE.RepeatWrapping;
                videoTexture.wrapT = THREE.RepeatWrapping;
            }
            
            videoTexture.needsUpdate = true;
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        }

        function animate() {
            requestAnimationFrame(animate);

            if (params.autoRotate && mainMesh) {
                mainMesh.rotation.y += 0.01 * params.rotateSpeed;
            }

            controls.update();

            if (params.bloomEnabled) {
                composer.render();
            } else {
                renderer.render(scene, camera);
            }
        }