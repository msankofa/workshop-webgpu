# Dither / ASCII Effect Pro – Video Version: https://codepen.io/sabosugi/full/PwzWLLw  – Support me by PayPal: https://paypal.com/paypalme/sabosugi

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/bNegbmy](https://codepen.io/sabosugi/pen/bNegbmy).

