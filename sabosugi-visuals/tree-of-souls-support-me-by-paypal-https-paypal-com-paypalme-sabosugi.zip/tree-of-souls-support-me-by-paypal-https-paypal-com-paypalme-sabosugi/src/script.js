        // Setup Three.js Scene, Camera, and Renderer
        const scene = new THREE.Scene();
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
        camera.position.z = 1;

        const renderer = new THREE.WebGLRenderer({ antialias: false });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // Settings Object for lil-gui
        const params = {
            dpr: 0.7,
            camSpeed: 0.2,
            morphSpeed: 1.0,
            iterations: 16,
            rotX: 0.57,
            rotY: 2.31,
            rotZ: 0.47,
            kMult: 8.55,
            clampMin: -0.65,
            clampMax: 79.46,
            expandX: 0.23,
            expandY: 1.75,
            expandZ: 0.65,
            thickness: -2.06,
            bounds: 5.9
        };

        // Initialize Pixel Ratio
        renderer.setPixelRatio(params.dpr);

        // Uniforms for the Shader
        const uniforms = {
            u_time: { value: 0.0 },
            u_resolution: { value: new THREE.Vector2(window.innerWidth * params.dpr, window.innerHeight * params.dpr) },
            u_camSpeed: { value: params.camSpeed },
            u_morphSpeed: { value: params.morphSpeed },
            u_iterations: { value: params.iterations },
            u_rot: { value: new THREE.Vector3(params.rotX, params.rotY, params.rotZ) },
            u_kMult: { value: params.kMult },
            u_clamp: { value: new THREE.Vector2(params.clampMin, params.clampMax) },
            u_expand: { value: new THREE.Vector3(params.expandX, params.expandY, params.expandZ) },
            u_thickness: { value: params.thickness },
            u_bounds: { value: params.bounds }
        };

        // Fullscreen Quad Geometry
        const geometry = new THREE.PlaneGeometry(2, 2);

        // Vertex Shader
        const vertexShader = `
            void main() {
                gl_Position = vec4(position, 1.0);
            }
        `;

        // Fragment Shader (Converted from Shadertoy GLSL)
        const fragmentShader = `
            precision highp float;

            uniform float u_time;
            uniform vec2 u_resolution;

            // GUI Parameters
            uniform float u_camSpeed;
            uniform float u_morphSpeed;
            uniform int u_iterations;
            uniform vec3 u_rot;
            uniform float u_kMult;
            uniform vec2 u_clamp;
            uniform vec3 u_expand;
            uniform float u_thickness;
            uniform float u_bounds;

            // 2D Rotation matrix
            mat2 rot(float a) {
                float s = sin(a), c = cos(a);
                return mat2(c, -s, s, c);
            }

            // Distance function: "Fractal Lotus" / Crystal KIFS
            vec2 map(vec3 p) {
                vec3 q = p;
                float scale = 2.3;
                
                // Smooth, organic morphing over time
                q += vec3(sin(u_time * 0.4 * u_morphSpeed) * 0.15, cos(u_time * 0.3 * u_morphSpeed) * 0.15, 0.0);
                
                // Kaleidoscopic Iterated Function System (KIFS)
                for(int i = 0; i < 20; i++) {
                    if (i >= u_iterations) break;

                    // Fold space to create complex symmetry
                    q = abs(q);
                    
                    // Rotation angles for crystalline web
                    q.xy *= rot(u_rot.x);
                    q.xz *= rot(u_rot.y);
                    q.yz *= rot(u_rot.z);
                    
                    // Spherical Inversion mapping
                    float r2 = dot(q, q);
                    
                    // Clamp boundaries for smooth geometry
                    float k = u_kMult / clamp(r2, u_clamp.x, u_clamp.y);
                    
                    // Scale and transform
                    q *= k;
                    scale *= k;
                    
                    // Expansion vector pushing space into lotus shape
                    q -= u_expand;
                }
                
                // Extract continuous smooth cylindrical rays
                float rays = (length(q.xy) - u_thickness) / scale;
                
                // Spherical bounding volume
                float bounds = length(p) - u_bounds;
                
                // Intersect rays with bounds
                float d = max(rays, bounds);
                
                return vec2(d, 0.0);
            }

            void main() {
                // Normalize pixel coordinates (-1 to 1)
                vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution.xy) / u_resolution.y;
                
                // Cinematic camera with orbit
                vec3 ro = vec3(sin(u_time * u_camSpeed) * 3.2, 
                               sin(u_time * u_camSpeed * 0.75) * 1.0, 
                               cos(u_time * u_camSpeed) * 3.2);
                               
                // Camera targeting logic
                vec3 target = vec3(0.0);
                vec3 fwd = normalize(target - ro);
                vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), fwd));
                vec3 up = cross(fwd, right);
                
                // Subtle camera roll
                vec2 rolledUV = uv * rot(sin(u_time * 0.1) * 0.15);
                
                // Ray direction
                vec3 rd = normalize(fwd + right * rolledUV.x + up * rolledUV.y);
                
                // Raymarching initialization
                float t = 0.0;
                vec3 glow = vec3(0.0);
                
                // Raymarching loop
                for(int i = 0; i < 75; i++) {
                    vec3 p = ro + rd * t;
                    float d = map(p).x;
                    
                    // Holographic base color logic
                    float holoDriver = length(p) * 0.5 - dot(normalize(p), rd) * 0.6 + u_time * 0.2;
                    
                    vec3 baseColor = vec3(0.55, 0.50, 0.65);
                    vec3 colorAmp  = vec3(0.45, 0.50, 0.40);
                    vec3 freq      = vec3(1.0, 1.0, 1.0);
                    vec3 phase     = vec3(0.0, 0.33, 0.67);
                    
                    vec3 currentCol = baseColor + colorAmp * cos(6.28318 * (freq * holoDriver + phase));
                    
                    // Warm Gold/Amber core glow
                    currentCol += vec3(0.5, 0.25, 0.0) * exp(-abs(length(p)) * 2.2);
                    
                    // White data pulses
                    float pulseWave = sin(p.x * 12.0 - u_time * 1.5) * sin(p.y * 10.0 + u_time * 2.0) * sin(length(p) * 12.0 - u_time * 0.5);
                    float sharpPulse = pow(max(0.6, pulseWave), 15.0);
                    
                    currentCol += vec3(3.5) * sharpPulse * exp(-abs(d) * 40.0);
                    
                    // Volumetric glow
                    float halo = 0.005 / (0.002 + abs(d));
                    float highlight = 0.001 / (0.0001 + d * d);
                    
                    glow += currentCol * (halo + highlight * 0.15);
                    
                    t += d * 0.6;
                    
                    if(t > 7.5) break;
                }
                
                // Global intensity
                vec3 color = glow * 0.056;
                
                // Deep vignette
                color *= 1.0 - 0.3 * length(uv);
                
                // ACES Tonemapping
                color = (color * (2.51 * color + 0.03)) / (color * (2.43 * color + 0.59) + 0.14);
                
                // 3D Particles Layer
                vec3 particles = vec3(0.0);
                
                for(float i = 0.0; i < 100.0; i++) {
                    vec3 h = fract(sin(vec3(i, i * 13.3, i * 31.7)) * 43758.5453);
                    
                    vec3 dir = normalize(h * 2.0 - 1.0);
                    float radius = 1.3 + h.x * 1.8;
                    vec3 pos = dir * radius;
                    
                    pos.xy *= rot(u_time * 0.12 + h.y * 3.0);
                    pos.xz *= rot(u_time * 0.18 + h.z * 3.0);
                    
                    vec3 w = pos - ro;
                    float proj = dot(rd, w);
                    
                    if(proj > 0.0 && proj < t) {
                        float dRay = length(w - rd * proj);
                        float size = 0.0025 + h.z * 0.029;
                        
                        float core = smoothstep(size, size * 0.4, dRay);
                        float particleGlow = exp(-dRay * 180.0) * 0.4;
                        
                        particles += (core + particleGlow) * vec3(1.0, 0.98, 0.95);
                    }
                }
                
                color += particles;
                
                // Gamma correction
                color = pow(color, vec3(1.0 / 2.2));
                
                gl_FragColor = vec4(color, 1.0);
            }
        `;

        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms
        });

        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // GUI Setup
        const gui = new lil.GUI({ title: 'Scene Settings' });
        
        gui.add(params, 'dpr', 0.1, 2.0, 0.1).name('Resolution (DPR)').onChange(v => {
            renderer.setPixelRatio(v);
            onWindowResize(); // Update resolution uniform
        });

        const camFolder = gui.addFolder('Camera & Animation');
        camFolder.add(params, 'camSpeed', 0.0, 1.0).name('Camera Speed').onChange(v => uniforms.u_camSpeed.value = v);
        camFolder.add(params, 'morphSpeed', 0.0, 3.0).name('Morph Speed').onChange(v => uniforms.u_morphSpeed.value = v);

        const mathFolder = gui.addFolder('Fractal Math (KIFS)');
        mathFolder.add(params, 'iterations', 1, 20, 1).name('Iterations').onChange(v => uniforms.u_iterations.value = v);
        mathFolder.add(params, 'rotX', 0.0, 6.28).name('Rotation X').onChange(v => uniforms.u_rot.value.x = v);
        mathFolder.add(params, 'rotY', 0.0, 6.28).name('Rotation Y').onChange(v => uniforms.u_rot.value.y = v);
        mathFolder.add(params, 'rotZ', 0.0, 6.28).name('Rotation Z').onChange(v => uniforms.u_rot.value.z = v);
        mathFolder.add(params, 'kMult', 1.0, 15.0).name('Multiplier').onChange(v => uniforms.u_kMult.value = v);
        mathFolder.add(params, 'clampMin', -2.0, 2.0).name('Clamp Min').onChange(v => uniforms.u_clamp.value.x = v);
        mathFolder.add(params, 'clampMax', 10.0, 100.0).name('Clamp Max').onChange(v => uniforms.u_clamp.value.y = v);

        const geoFolder = gui.addFolder('Fractal Geometry');
        geoFolder.add(params, 'expandX', 0.0, 3.0).name('Expand X').onChange(v => uniforms.u_expand.value.x = v);
        geoFolder.add(params, 'expandY', 0.0, 3.0).name('Expand Y').onChange(v => uniforms.u_expand.value.y = v);
        geoFolder.add(params, 'expandZ', 0.0, 3.0).name('Expand Z').onChange(v => uniforms.u_expand.value.z = v);
        geoFolder.add(params, 'thickness', -5.0, 1.0).name('Ray Thickness').onChange(v => uniforms.u_thickness.value = v);
        geoFolder.add(params, 'bounds', 1.0, 10.0).name('Bounding Sphere').onChange(v => uniforms.u_bounds.value = v);

        // Collapse GUI by default
        gui.close();

        // Handle Window Resize
        function onWindowResize() {
            renderer.setSize(window.innerWidth, window.innerHeight);
            const dpr = renderer.getPixelRatio();
            uniforms.u_resolution.value.set(window.innerWidth * dpr, window.innerHeight * dpr);
        }
        window.addEventListener('resize', onWindowResize);

        // Animation Loop
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            uniforms.u_time.value = clock.getElapsedTime();
            renderer.render(scene, camera);
        }
        
        animate();