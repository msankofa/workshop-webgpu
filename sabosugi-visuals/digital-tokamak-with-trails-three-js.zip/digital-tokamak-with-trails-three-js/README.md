# Digital Tokamak with Trails – Three.js

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/jErebjR](https://codepen.io/sabosugi/pen/jErebjR).

