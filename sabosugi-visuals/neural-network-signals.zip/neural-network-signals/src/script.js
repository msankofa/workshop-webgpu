        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import GUI from 'lil-gui';

        // --- Scene Setup ---
        const scene = new THREE.Scene();
        // Set background color matching the reference image
        scene.background = new THREE.Color('#000000'); 

        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.z = 25;

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        document.body.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;

        // --- Configuration Parameters ---
        const params = {
            count: 150,
            length: 25.0,
            color: '#e2e8e0',
            bgColor: '#000000',
            waviness: 1.5,
            waveFrequency: 0.3,
            opacity: 0.4,
            signalCount: 100,
            signalSpeed: 0.7,
            rotateWithCursor: false
        };

        // Group to hold all lines for easy rotation/management
        const linesGroup = new THREE.Group();
        scene.add(linesGroup);

        let linePaths = []; // Store paths for animating impulses
        let impulsesPoints; 
        let impulseData = [];
        
        // Helper to create round points (circles) for impulses
        function createCircleTexture() {
            const canvas = document.createElement('canvas');
            canvas.width = 16;
            canvas.height = 16;
            const ctx = canvas.getContext('2d');
            ctx.beginPath();
            ctx.arc(8, 8, 8, 0, Math.PI * 2);
            ctx.fillStyle = 'white';
            ctx.fill();
            return new THREE.CanvasTexture(canvas);
        }
        const circleTexture = createCircleTexture();

        // --- Generation Function ---
        let lineMaterial;

        function generateLines() {
            // Clear existing lines
            while(linesGroup.children.length > 0){ 
                const child = linesGroup.children[0];
                linesGroup.remove(child); 
                child.geometry.dispose();
            }

            // Create or update material
            if (!lineMaterial) {
                lineMaterial = new THREE.LineBasicMaterial({
                    color: params.color,
                    transparent: true,
                    opacity: params.opacity,
                    blending: THREE.NormalBlending
                });
            } else {
                lineMaterial.color.set(params.color);
                lineMaterial.opacity = params.opacity;
            }

            const segments = 80; // Increased resolution for smoother lines
            linePaths = [];

            for (let i = 0; i < params.count; i++) {
                // Generate a random direction on a sphere
                const theta = Math.random() * Math.PI * 2;
                const phi = Math.acos(Math.random() * 2 - 1);
                
                const dirX = Math.sin(phi) * Math.cos(theta);
                const dirY = Math.sin(phi) * Math.sin(theta);
                const dirZ = Math.cos(phi);
                
                const baseDir = new THREE.Vector3(dirX, dirY, dirZ);

                // Create orthogonal vectors for wave offset calculation
                const u = new THREE.Vector3(baseDir.y, -baseDir.x, 0).normalize();
                if (u.lengthSq() < 0.001) {
                    u.set(0, baseDir.z, -baseDir.y).normalize();
                }
                const v = new THREE.Vector3().crossVectors(baseDir, u);

                // Calculate random frequencies scaled by the user parameter
                const baseFreq = params.waveFrequency;
                const freq1 = Math.random() * baseFreq + (baseFreq * 0.25);
                const freq2 = Math.random() * baseFreq + (baseFreq * 0.25);
                const phase1 = Math.random() * Math.PI * 2;
                const phase2 = Math.random() * Math.PI * 2;

                const points = [];

                for (let j = 0; j <= segments; j++) {
                    const t = j / segments; // 0.0 to 1.0
                    const distance = t * params.length;
                    
                    // Base position along the straight line
                    const currentPos = baseDir.clone().multiplyScalar(distance);

                    // Amplitude increases non-linearly towards the ends
                    const amplitude = params.waviness * Math.pow(t, 1.8);

                    // Calculate wavy offsets
                    const offsetU = u.clone().multiplyScalar(Math.sin(distance * freq1 + phase1) * amplitude);
                    const offsetV = v.clone().multiplyScalar(Math.cos(distance * freq2 + phase2) * amplitude);

                    // Apply offsets
                    currentPos.add(offsetU).add(offsetV);
                    points.push(currentPos);
                }

                linePaths.push(points); // Save path for impulses

                const geometry = new THREE.BufferGeometry().setFromPoints(points);
                const line = new THREE.Line(geometry, lineMaterial);
                linesGroup.add(line);
            }
            
            generateImpulses();
        }

        function generateImpulses() {
            if (impulsesPoints) {
                linesGroup.remove(impulsesPoints);
                impulsesPoints.geometry.dispose();
                impulsesPoints.material.dispose();
                impulsesPoints = null;
            }

            impulseData = [];
            const numImpulses = params.signalCount;
            
            if (numImpulses === 0) return;

            const positions = new Float32Array(numImpulses * 3);

            for (let i = 0; i < numImpulses; i++) {
                const lineIndex = Math.floor(Math.random() * params.count);
                impulseData.push({
                    lineIndex: lineIndex,
                    progress: Math.random(),
                    speed: 0.05 + Math.random() * 0.15, // Travel speed along line
                    direction: Math.random() > 0.5 ? 1 : -1
                });
                
                positions[i*3] = 0;
                positions[i*3+1] = 0;
                positions[i*3+2] = 0;
            }

            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

            const material = new THREE.PointsMaterial({
                color: params.color,
                size: 3, // 3px size
                sizeAttenuation: false, // keep size consistent regardless of distance
                map: circleTexture,
                transparent: true,
                alphaTest: 0.5
            });

            impulsesPoints = new THREE.Points(geometry, material);
            linesGroup.add(impulsesPoints);
        }

        // Initialize the first batch of lines
        generateLines();

        // --- GUI Setup (using lil-gui) ---
        const gui = new GUI({ title: 'Scene Settings' });
        
        gui.addColor(params, 'bgColor').name('Background Color').onChange(() => {
            scene.background.set(params.bgColor);
        });
        gui.add(params, 'count', 50, 1000, 10).name('Number of Lines').onChange(generateLines);
        gui.add(params, 'length', 5, 100, 0.5).name('Line Length').onChange(generateLines);
        gui.add(params, 'signalCount', 0, 1000, 10).name('Signal Count').onChange(generateImpulses);
        gui.add(params, 'signalSpeed', 0, 5, 0.1).name('Signal Speed');
        gui.add(params, 'rotateWithCursor').name('Rotate with Hover Cursor').onChange((v) => {
            controls.enabled = !v; // Disable manual orbit when hover rotation is active
        });
        gui.addColor(params, 'color').name('Line Color').onChange(() => {
            if (lineMaterial) lineMaterial.color.set(params.color);
            if (impulsesPoints) impulsesPoints.material.color.set(params.color);
        });
        
        // Extra visual settings grouped together
        const visualFolder = gui.addFolder('Advanced Visuals');
        visualFolder.add(params, 'waviness', 0, 5, 0.1).name('Waviness').onChange(generateLines);
        visualFolder.add(params, 'waveFrequency', 0.01, 2.0, 0.01).name('Wave Frequency').onChange(generateLines);
        visualFolder.add(params, 'opacity', 0.1, 1.0, 0.05).name('Opacity').onChange(() => {
            if (lineMaterial) lineMaterial.opacity = params.opacity;
        });
        visualFolder.close();

        // --- Mouse and Resize Handlers ---
        let mouseX = 0;
        let mouseY = 0;

        document.addEventListener('mousemove', (event) => {
            // Normalize mouse coordinates from -1 to 1
            mouseX = (event.clientX / window.innerWidth) * 2 - 1;
            mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
        });

        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            const delta = clock.getDelta();
            
            // Slowly rotate the entire structure
            linesGroup.rotation.y += 0.05 * delta;
            linesGroup.rotation.x += 0.025 * delta;

            if (params.rotateWithCursor) {
                // Move camera based on normalized cursor position
                const targetX = mouseX * 15; 
                const targetY = mouseY * 15; 
                
                camera.position.x += (targetX - camera.position.x) * 0.02;
                camera.position.y += (targetY - camera.position.y) * 0.02;
                camera.lookAt(scene.position);
            } else {
                controls.update();
            }

            // Animate moving impulses along lines
            if (impulsesPoints && linePaths.length > 0) {
                const positions = impulsesPoints.geometry.attributes.position.array;
                const segments = linePaths[0].length - 1;

                for (let i = 0; i < impulseData.length; i++) {
                    const data = impulseData[i];
                    data.progress += data.speed * params.signalSpeed * data.direction * delta;

                    // Bounce logic
                    if (data.progress >= 1.0) {
                        data.progress = 1.0;
                        data.direction = -1;
                    } else if (data.progress <= 0.0) {
                        data.progress = 0.0;
                        data.direction = 1;
                    }

                    // Linear interpolation between path points
                    const path = linePaths[data.lineIndex];
                    const exactIndex = data.progress * segments;
                    const index1 = Math.floor(exactIndex);
                    const index2 = Math.min(Math.ceil(exactIndex), segments);
                    const t = exactIndex - index1;

                    const p1 = path[index1];
                    const p2 = path[index2];

                    positions[i * 3] = p1.x + (p2.x - p1.x) * t;
                    positions[i * 3 + 1] = p1.y + (p2.y - p1.y) * t;
                    positions[i * 3 + 2] = p1.z + (p2.z - p1.z) * t;
                }
                impulsesPoints.geometry.attributes.position.needsUpdate = true;
            }

            controls.update();
            renderer.render(scene, camera);
        }

        animate();