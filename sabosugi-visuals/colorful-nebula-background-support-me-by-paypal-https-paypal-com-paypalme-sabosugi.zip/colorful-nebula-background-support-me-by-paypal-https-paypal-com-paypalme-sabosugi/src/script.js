import * as THREE from 'three';
import GUI from 'lil-gui';

// --- Global Context ---
const ctx = {
    cam: null,
    scene_graph: null,
    engine: null,
    shader_props: null,
    perf_clock: new THREE.Clock(),
    pixel_scale: Math.min(window.devicePixelRatio || 1, 0.8)
};

// --- GLSL Core ---
const glsl_fragment = `
    uniform vec3 u_screen;
    uniform float u_ticks;
    
    // Exposed GUI parameters
    uniform float u_time_mul;
    uniform float u_light_fade;
    uniform float u_loop_limit;
    uniform vec4 u_chroma_shift;
    uniform float u_core_radius;
    uniform float u_advance_base;
    uniform float u_noise_freq;
    uniform float u_scatter;

    void main() {
        vec2 fc = gl_FragCoord.xy;
        vec4 acc = vec4(0.0);
        
        float depth = 0.0;
        float step_val = 0.0;
        float t_scaled = u_ticks * u_time_mul;

        vec3 ray_dir = normalize(vec3(fc * 2.0 - u_screen.xy, -u_screen.y));

        for (float k = 0.0; k < 250.0; k++) {
            // Dynamic break condition
            if (k >= u_loop_limit) break;

            vec3 pos = depth * ray_dir;
            step_val = 1.0;

            // Space folding and noise generation
            for (int m = 0; m < 6; m++) {
                
                if (step_val > 8.9) break; 
                
                vec3 shift = pos.yzx * step_val * u_noise_freq;
                shift += depth * 0.2;
                shift += t_scaled;
                
                pos += cos(shift) / step_val;
                
                step_val *= 1.4285714; 
            }

            // Distance field calculation
            float len_xy = length(pos.xy);
            float core_diff = abs(u_core_radius - len_xy);
            
            // Distributed multiplication
            step_val = u_advance_base + (core_diff * 0.1);
            depth += step_val;

            // Volumetric integration
            float scatter_factor = u_scatter / step_val;
            vec4 tint = cos(depth + u_chroma_shift) + 1.0;
            acc += (tint * scatter_factor) / u_light_fade;
        }

        gl_FragColor = acc;
    }
`;

const glsl_vertex = `
    void main() {
        gl_Position = vec4(position, 1.0);
    }
`;

// --- Bootstrapping ---
function initialize_engine() {
    // Scene architecture
    ctx.scene_graph = new THREE.Scene();
    ctx.cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

    // Renderer configuration
    ctx.engine = new THREE.WebGLRenderer({ antialias: false });
    ctx.engine.setSize(window.innerWidth, window.innerHeight);
    ctx.engine.setPixelRatio(ctx.pixel_scale);
    document.body.appendChild(ctx.engine.domElement);

    // Initial state mapping
    ctx.shader_props = {
        u_ticks: { value: 0 },
        u_screen: { value: new THREE.Vector3(window.innerWidth * ctx.pixel_scale, window.innerHeight * ctx.pixel_scale, 0.8) },
        
        u_time_mul: { value: 0.3 },
        u_light_fade: { value: 2600.0 },
        u_loop_limit: { value: 53.0 },
        u_chroma_shift: { value: new THREE.Vector4(6.3, 7.0, 3.6, 3.0) },
        u_core_radius: { value: 2.1 },
        u_advance_base: { value: 0.045 },
        u_noise_freq: { value: 0.7 },
        u_scatter: { value: 2.0 }
    };

    // Construct quad
    const mat = new THREE.ShaderMaterial({
        fragmentShader: glsl_fragment,
        vertexShader: glsl_vertex,
        uniforms: ctx.shader_props,
        depthWrite: false,
        depthTest: false
    });

    const geo = new THREE.PlaneGeometry(2, 2);
    const quad = new THREE.Mesh(geo, mat);
    ctx.scene_graph.add(quad);

    build_interface();

    window.addEventListener('resize', handle_resize, false);
}

// --- Interface Builder ---
function build_interface() {
    const panel = new GUI({ title: 'Shader Configuration' });
    panel.close(); 

    const bindings = {
        res_scale: ctx.pixel_scale,
        t_multiplier: ctx.shader_props.u_time_mul.value,
        ray_limit: ctx.shader_props.u_loop_limit.value,
        ray_stride: ctx.shader_props.u_advance_base.value,
        attenuation: ctx.shader_props.u_light_fade.value,
        void_radius: ctx.shader_props.u_core_radius.value,
        scattering: ctx.shader_props.u_scatter.value,
        turbulence: ctx.shader_props.u_noise_freq.value,
        ch_red: ctx.shader_props.u_chroma_shift.value.x,
        ch_green: ctx.shader_props.u_chroma_shift.value.y,
        ch_blue: ctx.shader_props.u_chroma_shift.value.z
    };

    const opt_group = panel.addFolder('Render Pipeline');
    opt_group.add(bindings, 'res_scale', 0.1, 2.0, 0.1).name('Internal Resolution').onChange(val => {
        ctx.pixel_scale = val;
        ctx.engine.setPixelRatio(val);
        ctx.shader_props.u_screen.value.set(window.innerWidth * val, window.innerHeight * val, 1);
    });
    opt_group.add(bindings, 'ray_limit', 10, 150, 1).name('Ray Limit').onChange(val => ctx.shader_props.u_loop_limit.value = val);
    opt_group.add(bindings, 'ray_stride', 0.01, 0.1, 0.005).name('Ray Stride').onChange(val => ctx.shader_props.u_advance_base.value = val);

    const vol_group = panel.addFolder('Volume Properties');
    vol_group.add(bindings, 't_multiplier', 0.0, 3.0, 0.1).name('Time Multiplier').onChange(val => ctx.shader_props.u_time_mul.value = val);
    vol_group.add(bindings, 'scattering', 0.1, 5.0, 0.1).name('Scattering Amount').onChange(val => ctx.shader_props.u_scatter.value = val);
    vol_group.add(bindings, 'turbulence', 0.5, 3.0, 0.1).name('Turbulence Freq').onChange(val => ctx.shader_props.u_noise_freq.value = val);
    vol_group.add(bindings, 'void_radius', 0.5, 10.0, 0.1).name('Void Radius').onChange(val => ctx.shader_props.u_core_radius.value = val);
    vol_group.add(bindings, 'attenuation', 500, 10000, 100).name('Light Attenuation').onChange(val => ctx.shader_props.u_light_fade.value = val);

    const hue_group = panel.addFolder('Palette Config');
    hue_group.add(bindings, 'ch_red', 0, 10, 0.1).name('Channel R Shift').onChange(val => ctx.shader_props.u_chroma_shift.value.x = val);
    hue_group.add(bindings, 'ch_green', 0, 10, 0.1).name('Channel G Shift').onChange(val => ctx.shader_props.u_chroma_shift.value.y = val);
    hue_group.add(bindings, 'ch_blue', 0, 10, 0.1).name('Channel B Shift').onChange(val => ctx.shader_props.u_chroma_shift.value.z = val);
}

// --- Window Events ---
function handle_resize() {
    ctx.engine.setSize(window.innerWidth, window.innerHeight);
    ctx.shader_props.u_screen.value.set(
        window.innerWidth * ctx.pixel_scale, 
        window.innerHeight * ctx.pixel_scale, 
        1
    );
}

// --- Main Loop ---
function trigger_render() {
    requestAnimationFrame(trigger_render);
    
    ctx.shader_props.u_ticks.value = ctx.perf_clock.getElapsedTime();
    ctx.engine.render(ctx.scene_graph, ctx.cam);
}

// Let's go
initialize_engine();
trigger_render();