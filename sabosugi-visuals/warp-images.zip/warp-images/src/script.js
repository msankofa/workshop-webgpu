       // --- Default Configuration ---
        const DEFAULT_CONFIG = {
            // Default image URL (leave empty string '' to use the generated placeholder)
            imageUrl: 'https://ik.imagekit.io/sqiqig7tz/woman-abstract.jpg',
            
            // Distortion parameters
            amplitude: 0.06,
            frequency: 18,
            complexity: 0,
            sharpness: 5,
            yStart: 0.4,
            speed: 0.5,
            maskAngle: -54.4, // Angle for safe area and spacer
            waveAngle: 122, // Angle for the distortion waves
            
            // Spacer parameters
            spacerY: 1.0,
            spacerSize: 0.08,
            spacerFeather: 0.05
        };

        // --- Scene Setup ---
        const scene = new THREE.Scene();
        
        // Orthographic camera for 2D image processing
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
        camera.position.z = 1;

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // --- Shader Material ---
        
        // Vertex Shader: Standard pass-through
        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `;

        // Fragment Shader: Core warp logic with Spacer, Sharpness, and Rotation
        const fragmentShader = `
            uniform sampler2D uTexture;
            uniform float uTime;
            uniform float uAmplitude;
            uniform float uFrequency;
            uniform float uComplexity;
            uniform float uSharpness;
            uniform float uYStart;
            uniform float uSpeed;
            uniform float uMaskAngle; // Angle for masks in radians
            uniform float uWaveAngle; // Angle for waves in radians
            
            // Spacer uniforms
            uniform float uSpacerY;
            uniform float uSpacerSize;
            uniform float uSpacerFeather;
            
            varying vec2 vUv;

            void main() {
                // Mask rotation math
                float mc = cos(uMaskAngle);
                float ms = sin(uMaskAngle);
                mat2 maskRot = mat2(mc, -ms, ms, mc);
                
                // Wave rotation math
                float wc = cos(uWaveAngle);
                float ws = sin(uWaveAngle);
                mat2 waveRot = mat2(wc, -ws, ws, wc);
                
                // Rotate UVs around the center
                vec2 centeredUv = vUv - vec2(0.5);
                vec2 maskUv = maskRot * centeredUv + vec2(0.5);
                vec2 waveUv = waveRot * centeredUv + vec2(0.5);

                // 1. Top Mask: Keeps the top part of the image undistorted
                float topMask = smoothstep(uYStart, uYStart - 0.2, maskUv.y);

                // 2. Spacer Mask: Creates a band without distortion
                float distToSpacer = abs(maskUv.y - uSpacerY);
                float halfSize = uSpacerSize * 0.5;
                float spacerMask = smoothstep(halfSize, halfSize + uSpacerFeather, distToSpacer);

                // Combine masks
                float finalMask = topMask * spacerMask;

                // 3. Wave Calculation (Sharp Bands Method)
                float time = uTime * uSpeed;
                
                // Base wave based on rotated Y for waves
                float baseWave = sin(waveUv.y * uFrequency + time);
                float shapedWave = sign(baseWave) * pow(abs(baseWave), uSharpness);
                
                // Add secondary complex wave
                float complexWave = sin(waveUv.y * uFrequency * uComplexity - time * 0.8);
                shapedWave += sign(complexWave) * pow(abs(complexWave), uSharpness * 1.5) * 0.4;

                // Apply the wave along the wave's X axis
                vec2 waveDir = vec2(wc, ws);
                vec2 finalUv = vUv + waveDir * (shapedWave * uAmplitude * finalMask);

                // Sample the texture
                vec4 color = texture2D(uTexture, finalUv);
                
                gl_FragColor = color;
            }
        `;

        // Create an empty initial texture to prevent WebGL warnings before the image loads
        const texture = new THREE.Texture();
        texture.wrapS = THREE.ClampToEdgeWrapping;
        texture.wrapT = THREE.ClampToEdgeWrapping;

        // Initialize Shader Material
        const material = new THREE.ShaderMaterial({
            vertexShader: vertexShader,
            fragmentShader: fragmentShader,
            uniforms: {
                uTexture: { value: texture },
                uTime: { value: 0.0 },
                uAmplitude: { value: DEFAULT_CONFIG.amplitude },
                uFrequency: { value: DEFAULT_CONFIG.frequency },
                uComplexity: { value: DEFAULT_CONFIG.complexity },
                uSharpness: { value: DEFAULT_CONFIG.sharpness },
                uYStart: { value: DEFAULT_CONFIG.yStart },
                uSpeed: { value: DEFAULT_CONFIG.speed },
                uMaskAngle: { value: DEFAULT_CONFIG.maskAngle * Math.PI / 180.0 },
                uWaveAngle: { value: DEFAULT_CONFIG.waveAngle * Math.PI / 180.0 },
                // Spacer default values
                uSpacerY: { value: DEFAULT_CONFIG.spacerY },
                uSpacerSize: { value: DEFAULT_CONFIG.spacerSize },
                uSpacerFeather: { value: DEFAULT_CONFIG.spacerFeather }
            }
        });

        // Plane geometry
        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- Texture Loader for URLs ---
        const textureLoader = new THREE.TextureLoader();
        // Allow cross-origin requests for images loaded from external URLs
        textureLoader.crossOrigin = 'anonymous';

        function loadTextureFromUrl(url) {
            textureLoader.load(
                url,
                function (newTexture) {
                    newTexture.wrapS = THREE.ClampToEdgeWrapping;
                    newTexture.wrapT = THREE.ClampToEdgeWrapping;
                    material.uniforms.uTexture.value = newTexture;

                    const img = newTexture.image;
                    updateMeshScale(img.width, img.height);
                },
                undefined,
                function (err) {
                    console.error('Error loading image:', err);
                    // Show error in the info div without using alert()
                    const infoDiv = document.getElementById('info');
                    const originalText = infoDiv.innerText;
                    infoDiv.innerText = 'Error loading URL (CORS or Invalid Link). Try local upload.';
                    infoDiv.style.color = '#ff6b6b';
                    setTimeout(() => {
                        infoDiv.innerText = originalText;
                        infoDiv.style.color = 'rgba(255, 255, 255, 0.5)';
                    }, 4000);
                }
            );
        }

        // Load default image on startup if provided
        if (DEFAULT_CONFIG.imageUrl) {
            loadTextureFromUrl(DEFAULT_CONFIG.imageUrl);
        }

        // --- lil-gui Settings Panel ---
        const gui = new lil.GUI({ title: 'Settings' });
        
        const params = {
            amplitude: material.uniforms.uAmplitude.value,
            frequency: material.uniforms.uFrequency.value,
            complexity: material.uniforms.uComplexity.value,
            sharpness: material.uniforms.uSharpness.value,
            yStart: material.uniforms.uYStart.value,
            speed: material.uniforms.uSpeed.value,
            maskAngle: DEFAULT_CONFIG.maskAngle,
            waveAngle: DEFAULT_CONFIG.waveAngle,
            
            spacerY: material.uniforms.uSpacerY.value,
            spacerSize: material.uniforms.uSpacerSize.value,
            spacerFeather: material.uniforms.uSpacerFeather.value,
            
            // Add URL property mapping to default config
            imageUrl: DEFAULT_CONFIG.imageUrl,
            loadUrl: () => {
                if (params.imageUrl) loadTextureFromUrl(params.imageUrl);
            },
            uploadImage: () => {
                document.getElementById('file-input').click();
            }
        };

        // Main Distortion Controls
        const folderDistortion = gui.addFolder('Distortion Config');
        folderDistortion.add(params, 'amplitude', 0.0, 1.0).name('Amplitude').onChange(v => material.uniforms.uAmplitude.value = v);
        folderDistortion.add(params, 'frequency', 1.0, 100.0).name('Frequency').onChange(v => material.uniforms.uFrequency.value = v);
        folderDistortion.add(params, 'complexity', 0.0, 5.0).name('Complexity').onChange(v => material.uniforms.uComplexity.value = v);
        folderDistortion.add(params, 'sharpness', 1.0, 20.0).name('Band Sharpness').onChange(v => material.uniforms.uSharpness.value = v);
        folderDistortion.add(params, 'yStart', 0.0, 1.0).name('Top Safe Area Y').onChange(v => material.uniforms.uYStart.value = v);
        folderDistortion.add(params, 'speed', 0.0, 1.0).name('Animation Speed').onChange(v => material.uniforms.uSpeed.value = v);
        folderDistortion.add(params, 'maskAngle', -180.0, 180.0).name('Mask Angle').onChange(v => material.uniforms.uMaskAngle.value = v * Math.PI / 180.0);
        folderDistortion.add(params, 'waveAngle', -180.0, 180.0).name('Wave Angle').onChange(v => material.uniforms.uWaveAngle.value = v * Math.PI / 180.0);
        
        // Spacer Controls
        const folderSpacer = gui.addFolder('Spacer Config');
        folderSpacer.add(params, 'spacerY', 0.0, 1.0).name('Spacer Center Y').onChange(v => material.uniforms.uSpacerY.value = v);
        folderSpacer.add(params, 'spacerSize', 0.0, 0.5).name('Spacer Size').onChange(v => material.uniforms.uSpacerSize.value = v);
        folderSpacer.add(params, 'spacerFeather', 0.0, 0.2).name('Spacer Feather').onChange(v => material.uniforms.uSpacerFeather.value = v);

        // Image Loading Controls
        const folderImage = gui.addFolder('Image Upload & URL');
        folderImage.add(params, 'imageUrl').name('Image URL');
        folderImage.add(params, 'loadUrl').name('Load from URL');
        folderImage.add(params, 'uploadImage').name('Upload Local Image');

        // --- Image Upload Logic ---
        document.getElementById('file-input').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(event) {
                const img = new Image();
                img.onload = function() {
                    const newTexture = new THREE.Texture(img);
                    newTexture.wrapS = THREE.ClampToEdgeWrapping;
                    newTexture.wrapT = THREE.ClampToEdgeWrapping;
                    newTexture.needsUpdate = true;
                    
                    material.uniforms.uTexture.value = newTexture;

                    // Adjust plane scale to match image aspect ratio, keeping it fit in window
                    updateMeshScale(img.width, img.height);
                };
                img.src = event.target.result;
            };
            reader.readAsDataURL(file);
        });

        // Function to handle aspect ratio scaling
        function updateMeshScale(imgWidth, imgHeight) {
            const imageAspect = imgWidth / imgHeight;
            const screenAspect = window.innerWidth / window.innerHeight;
            
            // Simple fit cover/contain logic using Orthographic camera bounds
            if (imageAspect > screenAspect) {
                mesh.scale.set(1.0, screenAspect / imageAspect, 1.0);
            } else {
                mesh.scale.set(imageAspect / screenAspect, 1.0, 1.0);
            }
        }

        // --- Resize Handler ---
        window.addEventListener('resize', () => {
            renderer.setSize(window.innerWidth, window.innerHeight);
            if (material.uniforms.uTexture.value && material.uniforms.uTexture.value.image) {
                 const img = material.uniforms.uTexture.value.image;
                 updateMeshScale(img.width, img.height);
            } else {
                 updateMeshScale(1, 1);
            }
        });

        // Initialize default scale
        updateMeshScale(1, 1);

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            material.uniforms.uTime.value = clock.getElapsedTime();
            renderer.render(scene, camera);
        }

        animate();