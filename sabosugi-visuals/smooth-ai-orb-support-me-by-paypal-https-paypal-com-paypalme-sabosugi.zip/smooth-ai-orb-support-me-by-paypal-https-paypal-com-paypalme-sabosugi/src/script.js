        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import GUI from 'lil-gui';

        // --- Core Variables ---
        let camera, scene, renderer, controls, material;
        let clock = new THREE.Clock();

        // --- Configuration Parameters ---
        const params = {
            dpr: 1.3, // Default DPR
            rotationSpeed: 1.0, // Auto rotation speed
            sphereSpinSpeed: -0.65, // Internal horizontal spin
            fractalWarpSpeed: 0.0262, // Internal fractal morphing speed
            color1: '#057eff', // Translated from vec3(0.020, 0.494, 1.000)
            color2: '#1a71ff', // Translated from vec3(0.102, 0.443, 1.000)
            aberration: 0.698, // Chromatic aberration intensity
            particleDensity: 0.021, // Density of white particles
            sphereRadius: 2.655, // Sphere Bounds
            edgeFade: 0.381, // Feathering effect at the edges
            fractalScale: 0.7602, // Domain Scale
            fractalMult: 2.196, // Iteration Multiplier
            glowIntensity: 0.014 // Glow Intensity
        };

        init();
        animate();

        function init() {
            const container = document.getElementById('container');

            // --- Scene & Camera Setup ---
            scene = new THREE.Scene();
            camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 100);
            camera.position.set(0, 0, 8.0); // Step back to see the sphere

            // --- Renderer Setup ---
            renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
            renderer.setPixelRatio(params.dpr);
            renderer.setSize(window.innerWidth, window.innerHeight);
            container.appendChild(renderer.domElement);

            // --- Controls (Inertia, Grab, Mobile gestures) ---
            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true; // Enables inertia
            controls.dampingFactor = 0.05;
            controls.enableZoom = true;
            controls.autoRotate = true;
            controls.autoRotateSpeed = params.rotationSpeed;

            // --- Shader Material Setup ---
            // Fullscreen quad. The raymarching algorithm handles 3D projection.
            const geometry = new THREE.PlaneGeometry(2, 2);

            material = new THREE.ShaderMaterial({
                uniforms: {
                    uTime: { value: 0.0 },
                    uResolution: { value: new THREE.Vector2(window.innerWidth * params.dpr, window.innerHeight * params.dpr) },
                    
                    // Camera uniforms synced with Three.js camera
                    cameraWorldMatrix: { value: camera.matrixWorld },
                    cameraProjectionMatrixInverse: { value: camera.projectionMatrixInverse },
                    
                    // GUI Parameters
                    uColor1: { value: new THREE.Color(params.color1) },
                    uColor2: { value: new THREE.Color(params.color2) },
                    uSphereRadius: { value: params.sphereRadius },
                    uEdgeFade: { value: params.edgeFade },
                    uFractalScale: { value: params.fractalScale },
                    uFractalMult: { value: params.fractalMult },
                    uGlowIntensity: { value: params.glowIntensity },
                    uFractalWarpSpeed: { value: params.fractalWarpSpeed },
                    uSphereSpin: { value: 0.0 },
                    uAberration: { value: params.aberration },
                    uParticleDensity: { value: params.particleDensity }
                },
                vertexShader: `
                    varying vec2 vUv;
                    void main() {
                        vUv = uv;
                        // Render a fullscreen plane bypassing normal projection
                        gl_Position = vec4(position, 1.0);
                    }
                `,
                fragmentShader: `
                    uniform float uTime;
                    uniform vec2 uResolution;
                    uniform vec3 uColor1;
                    uniform vec3 uColor2;
                    uniform float uSphereRadius;
                    uniform float uEdgeFade;
                    uniform float uFractalScale;
                    uniform float uFractalMult;
                    uniform float uGlowIntensity;
                    uniform float uFractalWarpSpeed;
                    uniform float uSphereSpin;
                    uniform float uAberration;
                    uniform float uParticleDensity;

                    uniform mat4 cameraWorldMatrix;
                    uniform mat4 cameraProjectionMatrixInverse;

                    varying vec2 vUv;

                    // Standard 2D rotation matrix
                    mat2 rot(float a) {
                        float s = sin(a), c = cos(a);
                        return mat2(c, -s, s, c);
                    }

                    // Pseudo-random noise generator to eliminate color banding (Dithering)
                    float hash(vec2 p) {
                        return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
                    }

                    // 3D hash for particles
                    float hash31(vec3 p3) {
                        p3  = fract(p3 * 0.1031);
                        p3 += dot(p3, p3.yzx + 33.33);
                        return fract((p3.x + p3.y) * p3.z);
                    }

                    // Polynomial smooth minimum (Melts hard geometric intersections into fluid shapes)
                    float smin(float a, float b, float k) {
                        float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
                        return mix(b, a, h) - k * h * (1.12 - h); // User's parameter applied
                    }

                    // Restricted Neon Palette: Animates between provided colors
                    vec3 palette(float t) {
                        // Sine wave maps time/distance to a smooth 0.0 -> 1.0 blend factor
                        float blend = sin(t * 1.4) * 0.5 + 0.5;
                        return mix(uColor1, uColor2, blend);
                    }

                    // --- Smooth Iterated Gyroid Network ---
                    float map(vec3 p) {
                        float d = 100.2;
                        float scale = 0.4;
                        
                        // Initial offset to prevent symmetry at the origin
                        p += vec3(12.600, 4.400, 5.569);
                        
                        for (int i = 1; i < 4; i++) {
                            // Continuous domain rotation driven by time
                            p.xy *= rot(uTime * uFractalWarpSpeed + 0.2);
                            p.yz *= rot(uTime * (uFractalWarpSpeed * 1.5) - 0.1);
                            
                            float dotp = dot(sin(p), cos(p.zxy));
                            
                            // Removes sharp ridges and makes tubes perfectly round
                            float gyroid = sqrt(dotp * dotp + 0.055) - 0.137;
                            
                            // Organic, liquid-like blending between fractal layers
                            d = smin(d, gyroid / abs(scale), 0.15);
                            
                            // Scale and shift for the next iteration to create fractal depth
                            p *= uFractalScale;
                            scale *= uFractalMult;
                            p += vec3(-1.7, 1.2, 3.5); 
                        }
                        
                        return d;
                    }

                    // Analytic Ray-Sphere Intersection
                    vec2 intersectSphere(vec3 ro, vec3 rd, float r) {
                        float b = dot(ro, rd);
                        float c = dot(ro, ro) - r * r;
                        float h = b * b - c;
                        if(h < 0.0) return vec2(0.0); // Strict cutoff based on user code
                        h = sqrt(h);
                        return vec2(-b - h, -b + h); // Returns tNear and tFar
                    }

                    void main() {
                        // Project screen coordinates to 3D Viewport Rays based on Three.js Camera
                        vec2 ndc = (vUv - 0.5) * 2.0;
                        vec4 clipPos = vec4(ndc, -1.0, 1.0);
                        vec4 viewPos = cameraProjectionMatrixInverse * clipPos;
                        vec3 rd = normalize((cameraWorldMatrix * vec4(viewPos.xyz, 0.0)).xyz);
                        
                        // Three.js ShaderMaterial provides cameraPosition automatically
                        vec3 ro = cameraPosition;

                        // Apply internal horizontal spin (Rotates the fractal space independently)
                        mat2 spinRot = rot(uSphereSpin);
                        ro.xz *= spinRot;
                        rd.xz *= spinRot;

                        // Confine rendering to the sphere interior
                        vec2 hit = intersectSphere(ro, rd, uSphereRadius);
                        
                        // Render deep void if the ray misses the bounding sphere
                        // hit.y <= 0.0 catches both missed rays and rays returning vec2(0.0)
                        if(hit.y <= 0.0) {
                            gl_FragColor = vec4(-0.01, 0.01, 0.015, 1.0);
                            return;
                        }
                        
                        float tNear = max(0.0, hit.x);
                        float tFar = hit.y;
                        
                        // APPLIED DITHERING: Offset the starting ray position slightly per pixel. 
                        // This breaks up visual banding into a smooth, film-like volumetric fog.
                        float t = tNear + hash(gl_FragCoord.xy) * 0.20;
                        
                        vec3 accumulatedGlow = vec3(0.0);
                        
                        // Volumetric raymarching loop
                        for(int i = 0; i < 90; i++) {
                            // Break early if we exit the sphere bounds
                            if(t > tFar) break;
                            
                            vec3 p = ro + rd * t;
                            float d = map(p);
                            
                            // Edge fade logic: makes the fractal transparent near the sphere bounds
                            float distFromCenter = length(p);
                            float fade = smoothstep(uSphereRadius, uSphereRadius - uEdgeFade, distFromCenter);
                            
                            // Glow formula: transforms surfaces into burning energy filaments
                            float intensity = (uGlowIntensity / (abs(d) + 0.029)) * fade;
                            
                            // Chromatic Aberration (Holo effect) mapped to palette
                            float phase = length(p) * -0.4 - uTime * -0.1;
                            vec3 holoColor;
                            holoColor.r = palette(phase + uAberration * 0.1).r;
                            holoColor.g = palette(phase).g;
                            holoColor.b = palette(phase - uAberration * 0.1).b;
                            
                            // Accumulate specific mapped palette color with holo
                            accumulatedGlow += holoColor * intensity;
                            
                            // Tiny white particles floating inside
                            vec3 pPos = p * 25.0 + vec3(uTime * 1.5, uTime * -2.0, uTime * 0.5); 
                            vec3 pCell = floor(pPos);
                            vec3 pFract = fract(pPos) - 0.5;
                            float isParticle = step(1.0 - uParticleDensity, hash31(pCell));
                            float pDist = length(pFract);
                            float pIntensity = 0.0015 / (pDist + 0.005);
                            
                            // --- BLEND MODE: OVERLAY / COLOR DODGE ---
                            // Base color of the particle
                            vec3 pColor = vec3(1.0) * pIntensity * isParticle * (intensity * 25.0);
                            
                            // Instead of pure addition, we multiply the particle by the existing accumulated 
                            // fractal glow. This causes the fractal colors to heavily saturate and blow out 
                            // to bright white where the particles intersect it (simulating Color Dodge).
                            accumulatedGlow += pColor + (accumulatedGlow * pColor * 2.5);
                            
                            // Advance ray with a safety factor. Minimum step clamped to 0.02 to prevent infinite loop crashes.
                            t += max(abs(d) * 0.7, 0.02);
                        }
                        
                        // Outer glass shell reflection
                        if(hit.x > 0.0) {
                            vec3 shellNormal = normalize(ro + rd * hit.x);
                            float rimLight = 0.5 - max(0.0, dot(-rd, shellNormal));
                            // Slightly re-activated the rim light to frame the sphere nicely
                            accumulatedGlow += vec3(0.2, 0.0, 0.6) * pow(rimLight, 4.0) * 0.3;
                        }
                        
                        // Reinhard tone mapping to handle overexposure
                        accumulatedGlow = accumulatedGlow / (1.3 + accumulatedGlow);
                        
                        // Gamma correction
                        accumulatedGlow = pow(accumulatedGlow, vec3(0.4545));
                        
                        gl_FragColor = vec4(accumulatedGlow, 1.0);
                    }
                `
            });

            const mesh = new THREE.Mesh(geometry, material);
            // Disable frustum culling so the fullscreen quad always renders
            mesh.frustumCulled = false;
            scene.add(mesh);

            setupGUI();

            window.addEventListener('resize', onWindowResize);
        }

        function setupGUI() {
            const gui = new GUI({ title: 'Fractal Settings' });

            const sysFolder = gui.addFolder('System & Interaction');
            sysFolder.add(params, 'dpr', 0.5, 2.0, 0.1).name('DPR (Pixel Ratio)').onChange(val => {
                renderer.setPixelRatio(val);
                material.uniforms.uResolution.value.set(window.innerWidth * val, window.innerHeight * val);
            });
            sysFolder.add(params, 'rotationSpeed', 0.0, 10.0).name('Camera Orbit Speed').onChange(val => {
                controls.autoRotateSpeed = val;
            });
            sysFolder.add(params, 'sphereSpinSpeed', -5.0, 5.0).name('Fractal Spin Speed');

            const visFolder = gui.addFolder('Visuals');
            visFolder.addColor(params, 'color1').name('Core Color (Blue)').onChange(val => {
                material.uniforms.uColor1.value.set(val);
            });
            visFolder.addColor(params, 'color2').name('Glow Color (Purple)').onChange(val => {
                material.uniforms.uColor2.value.set(val);
            });
            visFolder.add(params, 'glowIntensity', 0.001, 0.020, 0.001).name('Glow Intensity').onChange(val => {
                material.uniforms.uGlowIntensity.value = val;
            });
            visFolder.add(params, 'aberration', 0.0, 2.0).name('Holo Aberration').onChange(val => {
                material.uniforms.uAberration.value = val;
            });
            visFolder.add(params, 'particleDensity', 0.0, 0.1, 0.001).name('Particle Density').onChange(val => {
                material.uniforms.uParticleDensity.value = val;
            });

            const shapeFolder = gui.addFolder('Fractal Architecture');
            shapeFolder.add(params, 'sphereRadius', 0.5, 8.0).name('Sphere Bounds').onChange(val => {
                material.uniforms.uSphereRadius.value = val;
            });
            shapeFolder.add(params, 'edgeFade', 0.0, 3.0).name('Edge Transparency').onChange(val => {
                material.uniforms.uEdgeFade.value = val;
            });
            shapeFolder.add(params, 'fractalWarpSpeed', 0.0, 0.1).name('Warp Speed').onChange(val => {
                material.uniforms.uFractalWarpSpeed.value = val;
            });
            shapeFolder.add(params, 'fractalScale', 0.1, 1.5).name('Domain Scale').onChange(val => {
                material.uniforms.uFractalScale.value = val;
            });
            shapeFolder.add(params, 'fractalMult', 1.0, 5.0).name('Iteration Multiplier').onChange(val => {
                material.uniforms.uFractalMult.value = val;
            });

            // Collapse the panel by default 
            gui.close();
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            
            const dpr = renderer.getPixelRatio();
            material.uniforms.uResolution.value.set(window.innerWidth * dpr, window.innerHeight * dpr);
        }

        function animate() {
            requestAnimationFrame(animate);

            // Update time and internal spin
            const t = clock.getElapsedTime();
            material.uniforms.uTime.value = t;
            material.uniforms.uSphereSpin.value = t * params.sphereSpinSpeed;

            // Update controls (handles inertia and auto-rotation)
            controls.update();

            // Sync camera matrices with the shader
            material.uniforms.cameraWorldMatrix.value.copy(camera.matrixWorld);
            material.uniforms.cameraProjectionMatrixInverse.value.copy(camera.projectionMatrixInverse);

            renderer.render(scene, camera);
        }