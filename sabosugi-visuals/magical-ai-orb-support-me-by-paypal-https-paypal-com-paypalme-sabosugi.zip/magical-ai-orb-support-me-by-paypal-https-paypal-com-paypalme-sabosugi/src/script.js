  // Support me by PayPal: https://paypal.com/paypalme/sabosugi
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
        import GUI from 'lil-gui';

        // 1. Scene Setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x000000);

        // 2. Camera Setup
        const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 100);
        camera.position.set(0, 0, 6);

        // 3. Renderer Setup
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // 4. Orbit Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.enablePan = false;
        controls.minDistance = 3;
        controls.maxDistance = 15;

        // --- Presets Definition ---
        const presets = {
            'Default': {
                primaryEnergy: '#00b3ff', secondaryEnergy: '#2e9aff', speed: 0.5, density: 3.0, dpr: 0.7,
                atmosphereGlow: 0.15, atmosphereLevel: 1.0, atmosphereScale: 1.03, orbRotation: 0.89,
                internalAnim: 0.43, fractalIters: 4, fractalScale: 0.97, fractalDecay: -16.7,
                smoothness: 0.031, asymmetry: 0.55, chromaticAberration: 0.025
            },
            'Cyan': {
                primaryEnergy: '#00ffee', secondaryEnergy: '#9900ff', speed: 0.5, density: 1.1, dpr: 0.7,
                atmosphereGlow: 0.15, atmosphereLevel: 1.0, atmosphereScale: 1.03, orbRotation: 0.89,
                internalAnim: 0.43, fractalIters: 3, fractalScale: 0.75, fractalDecay: -16.7,
                smoothness: 0.05, asymmetry: 0.45, chromaticAberration: 0.026
            },
            'Gray': {
                primaryEnergy: '#ffffff', secondaryEnergy: '#000000', speed: 0.3, density: 0.9, dpr: 0.7,
                atmosphereGlow: 0.15, atmosphereLevel: 1.0, atmosphereScale: 1.03, orbRotation: 0.46,
                internalAnim: 0.17, fractalIters: 4, fractalScale: 0.74, fractalDecay: -21.6,
                smoothness: 0.036, asymmetry: 0.0, chromaticAberration: 0.017
            },
            'Yellow': {
                primaryEnergy: '#ffbb00', secondaryEnergy: '#2eff9d', speed: 0.5, density: 2.1, dpr: 0.7,
                atmosphereGlow: 0.15, atmosphereLevel: 1.0, atmosphereScale: 1.03, orbRotation: 0.53,
                internalAnim: 0.43, fractalIters: 3, fractalScale: 0.69, fractalDecay: -14.5,
                smoothness: 0.008, asymmetry: 0.35, chromaticAberration: 0.024
            },
            'Green': {
                primaryEnergy: '#44ff00', secondaryEnergy: '#0062ff', speed: 1.1, density: 1.3, dpr: 0.7,
                atmosphereGlow: 0.15, atmosphereLevel: 1.0, atmosphereScale: 1.03, orbRotation: 0.56,
                internalAnim: 0.4, fractalIters: 4, fractalScale: 0.89, fractalDecay: -24.3,
                smoothness: 0.081, asymmetry: 0.26, chromaticAberration: 0.0
            }
        };

        // 5. Shader Material Setup
        const params = {
            preset: 'Default',
            ...presets['Default']
        };

        // Set initial pixel ratio
        renderer.setPixelRatio(params.dpr);

        const vertexShader = `
            varying vec3 vLocalPosition;
            varying vec3 vNormal;
            varying vec3 vViewPosition;

            void main() {
                // Pass local position to fragment shader for localized raymarching
                vLocalPosition = position;
                
                // Calculate normal and view direction for Fresnel edge glow
                vNormal = normalize(normalMatrix * normal);
                vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
                vViewPosition = -mvPosition.xyz;
                
                gl_Position = projectionMatrix * mvPosition;
            }
        `;

        const fragmentShader = `
            uniform float uTime;
            uniform vec3 uLocalCamPos;
            uniform vec3 uPrimaryColor;
            uniform vec3 uSecondaryColor;
            uniform float uDensity;
            
            // Fractal Specific Uniforms
            uniform float uFractalIters;
            uniform float uFractalScale;
            uniform float uFractalDecay;
            uniform float uInternalAnim;
            uniform float uSmoothness;
            uniform float uAsymmetry;
            uniform float uAtmosphereGlow;
            
            varying vec3 vLocalPosition;
            varying vec3 vNormal;
            varying vec3 vViewPosition;

            // Evaluates the internal volume structure
            float evaluateStructure(vec3 pos) {
                float densityAcc = 0.0;
                vec3 anchor = pos;
                
                // Calculate rotation for internal animation
                float animTime = uTime * uInternalAnim;
                float s = sin(animTime);
                float c = cos(animTime);
                mat2 rotAnim = mat2(c, s, -s, c);

                // Static rotations based on asymmetry parameter to break mirror planes
                float a = 0.5 * uAsymmetry;
                mat2 rotAsym1 = mat2(cos(a), sin(a), -sin(a), cos(a));
                float b = 0.3 * uAsymmetry;
                mat2 rotAsym2 = mat2(cos(b), sin(b), -sin(b), cos(b));
                
                // Iterative space folding
                for (int step = 0; step < 12; ++step) {
                    if (float(step) >= uFractalIters) break;
                    
                    // 1. Internal animation: smoothly rotate space over time
                    pos.xy *= rotAnim;
                    pos.yz *= rotAnim;
                    
                    // 2. Break exact global mirroring completely
                    // Rotate space on non-aligned axes to destroy the kaleidoscope grid
                    pos.xz *= rotAsym1;
                    pos.yz *= rotAsym2;
                    // Add asymmetric shift
                    pos += vec3(0.05, -0.02, 0.03) * uAsymmetry;
                    
                    // 3. Smooth Fold Space (Replaces harsh abs() function)
                    // sqrt(x^2 + e) acts like abs(x) but with a rounded bottom
                    vec3 foldedPos = sqrt(pos * pos + uSmoothness);
                    
                    float magnitudeSq = dot(foldedPos, foldedPos);
                    
                    // Prevent division by zero artifacting
                    magnitudeSq = max(magnitudeSq, 0.00001); 
                    
                    pos = (uFractalScale * foldedPos / magnitudeSq) - uFractalScale;
                    
                    // Complex square transformation on YZ plane mapped to variables
                    float ySq = pos.y * pos.y;
                    float zSq = pos.z * pos.z;
                    float yz2 = 2.0 * pos.y * pos.z;
                    pos.yz = vec2(ySq - zSq, yz2);
                    
                    // Safe axes swizzle
                    pos = vec3(pos.z, pos.x, pos.y);
                    
                    // Accumulate field strength
                    densityAcc += exp(uFractalDecay * abs(dot(pos, anchor)));
                }
                
                return densityAcc * 0.5;
            }

            // Boundary intersection calculation
            vec2 getVolumeBounds(vec3 origin, vec3 dir, float radius) {
                float b = dot(origin, dir);
                float c = dot(origin, origin) - radius * radius;
                float discriminant = b * b - c;
                
                if (discriminant < 0.0) {
                    return vec2(-1.0);
                }
                
                float root = sqrt(discriminant);
                return vec2(-b - root, -b + root);
            }

            // Raymarch through the defined volume
            vec3 traceEnergy(vec3 origin, vec3 dir, vec2 limits) {
                float currentDepth = limits.x;
                float marchStep = 0.02;
                vec3 finalEnergy = vec3(0.0);
                float fieldVal = 0.0;
                
                for(int i = 0; i < 64; i++) {
                    // Adaptive stepping based on density
                    currentDepth += marchStep * exp(-2.0 * fieldVal);
                    if(currentDepth > limits.y) break;
                    
                    vec3 samplePoint = origin + currentDepth * dir;
                    fieldVal = evaluateStructure(samplePoint);
                    
                    // Calculate color emission for this step
                    float vSq = fieldVal * fieldVal;
                    
                    // Create a smooth gradient: lowered the threshold to 0.4 
                    // so Primary Color dominates the structure much earlier
                    float gradientBlend = smoothstep(0.0, 0.4, fieldVal);
                    vec3 currentGradient = mix(uSecondaryColor, uPrimaryColor, gradientBlend);
                    
                    // Apply volumetric depth intensity (boosted slightly for the primary core)
                    vec3 emission = currentGradient * (fieldVal * 1.8 + vSq * 1.0);
                    
                    // Accumulate color
                    finalEnergy = 0.99 * finalEnergy + (0.08 * uDensity) * emission;
                }
                
                return finalEnergy;
            }

            void main() {
                // Ray setup in local object space
                vec3 rayOrig = uLocalCamPos;
                vec3 rayDir = normalize(vLocalPosition - uLocalCamPos);
                
                // Add internal time-based twisting to the ray path
                float t = uTime * 0.1;
                float s = sin(t);
                float c = cos(t);
                mat2 rotXZ = mat2(c, s, -s, c);
                rayOrig.xz *= rotXZ;
                rayDir.xz *= rotXZ;

                // Sphere intersection (Radius 2.0 to match original fractal scale)
                vec2 limits = getVolumeBounds(rayOrig, rayDir, 2.0);
                
                if (limits.x < 0.0) {
                    discard; // Missed the bounding volume completely
                }
                
                // Accumulate volumetric data
                vec3 volumeColor = traceEnergy(rayOrig, rayDir, limits);
                
                // Get facing ratio to soften the hard geometric edge of the fractal
                vec3 normal = normalize(vNormal);
                vec3 viewDir = normalize(vViewPosition);
                float facingRatio = max(dot(normal, viewDir), 0.0);
                
                // Anti-aliasing fade to completely erase the polygonal edge
                float edgeAA = smoothstep(0.0, 0.05, facingRatio);
                
                // Tonemapping
                vec3 finalColor = 0.5 * log(1.0 + volumeColor);
                finalColor = clamp(finalColor, 0.0, 1.0);
                
                // Apply the anti-aliasing fade
                finalColor *= edgeAA;
                
                // Opacity is tied to luminosity so empty space is fully transparent
                float maxLuma = max(finalColor.r, max(finalColor.g, finalColor.b));
                float alpha = clamp(maxLuma * 1.5, 0.0, 1.0) * edgeAA;
                
                gl_FragColor = vec4(finalColor, alpha);
            }
        `;

        const uniforms = {
            uTime: { value: 0 },
            uLocalCamPos: { value: new THREE.Vector3() },
            uPrimaryColor: { value: new THREE.Color(params.primaryEnergy) },
            uSecondaryColor: { value: new THREE.Color(params.secondaryEnergy) },
            uDensity: { value: params.density },
            uFractalIters: { value: params.fractalIters },
            uFractalScale: { value: params.fractalScale },
            uFractalDecay: { value: params.fractalDecay },
            uInternalAnim: { value: params.internalAnim },
            uSmoothness: { value: params.smoothness },
            uAsymmetry: { value: params.asymmetry }
        };

        const material = new THREE.ShaderMaterial({
            vertexShader: vertexShader,
            fragmentShader: fragmentShader,
            uniforms: uniforms,
            transparent: true,
            side: THREE.DoubleSide,
            depthWrite: false,
            blending: THREE.AdditiveBlending
        });

        // Atmosphere Halo Material (Separated for a perfect blurred contour)
        const atmosphereVertexShader = `
            varying vec3 vNormal;
            varying vec3 vViewPosition;
            void main() {
                vNormal = normalize(normalMatrix * normal);
                vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
                vViewPosition = -mvPosition.xyz;
                gl_Position = projectionMatrix * mvPosition;
            }
        `;

        const atmosphereFragmentShader = `
            uniform vec3 uColor;
            uniform float uGlow;
            uniform float uLevel;
            varying vec3 vNormal;
            varying vec3 vViewPosition;
            void main() {
                vec3 normal = normalize(vNormal);
                vec3 viewDir = normalize(vViewPosition);
                float vdn = max(dot(normal, viewDir), 0.0);
                
                // Soften the absolute outer edge to prevent geometric aliasing (blur effect)
                float edgeFade = smoothstep(0.0, 0.15, vdn);
                
                // Fade out the center completely to keep it hollow.
                // uLevel controls how thick the halo is.
                float innerFadePoint = clamp(1.0 - uLevel, 0.0, 0.99);
                float centerFade = smoothstep(1.0, innerFadePoint, vdn);
                
                // Combine to create a soft, blurred ring stroke
                float alpha = edgeFade * centerFade * uGlow;
                
                gl_FragColor = vec4(uColor, alpha);
            }
        `;

        const atmosphereUniforms = {
            uColor: { value: new THREE.Color(params.primaryEnergy) },
            uGlow: { value: params.atmosphereGlow },
            uLevel: { value: params.atmosphereLevel }
        };

        const atmosphereMaterial = new THREE.ShaderMaterial({
            vertexShader: atmosphereVertexShader,
            fragmentShader: atmosphereFragmentShader,
            uniforms: atmosphereUniforms,
            transparent: true,
            side: THREE.FrontSide,
            depthWrite: false,
            blending: THREE.AdditiveBlending
        });

        // 6. Object Creation
        // Increased geometry segments to 128 for smoother physical silhouette
        const geometry = new THREE.SphereGeometry(2.0, 128, 128);
        const orb = new THREE.Mesh(geometry, material);
        scene.add(orb);

        // Add the blurred halo shell as a child of the orb
        const atmosphereMesh = new THREE.Mesh(geometry, atmosphereMaterial);
        atmosphereMesh.scale.set(params.atmosphereScale, params.atmosphereScale, params.atmosphereScale);
        orb.add(atmosphereMesh);

        // --- Post-Processing Setup ---
        const composer = new EffectComposer(renderer);
        composer.setPixelRatio(params.dpr);
        
        const renderPass = new RenderPass(scene, camera);
        composer.addPass(renderPass);
        
        const ChromaticAberrationShader = {
            uniforms: {
                "tDiffuse": { value: null },
                "uAmount": { value: params.chromaticAberration }
            },
            vertexShader: `
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform sampler2D tDiffuse;
                uniform float uAmount;
                varying vec2 vUv;
                void main() {
                    // 1. Get original pixel color
                    vec4 baseColor = texture2D(tDiffuse, vUv);
                    
                    // 2. Create a mask based on pixel luminosity. 
                    // This identifies the bounds of the sphere and atmosphere.
                    float luma = max(baseColor.r, max(baseColor.g, baseColor.b));
                    
                    // Smooth transition at the dark edges to prevent sharp clipping
                    float mask = smoothstep(0.01, 0.1, luma);
                    
                    // 3. Radial distortion from the center of the screen
                    vec2 offset = (vUv - 0.5) * uAmount;
                    
                    float r = texture2D(tDiffuse, vUv + offset).r;
                    float g = texture2D(tDiffuse, vUv).g;
                    float b = texture2D(tDiffuse, vUv - offset).b;
                    
                    vec3 aberratedColor = vec3(r, g, b);
                    
                    // 4. Mix original and aberrated color based on the mask.
                    // This ensures the pure black background stays pure black and 
                    // prevents RGB channels from bleeding outside the sphere.
                    gl_FragColor = vec4(mix(baseColor.rgb, aberratedColor, mask), 1.0);
                }
            `
        };
        const caPass = new ShaderPass(ChromaticAberrationShader);
        composer.addPass(caPass);

        // 7. GUI Setup 
        const gui = new GUI({ title: 'Orb Settings' });
        
        gui.add(params, 'preset', Object.keys(presets)).name('Preset').onChange(val => {
            const p = presets[val];
            // Apply parameters to the state object
            Object.assign(params, p);
            
            // Update uniforms and materials
            uniforms.uPrimaryColor.value.set(params.primaryEnergy);
            atmosphereUniforms.uColor.value.set(params.primaryEnergy);
            uniforms.uSecondaryColor.value.set(params.secondaryEnergy);
            atmosphereUniforms.uGlow.value = params.atmosphereGlow;
            atmosphereUniforms.uLevel.value = params.atmosphereLevel;
            atmosphereMesh.scale.set(params.atmosphereScale, params.atmosphereScale, params.atmosphereScale);
            uniforms.uDensity.value = params.density;
            caPass.uniforms.uAmount.value = params.chromaticAberration;
            renderer.setPixelRatio(params.dpr);
            composer.setPixelRatio(params.dpr);
            uniforms.uInternalAnim.value = params.internalAnim;
            uniforms.uSmoothness.value = params.smoothness;
            uniforms.uAsymmetry.value = params.asymmetry;
            uniforms.uFractalIters.value = params.fractalIters;
            uniforms.uFractalScale.value = params.fractalScale;
            uniforms.uFractalDecay.value = params.fractalDecay;
            
            // Visually sync all GUI sliders
            gui.controllersRecursive().forEach(c => c.updateDisplay());
        });

        const styleFolder = gui.addFolder('Energy Style');
        styleFolder.addColor(params, 'primaryEnergy').name('Primary Color').onChange(val => {
            uniforms.uPrimaryColor.value.set(val);
            atmosphereUniforms.uColor.value.set(val);
        });
        styleFolder.addColor(params, 'secondaryEnergy').name('Secondary Color').onChange(val => uniforms.uSecondaryColor.value.set(val));
        styleFolder.add(params, 'atmosphereGlow', 0.0, 5.0, 0.01).name('Atmosphere Glow').onChange(val => atmosphereUniforms.uGlow.value = val);
        styleFolder.add(params, 'atmosphereLevel', 0.1, 1.0, 0.01).name('Atmosphere Level').onChange(val => atmosphereUniforms.uLevel.value = val);
        styleFolder.add(params, 'atmosphereScale', 1.0, 1.1, 0.001).name('Atmosphere Scale').onChange(val => atmosphereMesh.scale.set(val, val, val));
        styleFolder.add(params, 'speed', 0.1, 3.0, 0.1).name('Internal Speed');
        styleFolder.add(params, 'orbRotation', 0.0, 1.0, 0.01).name('Orb Auto-Rotation');
        styleFolder.add(params, 'density', 0.1, 3.0, 0.1).name('Global Density').onChange(val => uniforms.uDensity.value = val);
        styleFolder.add(params, 'chromaticAberration', 0.0, 0.05, 0.001).name('Chromatic Aberr.').onChange(val => caPass.uniforms.uAmount.value = val);
        styleFolder.add(params, 'dpr', 0.1, 2.0, 0.1).name('Resolution (DPR)').onChange(val => {
            renderer.setPixelRatio(val);
            composer.setPixelRatio(val);
        });

        const fractalFolder = gui.addFolder('Fractal Structure');
        fractalFolder.add(params, 'internalAnim', 0.0, 2.0, 0.01).name('Internal Anim Speed').onChange(val => uniforms.uInternalAnim.value = val);
        fractalFolder.add(params, 'smoothness', 0.0, 0.15, 0.001).name('Corner Smoothness').onChange(val => uniforms.uSmoothness.value = val);
        fractalFolder.add(params, 'asymmetry', 0.0, 1.0, 0.01).name('Asymmetry').onChange(val => uniforms.uAsymmetry.value = val);
        fractalFolder.add(params, 'fractalIters', 2, 12, 1).name('Iterations').onChange(val => uniforms.uFractalIters.value = val);
        fractalFolder.add(params, 'fractalScale', 0.3, 1.5, 0.01).name('Scale').onChange(val => uniforms.uFractalScale.value = val);
        fractalFolder.add(params, 'fractalDecay', -25.0, -5.0, 0.1).name('Energy Decay').onChange(val => uniforms.uFractalDecay.value = val);

        // Collapse the GUI panel by default
        gui.close();

        // 8. Handle Window Resize
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        });

        // 9. Animation Loop
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            const delta = clock.getDelta();
            uniforms.uTime.value += delta * params.speed;
            
            // Independent smooth external rotation
            orb.rotation.y += delta * params.orbRotation;
            orb.rotation.x += delta * (params.orbRotation * 0.5);
            
            // Update matrices to calculate accurate local camera position
            orb.updateMatrixWorld();
            
            // Transform world camera position into local space of the orb for the shader
            const localCam = new THREE.Vector3().copy(camera.position);
            orb.worldToLocal(localCam);
            uniforms.uLocalCamPos.value.copy(localCam);

            controls.update();
            composer.render(); // Rendering via EffectComposer instead of standard renderer
        }

        animate();