        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import GUI from 'lil-gui';

        // --- Scene Setup ---
        const scene = new THREE.Scene();
        scene.fog = new THREE.FogExp2(0x0a0f14, 0.0196); // Add subtle fog to blend the horizon
        scene.background = new THREE.Color(0x0a0f14);

        const camera = new THREE.PerspectiveCamera(35, window.innerWidth / window.innerHeight, 0.1, 1000);
        // Position camera for an isometric view
        camera.position.set(20, 15, 40);

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(1.0);
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        document.body.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.target.set(0, 0, 0);

        // --- Lighting ---
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
        scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 2.0);
        directionalLight.position.set(20, 30, 10);
        directionalLight.castShadow = true;
        // Optimize shadow map for performance
        directionalLight.shadow.mapSize.width = 2048;
        directionalLight.shadow.mapSize.height = 2048;
        directionalLight.shadow.camera.left = -15;
        directionalLight.shadow.camera.right = 15;
        directionalLight.shadow.camera.top = 15;
        directionalLight.shadow.camera.bottom = -15;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 100;
        directionalLight.shadow.bias = -0.001;
        scene.add(directionalLight);

        // Updated Lighting: Lowered height, moved closer, increased intensity and distance to be visible
        const pointLight1 = new THREE.PointLight('#4488ff', 100.0, 200);
        pointLight1.position.set(-25, 10, -25);
        scene.add(pointLight1);

        const pointLight2 = new THREE.PointLight('#ff7744', 100.0, 200);
        pointLight2.position.set(25, 10, 25);
        scene.add(pointLight2);

        const pointLight3 = new THREE.PointLight('#aa44ff', 100.0, 200);
        pointLight3.position.set(25, 10, -25);
        scene.add(pointLight3);

        const pointLight4 = new THREE.PointLight('#44ffaa', 100.0, 200);
        pointLight4.position.set(-25, 10, 25);
        scene.add(pointLight4);

        // --- Parameters & GUI State ---
        const params = {
            dpr: 1.0,             // Device Pixel Ratio
            // Grid & Geometry
            gridSizeX: 200,
            gridSizeZ: 200,
            thickness: 0.09595,
            boxHeight: 3.6505,
            gap: 0.265,
            
            // Wave Animation (Matched to screenshot + new params)
            speed: 0.3283,
            amplitude: 0.575,
            frequency: 0.30195,
            complexity: 1.376,
            tiltAmount: 0.835,
            sharpness: 1.5,       // Controls how sharp the wave peaks are
            direction: 0.785,     // Wave direction angle (in radians)
            inverse: true,        // Reverse wave direction
            
            // Material (Matched to screenshot)
            color: '#708ca9',
            metalness: 1.0,
            roughness: 0.38,

            // Environment & Lighting (New)
            fogDensity: 0.0165,
            enablePointLights: true,
            light1Color: '#4488ff',
            light2Color: '#ff7744',
            light3Color: '#aa44ff',
            light4Color: '#44ffaa',
            pointLightsIntensity: 100.0,
            ambientIntensity: 0.4,
            dirIntensity: 2.0
        };

        // --- Instanced Mesh Setup ---
        let instancedMesh;
        let dummy = new THREE.Object3D();
        const upVector = new THREE.Vector3(0, 1, 0);
        let normalVector = new THREE.Vector3();

        function createMesh() {
            if (instancedMesh) {
                scene.remove(instancedMesh);
                instancedMesh.geometry.dispose();
                instancedMesh.material.dispose();
            }

            // Create geometry (BoxGeometry is best for performance)
            const geometry = new THREE.BoxGeometry(params.thickness, params.boxHeight, params.thickness);
            
            // Shift origin to the base so scaling/rotation happens from the root
            geometry.translate(0, params.boxHeight / 2, 0);

            const material = new THREE.MeshStandardMaterial({
                color: params.color,
                metalness: params.metalness,
                roughness: params.roughness
            });

            const count = params.gridSizeX * params.gridSizeZ;
            instancedMesh = new THREE.InstancedMesh(geometry, material, count);
            instancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
            instancedMesh.castShadow = true;
            instancedMesh.receiveShadow = true;
            
            scene.add(instancedMesh);
        }

        createMesh();

        // --- GUI Setup ---
        const gui = new GUI({ title: 'Scene Settings' });
        gui.close(); // Collapse the main panel by default

        // Add DPR first
        gui.add(params, 'dpr', 0.5, 2.0, 0.1).name('DPR').onChange(v => renderer.setPixelRatio(v));

        const folderGrid = gui.addFolder('Grid & Geometry');
        // We use onFinishChange for expensive rebuilds so we don't drop frames during dragging
        folderGrid.add(params, 'gridSizeX', 10, 200, 1).name('Grid Width').onFinishChange(createMesh);
        folderGrid.add(params, 'gridSizeZ', 10, 200, 1).name('Grid Length').onFinishChange(createMesh);
        folderGrid.add(params, 'thickness', 0.05, 1.0).name('Stick Thickness').onFinishChange(createMesh);
        folderGrid.add(params, 'boxHeight', 0.1, 5.0).name('Stick Height').onFinishChange(createMesh);
        folderGrid.add(params, 'gap', 0.0, 1.0).name('Gap Between Sticks');

        const folderWave = gui.addFolder('Wave Animation');
        folderWave.add(params, 'speed', 0.0, 5.0).name('Animation Speed');
        folderWave.add(params, 'amplitude', 0.0, 5.0).name('Wave Amplitude');
        folderWave.add(params, 'frequency', 0.01, 1.0).name('Wave Frequency');
        folderWave.add(params, 'complexity', 0.0, 2.0).name('Wave Complexity');
        folderWave.add(params, 'tiltAmount', 0.0, 1.0).name('Tilt Amount');
        folderWave.add(params, 'sharpness', 0.1, 5.0).name('Wave Sharpness');
        folderWave.add(params, 'direction', 0.0, Math.PI * 2).name('Wave Direction');
        folderWave.add(params, 'inverse').name('Inverse Direction');

        const folderMaterial = gui.addFolder('Material Settings');
        folderMaterial.addColor(params, 'color').name('Color').onChange(c => instancedMesh.material.color.set(c));
        folderMaterial.add(params, 'metalness', 0.0, 1.0).name('Metalness').onChange(v => instancedMesh.material.metalness = v);
        folderMaterial.add(params, 'roughness', 0.0, 1.0).name('Roughness').onChange(v => instancedMesh.material.roughness = v);

        // New environment and lighting controls
        const folderEnv = gui.addFolder('Environment & Lights');
        folderEnv.add(params, 'fogDensity', 0.0, 0.1).name('Fog Density').onChange(v => scene.fog.density = v);
        folderEnv.add(params, 'enablePointLights').name('Enable Point Lights').onChange(v => {
            pointLight1.visible = v;
            pointLight2.visible = v;
            pointLight3.visible = v;
            pointLight4.visible = v;
        });
        folderEnv.addColor(params, 'light1Color').name('Light 1 Color').onChange(c => pointLight1.color.set(c));
        folderEnv.addColor(params, 'light2Color').name('Light 2 Color').onChange(c => pointLight2.color.set(c));
        folderEnv.addColor(params, 'light3Color').name('Light 3 Color').onChange(c => pointLight3.color.set(c));
        folderEnv.addColor(params, 'light4Color').name('Light 4 Color').onChange(c => pointLight4.color.set(c));
        folderEnv.add(params, 'pointLightsIntensity', 0.0, 100.0).name('Lights Intensity').onChange(v => {
            pointLight1.intensity = v;
            pointLight2.intensity = v;
            pointLight3.intensity = v;
            pointLight4.intensity = v;
        });
        folderEnv.add(params, 'ambientIntensity', 0.0, 2.0).name('Ambient Intensity').onChange(v => ambientLight.intensity = v);
        folderEnv.add(params, 'dirIntensity', 0.0, 5.0).name('Directional Intensity').onChange(v => directionalLight.intensity = v);

        // --- Math & Animation ---
        const clock = new THREE.Clock();

        // Calculate wave height at given coordinates
        function getWaveHeight(x, z, time) {
            // Directional Primary Wave
            const dirX = Math.cos(params.direction);
            const dirZ = Math.sin(params.direction);
            const dot = x * dirX + z * dirZ;
            
            const primaryPhase = Math.sin(dot * params.frequency + time);
            
            // Apply deformation to make peaks sharper and troughs wider
            const sharpWave = Math.pow((primaryPhase + 1) * 0.5, params.sharpness) * 2.0 - 1.0;
            
            let y = sharpWave;
            
            // Secondary wave (adds complexity/noise)
            const dist = Math.sqrt(x * x + z * z);
            y += Math.sin(dist * params.frequency * 1.5 - time * 1.5) * params.complexity;
            
            return y * params.amplitude;
        }

        function animate() {
            requestAnimationFrame(animate);
            
            // Apply inverse direction by changing time sign
            const timeMult = params.inverse ? -1 : 1;
            const time = clock.getElapsedTime() * params.speed * timeMult;
            
            // Dynamically calculate spacing based on thickness and gap
            const spacing = params.thickness + params.gap;
            const offsetX = (params.gridSizeX * spacing) / 2;
            const offsetZ = (params.gridSizeZ * spacing) / 2;
            const eps = 0.05; // Small delta for normal calculation

            let index = 0;

            for (let i = 0; i < params.gridSizeX; i++) {
                for (let j = 0; j < params.gridSizeZ; j++) {
                    const x = (i * spacing) - offsetX;
                    const z = (j * spacing) - offsetZ;

                    // 1. Calculate position
                    const y = getWaveHeight(x, z, time);
                    dummy.position.set(x, y, z);

                    // 2. Calculate normal to tilt the sticks
                    if (params.tiltAmount > 0) {
                        const yX = getWaveHeight(x + eps, z, time);
                        const yZ = getWaveHeight(x, z + eps, time);
                        
                        const slopeX = (yX - y) / eps;
                        const slopeZ = (yZ - y) / eps;

                        // Create normal vector from slopes
                        normalVector.set(-slopeX, 1.0, -slopeZ).normalize();
                        
                        // Blend straight up with normal direction
                        normalVector.lerp(upVector, 1.0 - params.tiltAmount).normalize();
                        
                        // Rotate object to match normal
                        dummy.quaternion.setFromUnitVectors(upVector, normalVector);
                    } else {
                        // Point straight up
                        dummy.quaternion.identity();
                    }

                    // 3. Update specific instance matrix
                    dummy.updateMatrix();
                    instancedMesh.setMatrixAt(index, dummy.matrix);
                    
                    index++;
                }
            }

            // Flag that matrices have changed and need to be uploaded to GPU
            instancedMesh.instanceMatrix.needsUpdate = true;

            controls.update();
            renderer.render(scene, camera);
        }

        // --- Window Resize Handling ---
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });

        // Start animation loop
        animate();