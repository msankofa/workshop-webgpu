        // --- 1. Scene Setup ---
        const scene = new THREE.Scene();
        
        // Orthographic camera for full-screen shader rendering
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        
        const renderer = new THREE.WebGLRenderer({ antialias: false }); // Disabled basic AA, using FXAA instead
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // --- 2. GUI Parameters & Logic ---
        const params = {
            dpr: 1.0,
            enableAA: true, // FXAA toggle
            speed: 1.0,
            sphereSize: 1.0,
            warpAmp: 0.6,
            warpFalloff: 1.2,
            warpFreq: 6.0,
            warpSteps: 10.0,
            warpVelocity: -0.4,
            noiseContrast: 0.6,
            color1: '#002aff',
            color2: '#0040ff',
            color3: '#4400ff',
            color4: '#330aff',
            
            // Texture properties
            textureMix: 1.0,
            textureScale: 0.6,
            textureDistortion: 1.0,
            
            // Lighting properties
            lightX: 1.0,
            lightY: 1.0,
            lightZ: -1.0,
            fillX: -1.0,
            fillY: -0.5,
            fillZ: -0.5,
            ambient: 0.09,
            diffuse: 0.6,
            fillLight: 0.2,
            specularPower: 32.0,
            specularIntensity: 0.5,
            
            // Functions for GUI buttons
            loadTexture: function() {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = 'image/*';
                input.onchange = e => {
                    const file = e.target.files[0];
                    if (!file) return;
                    
                    const reader = new FileReader();
                    reader.onload = event => {
                        const img = new Image();
                        img.onload = () => {
                            const tex = new THREE.Texture(img);
                            tex.wrapS = THREE.RepeatWrapping;
                            tex.wrapT = THREE.RepeatWrapping;
                            // Apply Anisotropic Filtering for better texture quality at extreme angles
                            tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
                            tex.needsUpdate = true;
                            
                            uniforms.uTexture.value = tex;
                            uniforms.uHasTexture.value = 1.0;
                        }
                        img.src = event.target.result;
                    };
                    reader.readAsDataURL(file);
                };
                input.click();
            },
            removeTexture: function() {
                uniforms.uHasTexture.value = 0.0;
                uniforms.uTexture.value = null;
            }
        };

        // --- 3. Shader Material ---
        const uniforms = {
            iTime: { value: 0.0 },
            iResolution: { value: new THREE.Vector2() },
            uSpeed: { value: params.speed },
            uSphereSize: { value: params.sphereSize },
            uWarpAmp: { value: params.warpAmp },
            uWarpFalloff: { value: params.warpFalloff },
            uWarpStartFreq: { value: params.warpFreq },
            uWarpSteps: { value: params.warpSteps },
            uWarpVelocity: { value: params.warpVelocity },
            uNoiseContrast: { value: params.noiseContrast },
            uDragRotate: { value: new THREE.Vector2(0, 0) },
            uColor1: { value: new THREE.Color(params.color1) },
            uColor2: { value: new THREE.Color(params.color2) },
            uColor3: { value: new THREE.Color(params.color3) },
            uColor4: { value: new THREE.Color(params.color4) },
            
            // Texture Uniforms
            uTexture: { value: null },
            uHasTexture: { value: 0.0 },
            uTextureMix: { value: params.textureMix },
            uTextureScale: { value: params.textureScale },
            uTextureDistortion: { value: params.textureDistortion },
            
            // Lighting Uniforms
            uLightDir: { value: new THREE.Vector3(params.lightX, params.lightY, params.lightZ) },
            uFillDir: { value: new THREE.Vector3(params.fillX, params.fillY, params.fillZ) },
            uAmbient: { value: params.ambient },
            uDiffuse: { value: params.diffuse },
            uFillLight: { value: params.fillLight },
            uSpecularPower: { value: params.specularPower },
            uSpecularIntensity: { value: params.specularIntensity }
        };

        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform float iTime;
            uniform vec2 iResolution;
            
            // GUI Uniforms
            uniform float uSpeed;
            uniform float uSphereSize;
            uniform float uWarpAmp;
            uniform float uWarpFalloff;
            uniform float uWarpStartFreq;
            uniform float uWarpSteps;
            uniform float uWarpVelocity;
            uniform float uNoiseContrast;
            uniform vec2 uDragRotate;
            
            // Color Uniforms
            uniform vec3 uColor1;
            uniform vec3 uColor2;
            uniform vec3 uColor3;
            uniform vec3 uColor4;

            // Texture Uniforms
            uniform sampler2D uTexture;
            uniform float uHasTexture;
            uniform float uTextureMix;
            uniform float uTextureScale;
            uniform float uTextureDistortion;

            // Lighting Uniforms
            uniform vec3 uLightDir;
            uniform vec3 uFillDir;
            uniform float uAmbient;
            uniform float uDiffuse;
            uniform float uFillLight;
            uniform float uSpecularPower;
            uniform float uSpecularIntensity;

            varying vec2 vUv;

            #define MAX_STEPS 250
            #define SURF_DIST 0.001
            #define MAX_DIST 12.6
            #define PI 3.14159265359

            // 3D Pseudo-Random Number Generator
            float prng3D(vec3 p) {
                return fract(sin(dot(p, vec3(12.9898, 78.283, 37.919))) * 43758.7053);
            }

            // 3D Value Noise (Seamless)
            float valNoise3D(vec3 p) {
                vec3 i = floor(p);
                vec3 f = fract(p);
                vec3 u = f * f * (2.4 - 1.4 * f);
                
                float n000 = prng3D(i + vec3(0.0, 0.0, 0.0));
                float n100 = prng3D(i + vec3(1.0, 0.0, 0.0));
                float n010 = prng3D(i + vec3(0.0, 1.0, 0.0));
                float n110 = prng3D(i + vec3(1.0, 1.0, 0.0));
                float n001 = prng3D(i + vec3(0.0, 0.0, 1.0));
                float n101 = prng3D(i + vec3(1.0, 0.0, 1.0));
                float n011 = prng3D(i + vec3(0.0, 1.0, 1.0));
                float n111 = prng3D(i + vec3(1.0, 1.0, 1.0));
                
                float nx00 = mix(n000, n100, u.x);
                float nx10 = mix(n010, n110, u.x);
                float nx01 = mix(n001, n101, u.x);
                float nx11 = mix(n011, n111, u.x);
                
                float nxy0 = mix(nx00, nx10, u.y);
                float nxy1 = mix(nx01, nx11, u.y);
                
                return pow(mix(nxy0, nxy1, u.z), uNoiseContrast);
            }

            // Dynamic color palette mapped to 3D space
            vec3 getDynamicIrradiance(vec3 coord, float offset) {
                float T = iTime * uSpeed;
                float t = fract(T * 0.0 + (coord.x + coord.y + coord.z) * 0.27 + pow(offset, 4.6));
                
                t *= 4.0;
                float stage = floor(t);
                float blend = smoothstep(0.0, 1.4, fract(t));
                
                if (stage == 0.0) return mix(uColor1, uColor2, blend);
                if (stage == 1.0) return mix(uColor2, uColor3, blend);
                if (stage == 2.0) return mix(uColor3, uColor4, blend);
                return mix(uColor4, uColor1, blend);
            }

            // Computes only the structural domain warping
            vec3 warpPosition(vec3 pos) {
                pos *= 0.4; 
                float T = iTime * uSpeed;
                
                float currentFreq = uWarpStartFreq;
                float pwr = pow(uWarpFalloff, uWarpStartFreq);
                float basePhase = T * uWarpVelocity;

                for (float iter = 0.0; iter < 20.0; iter++) {
                    if (iter >= uWarpSteps) break;
                    
                    float phaseX = basePhase + currentFreq * 0.18; 
                    float phaseY = basePhase + currentFreq * 0.21; 
                    float phaseZ = basePhase + currentFreq * 0.24; 
                    
                    vec3 offset;
                    offset.x = uWarpAmp * sin(pos.y * pwr + phaseX) / pwr;
                    offset.y = uWarpAmp * sin(pos.z * pwr + phaseY) / pwr;
                    offset.z = uWarpAmp * sin(pos.x * pwr + phaseZ) / pwr;
                    pos += offset;
                    
                    currentFreq += 1.0;
                    pwr *= uWarpFalloff; 
                }
                
                return pos;
            }

            // Separated noise functions
            float getFractalHeight(vec3 warpedPos) {
                return valNoise3D(warpedPos * 3.1 + (iTime * uSpeed) * 0.3);
            }
            
            float getFractalChroma(vec3 warpedPos) {
                return valNoise3D(warpedPos * 1.5 + (iTime * uSpeed) * 0.6 + 20.0);
            }

            // Calculate rotation once for the whole space
            vec3 transformToObjSpace(vec3 p) {
                mat2 rotY = mat2(cos(uDragRotate.x), -sin(uDragRotate.x), sin(uDragRotate.x), cos(uDragRotate.x));
                mat2 rotX = mat2(cos(uDragRotate.y), -sin(uDragRotate.y), sin(uDragRotate.y), cos(uDragRotate.y));
                
                float rotTime = iTime * uSpeed * 0.15;
                mat2 autoRot = mat2(cos(rotTime), -sin(rotTime), sin(rotTime), cos(rotTime));
                
                p.yz *= rotX; // Pitch
                p.xz *= rotY; // Yaw
                p.xz *= autoRot; // Auto spin
                
                return p;
            }

            // SDF mapping
            float mapGeometry(vec3 p) {
                float radius = length(p);
                vec3 dir = p / radius;
                
                vec3 warpedPos = warpPosition(dir);
                float heightNoise = getFractalHeight(warpedPos);
                float heightMap = smoothstep(0.2, 0.8, heightNoise);
                
                float surfaceDist = radius - uSphereSize - (heightMap * 0.35);
                return surfaceDist * 0.35; 
            }

            // Surface normal
            vec3 calculateNormal(vec3 p) {
                vec2 e = vec2(0.01, 0.0);
                vec3 n = mapGeometry(p) - vec3(
                    mapGeometry(p - e.xyy),
                    mapGeometry(p - e.yxy),
                    mapGeometry(p - e.yyx)
                );
                return normalize(n);
            }

            void mainImage(out vec4 fragColor, in vec2 fragCoord) {
                vec2 st = (2.0 * fragCoord - iResolution.xy) / iResolution.y;
                
                vec3 ro = transformToObjSpace(vec3(0.0, 0.0, -2.8));
                vec3 rd = transformToObjSpace(normalize(vec3(st, 1.0)));
                
                vec3 finalRender = vec3(0.0);
                float distTraveled = 0.0;
                vec3 hitPos;
                bool isHit = false;
                
                for (int i = 0; i < MAX_STEPS; i++) {
                    hitPos = ro + rd * distTraveled;
                    float d = mapGeometry(hitPos);
                    
                    if (abs(d) < SURF_DIST) {
                        isHit = true;
                        break;
                    }
                    if (distTraveled > MAX_DIST) {
                        break;
                    }
                    
                    distTraveled += d;
                    
                    // Anti-black-hole fallback
                    if (i == MAX_STEPS - 1) {
                        isHit = true;
                    }
                }
                
                if (isHit) {
                    vec3 normal = calculateNormal(hitPos);
                    
                    vec3 dir = normalize(hitPos);
                    vec3 warpedPos = warpPosition(dir);
                    
                    float heightNoise = getFractalHeight(warpedPos);
                    float chromaShift = getFractalChroma(warpedPos); 
                    
                    // Base procedural albedo
                    vec3 albedo = getDynamicIrradiance(dir, chromaShift);
                    
                    // APPLY TEXTURE
                    if (uHasTexture > 0.5) {
                        // Blend between clean sphere mapping and fractal-warped mapping
                        vec3 mappingDir = normalize(mix(dir, warpedPos, uTextureDistortion));
                        
                        // Convert 3D direction to 2D Spherical UVs
                        vec2 sphereUV = vec2(
                            atan(mappingDir.z, mappingDir.x) / (2.0 * PI) + 0.5,
                            asin(mappingDir.y) / PI + 0.5
                        );
                        
                        // Apply Scale
                        sphereUV *= uTextureScale;
                        
                        // Sample texture and mix with procedural color
                        vec3 texColor = texture2D(uTexture, sphereUV).rgb;
                        albedo = mix(albedo, texColor, uTextureMix);
                    }
                    
                    float patternContrast = smoothstep(0.4, 0.8, heightNoise);
                    vec3 surfaceColor = (0.4 + patternContrast * 1.3) * albedo;
                    
                    vec3 lightDir = transformToObjSpace(normalize(uLightDir));
                    vec3 fillDir  = transformToObjSpace(normalize(uFillDir));
                    vec3 viewDir  = -rd; 
                    
                    float diffuseHit = max(dot(normal, lightDir), -0.8);
                    float fillHit = max(dot(normal, fillDir), 0.0);
                    
                    float ambient = uAmbient;
                    float diffuse = diffuseHit * uDiffuse + fillHit * uFillLight;
                    
                    finalRender = surfaceColor * (diffuse + ambient);
                    
                    vec3 halfVector = normalize(lightDir + viewDir);
                    float specular = pow(max(dot(normal, halfVector), 0.0), uSpecularPower);
                    finalRender += vec3(1.0, 0.9, 0.8) * specular * uSpecularIntensity * patternContrast;
                    
                    float rim = 1.2 - max(dot(normal, viewDir), 0.4);
                    rim = smoothstep(0.6, 1.0, rim);
                    finalRender += albedo * rim * 0.5;
                }
                
                fragColor = vec4(finalRender, 1.0);
            }

            void main() {
                mainImage(gl_FragColor, vUv * iResolution.xy);
            }
        `;

        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms
        });

        // Full screen quad
        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- 4. Post-Processing Pipeline (FXAA) ---
        const composer = new THREE.EffectComposer(renderer);
        const renderPass = new THREE.RenderPass(scene, camera);
        composer.addPass(renderPass);

        const fxaaPass = new THREE.ShaderPass(THREE.FXAAShader);
        composer.addPass(fxaaPass);

        // --- 5. Render Resolution Handling ---
        function updateResolution() {
            // Update Base Renderer
            renderer.setPixelRatio(params.dpr);
            renderer.setSize(window.innerWidth, window.innerHeight);
            
            // Update Post-Processing Composer
            composer.setPixelRatio(params.dpr);
            composer.setSize(window.innerWidth, window.innerHeight);
            
            // Pass resolution to the main fractal shader
            const width = renderer.domElement.width;
            const height = renderer.domElement.height;
            uniforms.iResolution.value.set(width, height);

            // Pass exact physical pixel resolution to FXAA shader to detect edges properly
            fxaaPass.material.uniforms['resolution'].value.x = 1 / width;
            fxaaPass.material.uniforms['resolution'].value.y = 1 / height;
        }
        
        window.addEventListener('resize', updateResolution);
        updateResolution();

        // --- 6. Mouse Drag Interaction ---
        let isDragging = false;
        let previousMousePosition = { x: 0, y: 0 };
        
        const targetRotation = { x: 0, y: 0 };
        const currentRotation = { x: 0, y: 0 };
        const dragSensitivity = 0.005;
        const damping = 0.05; 

        document.body.addEventListener('pointerdown', (e) => {
            isDragging = true;
            previousMousePosition = { x: e.offsetX, y: e.offsetY };
        });

        document.body.addEventListener('pointermove', (e) => {
            if (isDragging) {
                const deltaMove = {
                    x: e.offsetX - previousMousePosition.x,
                    y: e.offsetY - previousMousePosition.y
                };

                targetRotation.x -= deltaMove.x * dragSensitivity; // Inverted horizontal
                targetRotation.y += deltaMove.y * dragSensitivity;

                previousMousePosition = { x: e.offsetX, y: e.offsetY };
            }
        });

        window.addEventListener('pointerup', () => {
            isDragging = false;
        });

        // --- 7. GUI Initialization ---
        const gui = new lil.GUI({ title: 'Settings' });
        gui.close(); 

        // Display/System Folder
        const fDisplay = gui.addFolder('Display & Speed');
        fDisplay.add(params, 'dpr', 0.5, 2.0, 0.1).name('DPR').onChange(updateResolution);
        fDisplay.add(params, 'enableAA').name('Anti-Aliasing (FXAA)').onChange(v => fxaaPass.enabled = v);
        fDisplay.add(params, 'speed', 0.0, 3.0, 0.1).name('Animation Speed').onChange(v => uniforms.uSpeed.value = v);
        fDisplay.add(params, 'sphereSize', 0.5, 2.0, 0.1).name('Sphere Size').onChange(v => uniforms.uSphereSize.value = v);

        // Deformation Folder
        const fWarp = gui.addFolder('Deformation & Noise');
        fWarp.add(params, 'warpAmp', 0.0, 1.5, 0.05).name('Warp Amplitude').onChange(v => uniforms.uWarpAmp.value = v);
        fWarp.add(params, 'warpFalloff', 0.5, 2.0, 0.1).name('Warp Falloff').onChange(v => uniforms.uWarpFalloff.value = v);
        fWarp.add(params, 'warpFreq', 1.0, 10.0, 0.1).name('Start Freq').onChange(v => uniforms.uWarpStartFreq.value = v);
        fWarp.add(params, 'warpSteps', 1.0, 20.0, 1.0).name('Warp Steps').onChange(v => uniforms.uWarpSteps.value = v);
        fWarp.add(params, 'warpVelocity', -1.0, 1.0, 0.1).name('Warp Velocity').onChange(v => uniforms.uWarpVelocity.value = v);
        fWarp.add(params, 'noiseContrast', 0.1, 2.0, 0.1).name('Noise Contrast').onChange(v => uniforms.uNoiseContrast.value = v);

        // Colors Folder
        const fColors = gui.addFolder('Procedural Palette');
        fColors.addColor(params, 'color1').name('Color 1').onChange(v => uniforms.uColor1.value.set(v));
        fColors.addColor(params, 'color2').name('Color 2').onChange(v => uniforms.uColor2.value.set(v));
        fColors.addColor(params, 'color3').name('Color 3').onChange(v => uniforms.uColor3.value.set(v));
        fColors.addColor(params, 'color4').name('Color 4').onChange(v => uniforms.uColor4.value.set(v));

        // Texture Mapping Folder
        const fTex = gui.addFolder('Texture Mapping');
        fTex.add(params, 'loadTexture').name('Load Image...');
        fTex.add(params, 'removeTexture').name('Remove Image');
        fTex.add(params, 'textureMix', 0.0, 1.0, 0.05).name('Mix Strength').onChange(v => uniforms.uTextureMix.value = v);
        fTex.add(params, 'textureScale', 0.1, 5.0, 0.1).name('Scale').onChange(v => uniforms.uTextureScale.value = v);
        fTex.add(params, 'textureDistortion', 0.0, 1.0, 0.05).name('Distortion').onChange(v => uniforms.uTextureDistortion.value = v);

        // Lighting Folder
        const fLight = gui.addFolder('Lighting');
        fLight.add(params, 'lightX', -5.0, 5.0, 0.1).name('Main Light X').onChange(v => uniforms.uLightDir.value.x = v);
        fLight.add(params, 'lightY', -5.0, 5.0, 0.1).name('Main Light Y').onChange(v => uniforms.uLightDir.value.y = v);
        fLight.add(params, 'lightZ', -5.0, 5.0, 0.1).name('Main Light Z').onChange(v => uniforms.uLightDir.value.z = v);
        fLight.add(params, 'fillX', -5.0, 5.0, 0.1).name('Fill Light X').onChange(v => uniforms.uFillDir.value.x = v);
        fLight.add(params, 'fillY', -5.0, 5.0, 0.1).name('Fill Light Y').onChange(v => uniforms.uFillDir.value.y = v);
        fLight.add(params, 'fillZ', -5.0, 5.0, 0.1).name('Fill Light Z').onChange(v => uniforms.uFillDir.value.z = v);
        fLight.add(params, 'ambient', 0.0, 0.2, 0.01).name('Ambient Int.').onChange(v => uniforms.uAmbient.value = v);
        fLight.add(params, 'diffuse', 0.0, 2.0, 0.05).name('Diffuse Int.').onChange(v => uniforms.uDiffuse.value = v);
        fLight.add(params, 'fillLight', 0.0, 1.0, 0.05).name('Fill Int.').onChange(v => uniforms.uFillLight.value = v);
        fLight.add(params, 'specularPower', 1.0, 128.0, 1.0).name('Specular Power').onChange(v => uniforms.uSpecularPower.value = v);
        fLight.add(params, 'specularIntensity', 0.0, 2.0, 0.05).name('Specular Int.').onChange(v => uniforms.uSpecularIntensity.value = v);

        // --- 8. Render Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            uniforms.iTime.value = clock.getElapsedTime();
            
            // Smoothly interpolate rotation (Lerp)
            currentRotation.x += (targetRotation.x - currentRotation.x) * damping;
            currentRotation.y += (targetRotation.y - currentRotation.y) * damping;
            
            uniforms.uDragRotate.value.set(currentRotation.x, currentRotation.y);
            
            // Use the EffectComposer to render the scene WITH post-processing (FXAA)
            composer.render();
        }

        animate();