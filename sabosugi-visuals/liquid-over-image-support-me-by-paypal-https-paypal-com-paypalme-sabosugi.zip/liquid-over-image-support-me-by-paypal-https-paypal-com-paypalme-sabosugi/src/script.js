        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform float uTime;
            uniform vec2 uResolution;
            uniform sampler2D uTexture;
            uniform vec2 uTextureSize;
            
            // Uniforms for advanced GUI control
            uniform float uDistortion;
            uniform float uFractalAlpha;
            uniform float uSpeed;
            uniform float uAccumBase;
            uniform vec3 uColor;
            uniform float uSeed;
            
            // Interaction uniforms
            uniform vec2 uMouse;
            uniform float uHoverActive;
            uniform float uHoverIntensity; // Controls fade in/out
            uniform float uHoverForce;     // Controls push strength
            
            varying vec2 vUv;
            
            // Core generator constants
            const float SCALE_FACTOR = -2.53681469282;
            const int LOOP_COUNT = 38;
            const float WEIGHT = 0.0040;
            const float ITER_INV = 0.02631578947; // 1.0 / 38.0

            // Calculates coordinate distortion based on current phase
            vec2 getOffset(vec2 currentCoord, float currentPhase) {
                float phX = currentPhase - currentCoord.x;
                float phY = currentPhase + currentCoord.y;
                return vec2(cos(phX) + sin(phY), sin(currentPhase - currentCoord.y) + cos(currentPhase + currentCoord.x));
            }

            void main() {
                vec2 normUv = vUv;
                
                // 0. MOUSE INTERACTION (HOVER PUSH)
                vec2 aspectVec = vec2(uResolution.x / uResolution.y, 1.0);
                vec2 mouseDelta = (normUv - uMouse) * aspectVec;
                float mouseDist = length(mouseDelta);
                
                // Strength calculation incorporating uHoverIntensity for smooth fade in/out
                float pushForce = exp(-mouseDist * mouseDist * 20.0) * uHoverForce * uHoverActive * uHoverIntensity;
                
                // Edge fade mask: smoothly disables the push force at the screen boundaries
                float edgeMask = smoothstep(0.0, 0.12, normUv.x) * smoothstep(1.0, 0.88, normUv.x) *
                                 smoothstep(0.0, 0.12, normUv.y) * smoothstep(1.0, 0.88, normUv.y);
                
                normUv += mouseDelta * (pushForce * edgeMask);

                // 1. FRACTAL GENERATION
                float timeBase = (uTime * uSpeed) + 6.5 + (uSeed * 0.1);
                
                // Apply seed to base grid
                vec2 baseGrid = fract(normUv) * SCALE_FACTOR - (300.0 + uSeed);
                vec2 shiftVec = baseGrid;
                
                float accum = uAccumBase;

                for (int iter = 0; iter < LOOP_COUNT; iter++) {
                    float phase = timeBase * (0.6 - (0.94 / (float(iter) + 5.0)));
                    shiftVec = baseGrid + getOffset(shiftVec, phase);
                    
                    vec2 denominator = vec2(sin(shiftVec.x + phase), cos(shiftVec.y + phase));
                    vec2 lengthVec = (baseGrid * WEIGHT) / denominator;
                    
                    accum += 1.1 / length(lengthVec);
                }
                
                accum *= ITER_INV;
                float finalIntensity = 1.52 - pow(accum, 0.49);
                
                // Raw structural pattern of the fractal
                float pattern = pow(abs(finalIntensity), 11.6);

                // 2. IMAGE COVER MODE & UV CALCULATION
                float screenAspect = uResolution.x / uResolution.y;
                float texAspect = uTextureSize.x / uTextureSize.y;
                
                vec2 texUV = normUv;
                
                // Calculate cover proportions
                if (screenAspect < texAspect) {
                    float scale = screenAspect / texAspect;
                    texUV.x = (texUV.x - 0.5) * scale + 0.5;
                } else {
                    float scale = texAspect / screenAspect;
                    texUV.y = (texUV.y - 0.5) * scale + 0.5;
                }

                // ZOOM FIX: Scale down the UVs slightly to hide edge stretching 
                texUV = (texUV - 0.5) * 0.92 + 0.5;

                // 3. DISPLACEMENT & DISTORTION
                // The distortion is driven by the fractal shift (which is affected by the mouse)
                vec2 pureDisplacement = (shiftVec - baseGrid) * finalIntensity;
                vec2 distortedUV = texUV + (pureDisplacement * uDistortion);
                
                vec4 bgImageColor = texture2D(uTexture, distortedUV);

                // 4. ADVANCED VOLUMETRIC BLENDING (Absorption + Screen)
                // This behaves like real translucent liquid over a surface.
                
                // A. Light Absorption (Depth)
                // The 'valleys' of the fractal act as deep water, tinting the image below.
                // We calculate how deep the water is (inverse of pattern) and apply a colored tint (Multiply-like).
                float depth = clamp(1.0 - (pattern * 0.5), 0.0, 1.0);
                vec3 tintedBackground = mix(bgImageColor.rgb, bgImageColor.rgb * uColor, depth * 0.4);
                
                // B. Caustic Highlights (Screen)
                // The 'crests' of the fractal catch the light. 
                // We scale uFractalAlpha by 2.5 so the 0.0-0.5 UI slider gives a rich glow.
                vec3 highlights = uColor * pattern * (uFractalAlpha * 2.5);
                
                // C. Screen Blend Formula: 1.0 - (1.0 - Base) * (1.0 - Blend)
                // Screen adds the glowing highlights beautifully without grey-washing or instantly clipping to pure white.
                vec3 finalOutput = 1.0 - (1.0 - tintedBackground) * (1.0 - clamp(highlights, 0.0, 1.0));
                
                gl_FragColor = vec4(finalOutput, 1.0);
            }
        `;

        const canvas = document.getElementById('webgl-canvas');
        const renderer = new THREE.WebGLRenderer({ canvas, antialias: false });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.setSize(window.innerWidth, window.innerHeight);

        const scene = new THREE.Scene();
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        const geometry = new THREE.PlaneGeometry(2, 2);

        const textureLoader = new THREE.TextureLoader(); 
        textureLoader.setCrossOrigin('anonymous');
        
        const defaultImageUrl = 'https://images.pexels.com/photos/36763372/pexels-photo-36763372.jpeg';
        let customTexture = null;

        // Generate a random seed on load
        const initialSeed = Math.random() * 1000.0;

        // Perfected default settings from screenshot
        const defaultSettings = {
            distortion: 0.0025,
            fractalAlpha: 0.172,
            speed: 0.45,
            accumBase: 4.13,
            color: new THREE.Color('#1e3048'),
            hoverCursor: true,
            hoverForce: 0.1
        }; 

        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms: {
                uTime: { value: 0.0 },
                uResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
                uTexture: { value: null },
                uTextureSize: { value: new THREE.Vector2(1, 1) },
                uDistortion: { value: defaultSettings.distortion },
                uFractalAlpha: { value: defaultSettings.fractalAlpha },
                uSpeed: { value: defaultSettings.speed },
                uAccumBase: { value: defaultSettings.accumBase },
                uColor: { value: defaultSettings.color.clone() },
                uMouse: { value: new THREE.Vector2(0.5, 0.5) },
                uHoverActive: { value: defaultSettings.hoverCursor ? 1.0 : 0.0 },
                uHoverIntensity: { value: 0.0 },
                uHoverForce: { value: defaultSettings.hoverForce },
                uSeed: { value: initialSeed }
            },
            depthWrite: false,
            depthTest: false
        });

        textureLoader.load(defaultImageUrl, (texture) => {
            texture.minFilter = THREE.LinearFilter;
            texture.magFilter = THREE.LinearFilter;
            texture.wrapS = THREE.ClampToEdgeWrapping;
            texture.wrapT = THREE.ClampToEdgeWrapping;
            
            material.uniforms.uTexture.value = texture;
            material.uniforms.uTextureSize.value.set(texture.image.width, texture.image.height);
            customTexture = texture;
        });

        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        const gui = new lil.GUI({ title: 'Scene Settings' });
        
        const params = {
            uploadImage: () => document.getElementById('file-input').click(),
            randomizeSeed: () => { material.uniforms.uSeed.value = Math.random() * 1000.0; },
            hoverCursor: defaultSettings.hoverCursor,
            hoverForce: defaultSettings.hoverForce,
            speed: defaultSettings.speed,
            accumBase: defaultSettings.accumBase,
            distortion: defaultSettings.distortion,
            fractalAlpha: defaultSettings.fractalAlpha,
            color: '#' + defaultSettings.color.getHexString()
        };

        gui.add(params, 'uploadImage').name('🖼️ Upload Image');
        gui.add(params, 'randomizeSeed').name('🎲 Randomize Seed');
        gui.add(params, 'hoverCursor').name('👆 Hover Cursor').onChange(v => material.uniforms.uHoverActive.value = v ? 1.0 : 0.0);
        gui.add(params, 'hoverForce', 0.0, 1.0).name('Hover Intensity').onChange(v => material.uniforms.uHoverForce.value = v);
        
        const folderFractal = gui.addFolder('Fractal Properties');
        folderFractal.add(params, 'speed', 0.0, 2.0).name('Animation Speed').onChange(v => material.uniforms.uSpeed.value = v);
        folderFractal.add(params, 'accumBase', 1.0, 6.0).name('Fluid Thickness').onChange(v => material.uniforms.uAccumBase.value = v);
        folderFractal.addColor(params, 'color').name('Fluid Tint').onChange(v => material.uniforms.uColor.value.set(v));
        
        const folderEffect = gui.addFolder('Post Processing');
        folderEffect.add(params, 'distortion', 0.0, 0.02).name('Distortion Force').onChange(v => material.uniforms.uDistortion.value = v);
        folderEffect.add(params, 'fractalAlpha', 0.0, 0.5).name('Brightness').onChange(v => material.uniforms.uFractalAlpha.value = v);
        
        gui.close();

        const targetMouse = new THREE.Vector2(0.5, 0.5);
        const currentMouse = new THREE.Vector2(0.5, 0.5);
        let targetHoverIntensity = 0.0;
        let currentHoverIntensity = 0.0;

        function updateMouseUniform(x, y, snap = false) {
            if (params.hoverCursor) {
                targetMouse.set(
                    x / window.innerWidth,
                    1.0 - (y / window.innerHeight)
                );
                
                // If snapping or just entering, immediately move the physics point
                if (snap || currentHoverIntensity < 0.01) {
                    currentMouse.copy(targetMouse);
                }
                
                targetHoverIntensity = 1.0;
            }
        }

        window.addEventListener('mousemove', (e) => {
            updateMouseUniform(e.clientX, e.clientY);
        });
        
        window.addEventListener('mouseenter', (e) => {
            updateMouseUniform(e.clientX, e.clientY, true);
        });

        window.addEventListener('touchmove', (e) => {
            if (e.touches.length > 0) {
                updateMouseUniform(e.touches[0].clientX, e.touches[0].clientY);
            }
        });
        
        window.addEventListener('touchstart', (e) => {
            if (e.touches.length > 0) {
                updateMouseUniform(e.touches[0].clientX, e.touches[0].clientY, true);
            }
        });

        window.addEventListener('mouseout', (e) => {
            // Only fade out if actually leaving the browser window, not just hovering over GUI
            if (!e.relatedTarget) {
                targetHoverIntensity = 0.0; 
            }
        });
        
        window.addEventListener('touchend', () => {
            targetHoverIntensity = 0.0;
        });

        const fileInput = document.getElementById('file-input');
        fileInput.addEventListener('change', (event) => {
            const file = event.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (e) => {
                const dataUrl = e.target.result;
                textureLoader.load(dataUrl, (texture) => {
                    texture.minFilter = THREE.LinearFilter;
                    texture.magFilter = THREE.LinearFilter;
                    texture.wrapS = THREE.ClampToEdgeWrapping;
                    texture.wrapT = THREE.ClampToEdgeWrapping;
                    
                    if (customTexture) customTexture.dispose();
                    customTexture = texture;
                    
                    material.uniforms.uTexture.value = texture;
                    material.uniforms.uTextureSize.value.set(texture.image.width, texture.image.height);
                });
            };
            reader.readAsDataURL(file);
        });

        window.addEventListener('resize', () => {
            const width = window.innerWidth;
            const height = window.innerHeight;
            
            renderer.setSize(width, height);
            material.uniforms.uResolution.value.set(width, height);
        });

        const clock = new THREE.Clock();
        
        function animate() {
            requestAnimationFrame(animate);
            material.uniforms.uTime.value = clock.getElapsedTime();
            
            // Smoothly animate the hover intensity (Fade in / Fade out)
            currentHoverIntensity += (targetHoverIntensity - currentHoverIntensity) * 0.05;
            material.uniforms.uHoverIntensity.value = currentHoverIntensity;
            
            // Smooth mouse interpolation for movement
            currentMouse.lerp(targetMouse, 0.08);
            material.uniforms.uMouse.value.copy(currentMouse);

            renderer.render(scene, camera);
        }

        window.onload = animate;