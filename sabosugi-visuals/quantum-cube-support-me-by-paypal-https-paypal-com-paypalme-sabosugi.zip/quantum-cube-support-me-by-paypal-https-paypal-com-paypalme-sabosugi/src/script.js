        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform vec2 iResolution;
            uniform float iTime;
            uniform vec3 uCamPos;
            
            // GUI Parameters
            uniform bool uAutoRotate;
            uniform float uRotX;
            uniform float uRotY;
            uniform float uFractalSpeed;
            uniform float uMorphSpeed;
            uniform float uScaleFactor;
            uniform float uCubeSize;
            uniform float uEdgeGlow;
            
            // Colors
            uniform vec3 uColor1;
            uniform vec3 uColor2;
            uniform vec3 uColor3;

            varying vec2 vUv;

            // Helper matrix for 2D rotation
            mat2 rot2d(float angle) {
                float s = sin(angle), c = cos(angle);
                return mat2(c, -s, s, c);
            }

            // Signed Distance Function for a Cube
            float sdBox(vec3 p, vec3 b) {
                vec3 q = abs(p) - b;
                return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
            }

            // Single centered cube definition (dynamically sized and rotated)
            float mapCube(vec3 p) {
                vec3 q = p;
                if(uAutoRotate) {
                    q.xy *= rot2d(iTime * uRotX);
                    q.yz *= rot2d(iTime * uRotY);
                }
                return sdBox(q, vec3(uCubeSize));
            }

            // Estimates surface normals for reflections
            vec3 calcNormal(vec3 p) {
                vec2 e = vec2(0.001, 0.0);
                return normalize(vec3(
                    mapCube(p + e.xyy) - mapCube(p - e.xyy),
                    mapCube(p + e.yxy) - mapCube(p - e.yxy),
                    mapCube(p + e.yyx) - mapCube(p - e.yyx)
                ));
            }

            // Sharp, Crystalline High-Tech Fractal (KIFS) EXACTLY FROM CODE_4
            vec3 calcCrystalFractal(vec3 p, vec3 cubeNormal) {
                vec3 q = p * 0.1; 
                
                // Keep fractal stable when the outer shell rotates
                if(uAutoRotate) {
                    q.yz *= rot2d(-iTime * uRotY);
                    q.xy *= rot2d(-iTime * uRotX);
                }
                
                // Smooth and steady rotation of the internal crystal structure
                q.xz *= rot2d(iTime * 0.08 * uFractalSpeed);
                q.yz *= rot2d(iTime * 0.05 * uFractalSpeed);
                
                float scaleFactor = 0.3;
                vec3 colorAccum = vec3(0.0);
                
                // 8 iterations of sharp kaleidoscopic folding
                for(int i = 0; i < 8; i++) {
                    // Micro-morphing: strictly subtle changes in the folding distances
                    vec3 morphOffset = vec3(0.14, 0.22, 0.14) + sin(iTime * 0.4 * uMorphSpeed + float(i) * 1.5) * 0.003;
                    
                    // Absolute value folding creates perfectly sharp crystal shards
                    q = abs(q) - morphOffset;
                    
                    // Tetrahderal sorting for razor-sharp crystalline intersections
                    if (q.x < q.y) q.xy = q.yx;
                    if (q.x < q.z) q.xz = q.zx;
                    if (q.y < q.z) q.yz = q.zy;
                    
                    // Micro-morphing: very slight evolution of the angles to shift the shape
                    float angleShiftXY = sin(iTime * 0.3 * uMorphSpeed + float(i)) * 0.015;
                    float angleShiftXZ = cos(iTime * 0.25 * uMorphSpeed - float(i)) * 0.015;
                    
                    // 45-degree rotation (0.785 rad) forces octagonal/diamond crystal symmetry
                    q.xy *= rot2d(0.785 + float(i) * 0.02 + angleShiftXY);
                    q.xz *= rot2d(0.35 + angleShiftXZ);
                    
                    // Non-uniform scaling to elongate the structures into sharp shards
                    q.x = q.x * 1.85 - 0.02;
                    q.y = q.y * 1.85 - 0.08;
                    q.z = q.z * 1.65 - 0.04;
                    scaleFactor *= uScaleFactor; // default 2.13
                    
                    // Isolate the razor-sharp edges of the crystal planes
                    float crystalEdge = smoothstep(0.12, 0.0, abs(max(q.x, max(q.y, q.z))) - 0.01);
                    
                    if (crystalEdge > 0.0) {
                        // High-tech prismatic color selection per layer
                        vec3 crystalColor = vec3(0.0);
                        if (i % 3 == 0)      crystalColor = uColor1; // Laser Cyan
                        else if (i % 3 == 1) crystalColor = uColor2;  // Electric Purple
                        else                 crystalColor = uColor3;  // Refined Gold
                        
                        // Precision STATIC energy lines on the crystal facets
                        float staticHighlight = smoothstep(0.8, 1.0, sin(q.y * -6.5));
                        crystalColor += vec3(4.6, 0.95, 0.9) * staticHighlight * 8.3;
                        
                        // Accumulate with scale factor for deep holographic parallax depth
                        colorAccum += (crystalColor * crystalEdge) / scaleFactor;
                    }
                }
            
                // Internal refraction core glow
                float coreRefraction = exp(-length(p) * 20.1) * 0.25;
                vec3 coreColor = vec3(0.0, 0.5, 1.0) * coreRefraction;
                
                vec3 pLocal = p;
                vec3 nLocal = cubeNormal;
                if(uAutoRotate) {
                    pLocal.xy *= rot2d(iTime * uRotX);
                    pLocal.yz *= rot2d(iTime * uRotY);
                    
                    nLocal.xy *= rot2d(iTime * uRotX);
                    nLocal.yz *= rot2d(iTime * uRotY);
                }
                
                // --- Safe logic for straight facet lines on all sides ---
                // We now use the exact surface normal the ray entered from to prevent mid-ray flipping
                vec3 absN = abs(nLocal);
                float slice = pLocal.y;
                if (absN.y > absN.x && absN.y > absN.z) {
                    slice = pLocal.x; // Use X axis for top and bottom faces to keep lines straight
                }
                
                // Clean, sharp STATIC technical scanlines
                float staticScanlines = step(0.60, fract(slice * 65.9)) * -1.65 + 1.75;
                
                return (colorAccum * 79.1 + coreColor) * staticScanlines;
            }

            // Volumetric raymarcher with high Prism Dispersion (Chromatic Aberration)
            vec4 accumulateVolume(vec3 ro, vec3 rd, vec3 hitNormal) {
                vec3 accumulatedColor = vec3(0.0);
                float alpha = 0.0;
                float stepSize = 0.022; // Very tight steps to capture razor-sharp details
                
                for(int j = 0; j < 23; j++) {
                    vec3 p = ro + rd * (float(j) * stepSize);
                    if (mapCube(p) > 0.01) break; 
                    
                    // Severe RGB splitting to mimic light dispersion through a crystalline medium
                    vec3 rChannel = calcCrystalFractal(p + vec3(0.022, 0.0, 0.0), hitNormal);
                    vec3 gChannel = calcCrystalFractal(p, hitNormal);
                    vec3 bChannel = calcCrystalFractal(p - vec3(0.022, 0.0, 0.0), hitNormal);
                    
                    vec3 crystalSample = vec3(rChannel.r, gChannel.g, bChannel.b);
                    
                    accumulatedColor += crystalSample * 0.065;
                    alpha += 0.08;
                    if(alpha >= 1.2) { alpha = 0.5; break; }
                }
                return vec4(accumulatedColor, alpha);
            }

            void main() {
                vec2 uv = (vUv - 0.5) * iResolution.xy / iResolution.y;
                
                // Camera Ray setups (Linked to OrbitControls position)
                vec3 ro = uCamPos;
                vec3 target = vec3(0.0, 0.0, 0.0);
                
                vec3 forward = normalize(target - ro);
                vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
                vec3 up = cross(forward, right);
                vec3 rd = normalize(forward + uv.x * right + uv.y * up);
                
                vec3 finalOutput = vec3(0.0); // Pitch black backdrop
                
                float tCube = 0.6;
                bool hitCube = false;
                vec3 rayPosition;
                
                // Raymarching for the glass boundary
                for(int i = 0; i < 80; i++) {
                    rayPosition = ro + rd * tCube;
                    float distanceToScene = mapCube(rayPosition);
                    if(distanceToScene < 0.001) {
                        hitCube = true;
                        break;
                    }
                    tCube += distanceToScene;
                    if(tCube >= 10.0) break;
                }
                
                if (hitCube) {
                    vec3 normal = calcNormal(rayPosition);
                    vec3 lightDirection = normalize(vec3(2.0, 4.0, -3.0));
                    
                    // Precision Outer Edge/Contour Mapping linked dynamically to CubeSize
                    vec3 qEdge = rayPosition;
                    if(uAutoRotate) {
                        qEdge.xy *= rot2d(iTime * uRotX);
                        qEdge.yz *= rot2d(iTime * uRotY);
                    }
                    vec3 distanceToEdge = smoothstep(uCubeSize - 0.03, uCubeSize - 0.003, abs(qEdge));
                    float edgeMask = max(distanceToEdge.x * distanceToEdge.y, 
                                     max(distanceToEdge.y * distanceToEdge.z, 
                                         distanceToEdge.z * distanceToEdge.x));
                    edgeMask = clamp(edgeMask, 0.0, 1.0);
                    
                    // Clean glass reflections
                    vec3 reflectionDirection = reflect(rd, normal);
                    float specularLight = pow(max(dot(reflectionDirection, lightDirection), 0.0), 40.4) * 0.4;
                    float fresnelReflection = pow(1.0 - max(dot(normal, -rd), -0.5), 4.0);
                    
                    // Render internal volume
                    vec4 internalVolume = accumulateVolume(rayPosition + rd * 0.01, rd, normal);
                    vec3 glassInterior = internalVolume.xyz; 
                    
                    // Clean Neon Laser wireframe for the outer edges (Now controlled by uEdgeGlow)
                    vec3 edgeGlowColor = vec3(0.0, 1.75, 1.0) * edgeMask * uEdgeGlow; 
                    
                    // Final blend: Sharp Crystal Core + Glowing Outlines + Specular Shine
                    finalOutput = glassInterior + edgeGlowColor + vec3(specularLight * 1.0);
                    
                    // Sophisticated crystal-blue rim lighting (Fresnel effect)
                    finalOutput = mix(finalOutput, vec3(0.2, 0.65, 1.0), fresnelReflection * 0.45);
                } 
                
                // Filmic tone mapping & crisp gamma translation
                finalOutput = finalOutput / (finalOutput + vec3(1.0)); 
                finalOutput = pow(finalOutput, vec3(0.4545)); 
                
                gl_FragColor = vec4(finalOutput, 1.0);
            }
        `;

        let scene, camera, renderer, material;
        let startAzimuth = 0; // Used to calculate the inverted horizontal movement
        
        // Settings configured via GUI to match code_4 exact defaults
        const params = {
            dpr: 1.0,
            autoRotate: true,
            rotSpeedX: 0.15,
            rotSpeedY: 0.25,
            fractalSpeed: 1.0,
            morphSpeed: 1.0,
            scaleFactor: 2.13, 
            cubeSize: 0.40,   
            edgeGlow: 0.0, // Set to 0.0 by default as requested
            color1: '#0055ff', // 0.000, 0.333, 1.000
            color2: '#3355ff', // 0.200, 0.333, 1.000
            color3: '#ff9900'  // 1.000, 0.600, 0.000
        };

        function hexToVec3(hex) {
            const color = new THREE.Color(hex);
            return new THREE.Vector3(color.r, color.g, color.b);
        }

        function init() {
            const container = document.getElementById('canvas-container');
            
            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(params.dpr);
            container.appendChild(renderer.domElement);

            scene = new THREE.Scene();

            // Set perspective camera to look slightly from below (y = -0.8) with default FOV for no distortion
            camera = new THREE.PerspectiveCamera(20.0, window.innerWidth / window.innerHeight, 0.1, 10);
            camera.position.set(1.3, -0.8, -1.6);
            camera.lookAt(0, 0, 0);

            // Record the initial angle so we can invert the horizontal rotation correctly
            startAzimuth = Math.atan2(camera.position.x, camera.position.z);

            const controls = new THREE.OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.enablePan = false; // Prevent shifting target to keep shader math accurate

            material = new THREE.ShaderMaterial({
                vertexShader: vertexShader,
                fragmentShader: fragmentShader,
                uniforms: {
                    iResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
                    iTime: { value: 0.0 },
                    uCamPos: { value: new THREE.Vector3() },
                    
                    uAutoRotate: { value: params.autoRotate },
                    uRotX: { value: params.rotSpeedX },
                    uRotY: { value: params.rotSpeedY },
                    
                    uFractalSpeed: { value: params.fractalSpeed },
                    uMorphSpeed: { value: params.morphSpeed },
                    uScaleFactor: { value: params.scaleFactor },
                    uCubeSize: { value: params.cubeSize },
                    uEdgeGlow: { value: params.edgeGlow },
                    
                    uColor1: { value: hexToVec3(params.color1) },
                    uColor2: { value: hexToVec3(params.color2) },
                    uColor3: { value: hexToVec3(params.color3) },
                }
            });

            const geometry = new THREE.PlaneGeometry(2, 2);
            const mesh = new THREE.Mesh(geometry, material);
            scene.add(mesh); 
            
            // Fullscreen projection camera
            const orthoCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
            
            const gui = new lil.GUI({ title: 'Cube Settings' });
            gui.close(); // Closed by default
            
            const sysFolder = gui.addFolder('System & Rotation');
            sysFolder.add(params, 'dpr', 0.5, 2.0, 0.1).name('Resolution (DPR)').onChange(v => renderer.setPixelRatio(v));
            sysFolder.add(params, 'autoRotate').name('Diagonal Auto-Rotate').onChange(v => material.uniforms.uAutoRotate.value = v);
            sysFolder.add(params, 'rotSpeedX', 0.0, 1.0, 0.01).name('Auto-Rot X').onChange(v => material.uniforms.uRotX.value = v);
            sysFolder.add(params, 'rotSpeedY', 0.0, 1.0, 0.01).name('Auto-Rot Y').onChange(v => material.uniforms.uRotY.value = v);
            
            const fracFolder = gui.addFolder('Fractal Generator');
            fracFolder.add(params, 'cubeSize', 0.2, 0.8, 0.01).name('Cube Size').onChange(v => material.uniforms.uCubeSize.value = v);
            fracFolder.add(params, 'edgeGlow', 0.0, 10.0, 0.1).name('Edge Glow (Contours)').onChange(v => material.uniforms.uEdgeGlow.value = v);
            fracFolder.add(params, 'fractalSpeed', 0.0, 5.0, 0.1).name('Internal Spin').onChange(v => material.uniforms.uFractalSpeed.value = v);
            fracFolder.add(params, 'morphSpeed', 0.0, 5.0, 0.1).name('Morphing Speed').onChange(v => material.uniforms.uMorphSpeed.value = v);
            fracFolder.add(params, 'scaleFactor', 1.0, 3.0, 0.01).name('Complexity Scale').onChange(v => material.uniforms.uScaleFactor.value = v);
            
            const colorFolder = gui.addFolder('Hologram Colors');
            colorFolder.addColor(params, 'color1').name('Layer 1 (Cyan)').onChange(v => material.uniforms.uColor1.value = hexToVec3(v));
            colorFolder.addColor(params, 'color2').name('Layer 2 (Purple)').onChange(v => material.uniforms.uColor2.value = hexToVec3(v));
            colorFolder.addColor(params, 'color3').name('Layer 3 (Gold)').onChange(v => material.uniforms.uColor3.value = hexToVec3(v));

            window.addEventListener('resize', onWindowResize, false);
            const clock = new THREE.Clock();

            function animate() {
                requestAnimationFrame(animate);
                
                controls.update();
                
                material.uniforms.iTime.value = clock.getElapsedTime();
                
                // --- CUSTOM INVERTED HORIZONTAL LOGIC ---
                // We keep vertical rotation (Y) normal, but invert horizontal (azimuthal) math for the shader
                const currentAzimuth = Math.atan2(camera.position.x, camera.position.z);
                const radius = Math.hypot(camera.position.x, camera.position.z);
                
                // Calculate how much the camera has moved horizontally
                const delta = currentAzimuth - startAzimuth;
                
                // Reverse the direction of the horizontal movement
                const invertedAzimuth = startAzimuth - delta;
                
                // Apply the inverted X and Z coordinates, but keep the original Y coordinate
                const shaderCamX = Math.sin(invertedAzimuth) * radius;
                const shaderCamZ = Math.cos(invertedAzimuth) * radius;
                const shaderCamY = camera.position.y;
                
                material.uniforms.uCamPos.value.set(shaderCamX, shaderCamY, shaderCamZ);
                // ----------------------------------------

                renderer.render(scene, orthoCamera);
            }

            function onWindowResize() {
                camera.aspect = window.innerWidth / window.innerHeight;
                camera.updateProjectionMatrix();
                renderer.setSize(window.innerWidth, window.innerHeight);
                material.uniforms.iResolution.value.set(window.innerWidth, window.innerHeight);
            }

            animate();
        }

        window.onload = init;