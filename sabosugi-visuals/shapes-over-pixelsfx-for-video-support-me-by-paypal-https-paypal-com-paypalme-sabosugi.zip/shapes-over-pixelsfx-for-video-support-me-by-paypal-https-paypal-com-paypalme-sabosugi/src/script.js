// Support me by PayPal: https://paypal.com/paypalme/sabosugi
// Setup Canvas
        const canvas = document.getElementById('mainCanvas');
        const ctx = canvas.getContext('2d');
        
        // Offscreen canvas for reading video pixels
        const offscreenCanvas = document.createElement('canvas');
        const offscreenCtx = offscreenCanvas.getContext('2d', { willReadFrequently: true });

        // Video Element
        const video = document.createElement('video');
        video.src = 'https://cdn-cf-east.streamable.com/video/mp4/h1dmwx.mp4?Expires=1783763736291&Key-Pair-Id=APKAIEYUVEN4EVB2OKEQ&Signature=JCBxPPTKIsdItshpt3mgw3zX2p6XCkzFqMnzdOV1BE2ISOaURNU-KBVF5p2Jq6ZNchTOu8de3iOaDl5Wzsl9K5j8xSr57LeX4L0QaiuCsz-qf~cmNluaj2ch-ePKQoBBNrorXlBd0fyiZHxGG0N4Cao~fJaD56Ax76PfQXKuOOYa5sYj2CsRql4KGmLyCkXrL1s0AfWBDJ7BBqxDoMXI2EQATOD0BBlvoDAVZg~F7KBWWIMhQQzVPEsL9jOPDtGHNSl9-hiOLCVG7kWXDihkKncMWelALD-wEOg-yCjiR~6iGeysw00FD5g3vuq1Xc2MvgnQmqIK4XkNjTakCOfcJA__';
        video.crossOrigin = 'anonymous';
        video.loop = true;
        video.muted = true;
        video.playsInline = true;
        video.autoplay = true;

        // GUI Parameters
        const params = {
            // Background & Original Video
            bgColor: '#000000',
            bgVideoOpacity: 0.72,
            contrast: 100,
            
            // Effect
            effectOpacity: 0.76,
            blendMode: 'lighter',
            resolution: 13,
            sizeMultiplier: 1.4,
            
            // Filters
            minBrightness: 0.0,
            maxBrightness: 0.52,
            
            // Actions
            uploadLocalVideo: () => document.getElementById('videoInput').click(),
            togglePlay: () => {
                if (video.paused) video.play();
                else video.pause();
            }
        };

        const blendModes = [
            'source-over', 'lighter', 'multiply', 'screen', 'overlay', 
            'darken', 'lighten', 'color-dodge', 'color-burn', 
            'hard-light', 'soft-light', 'difference', 'exclusion', 
            'hue', 'saturation', 'color', 'luminosity'
        ];

        // Initialize lil-gui
        const gui = new lil.GUI({ title: 'Scene Settings' });
        
        const fVideo = gui.addFolder('Video & Background');
        fVideo.add(params, 'bgVideoOpacity', 0.0, 1.0, 0.01).name('Bg Video Opacity');
        fVideo.add(params, 'contrast', 0, 300, 1).name('Contrast (%)');
        fVideo.addColor(params, 'bgColor').name('Background Color');

        const fEffect = gui.addFolder('Shape Effect');
        fEffect.add(params, 'effectOpacity', 0.0, 1.0, 0.01).name('Effect Opacity');
        fEffect.add(params, 'blendMode', blendModes).name('Blend Mode');
        fEffect.add(params, 'resolution', 5, 50, 1).name('Grid Size (px)');
        fEffect.add(params, 'sizeMultiplier', 0.1, 3.0, 0.1).name('Size Multiplier');
        
        const fLevels = gui.addFolder('Brightness Filter');
        fLevels.add(params, 'minBrightness', 0.0, 1.0, 0.01).name('Min Threshold');
        fLevels.add(params, 'maxBrightness', 0.0, 1.0, 0.01).name('Max Threshold');

        const fControls = gui.addFolder('Controls');
        fControls.add(params, 'uploadLocalVideo').name('Upload Local Video');
        fControls.add(params, 'togglePlay').name('Play / Pause');

        // Handle File Upload
        document.getElementById('videoInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const url = URL.createObjectURL(file);
                video.src = url;
                video.play();
            }
        });

        // Resize Handling
        function resize() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            // Removed offscreen canvas resizing here for optimization
        }
        window.addEventListener('resize', resize);
        resize();

        // Pseudo-random generator based on coordinates to keep shapes stable
        function pseudoRandom(x, y) {
            return Math.abs(Math.sin(x * 12.9898 + y * 78.233) * 43758.5453) % 1;
        }

        // Shape Helper Functions
        function definePolygon(ctx, x, y, radius, sides) {
            for (let i = 0; i < sides; i++) {
                const angle = (i * 2 * Math.PI) / sides - Math.PI / 2;
                if (i === 0) ctx.moveTo(x + radius * Math.cos(angle), y + radius * Math.sin(angle));
                else ctx.lineTo(x + radius * Math.cos(angle), y + radius * Math.sin(angle));
            }
            ctx.closePath();
        }

        function defineStar(ctx, x, y, radius, innerRadius, points) {
            for (let i = 0; i < points * 2; i++) {
                const r = (i % 2 === 0) ? radius : innerRadius;
                const angle = (i * Math.PI) / points - Math.PI / 2;
                if (i === 0) ctx.moveTo(x + r * Math.cos(angle), y + r * Math.sin(angle));
                else ctx.lineTo(x + r * Math.cos(angle), y + r * Math.sin(angle));
            }
            ctx.closePath();
        }

        // Draw individual shape based on type
        function drawShape(ctx, type, x, y, size) {
            ctx.beginPath();
            
            const half = size / 2;
            const quarter = size / 4;

            // 14 Different Primitives
            switch(type) {
                case 0: // Circle
                    ctx.arc(x, y, half, 0, Math.PI * 2); break;
                case 1: // Square
                    ctx.rect(x - half, y - half, size, size); break;
                case 2: // Triangle Up
                    ctx.moveTo(x, y - half); ctx.lineTo(x + half, y + half); ctx.lineTo(x - half, y + half); break;
                case 3: // Triangle Down
                    ctx.moveTo(x - half, y - half); ctx.lineTo(x + half, y - half); ctx.lineTo(x, y + half); break;
                case 4: // Horizontal Rectangle
                    ctx.rect(x - half, y - quarter, size, half); break;
                case 5: // Vertical Rectangle
                    ctx.rect(x - quarter, y - half, half, size); break;
                case 6: // Diamond
                    ctx.moveTo(x, y - half); ctx.lineTo(x + half, y); ctx.lineTo(x, y + half); ctx.lineTo(x - half, y); break;
                case 7: // Pentagon
                    definePolygon(ctx, x, y, half, 5); break;
                case 8: // Hexagon
                    definePolygon(ctx, x, y, half, 6); break;
                case 9: // Octagon
                    definePolygon(ctx, x, y, half, 8); break;
                case 10: // Star (5 points)
                    defineStar(ctx, x, y, half, half / 2.5, 5); break;
                case 11: // Cross
                    const t = size / 6;
                    ctx.rect(x - t, y - half, t*2, size);
                    ctx.rect(x - half, y - t, size, t*2); break;
                case 12: // Half-circle
                    ctx.arc(x, y, half, Math.PI, 0); ctx.closePath(); break;
                case 13: // Ring (Donut)
                    ctx.arc(x, y, half, 0, Math.PI * 2);
                    ctx.arc(x, y, half / 2, 0, Math.PI * 2, true); break; // anticlockwise creates a hole
            }
            
            ctx.fill();
        }

        // Render Loop
        function animate() {
            requestAnimationFrame(animate);

            // 1. Reset and draw flat background
            ctx.globalCompositeOperation = 'source-over';
            ctx.globalAlpha = 1.0;
            ctx.fillStyle = params.bgColor;
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            if (video.readyState >= 2) {
                // Calculate Object-Fit: Cover dimensions
                const videoRatio = video.videoWidth / video.videoHeight;
                const canvasRatio = canvas.width / canvas.height;
                
                let drawWidth, drawHeight, offsetX, offsetY;

                if (canvasRatio > videoRatio) {
                    drawWidth = canvas.width;
                    drawHeight = canvas.width / videoRatio;
                    offsetX = 0;
                    offsetY = (canvas.height - drawHeight) / 2;
                } else {
                    drawWidth = canvas.height * videoRatio;
                    drawHeight = canvas.height;
                    offsetX = (canvas.width - drawWidth) / 2;
                    offsetY = 0;
                }

                // Apply Contrast Filter native to canvas
                const contrastStr = `contrast(${params.contrast}%)`;
                
                // 2. Draw Original Video Background
                if (params.bgVideoOpacity > 0) {
                    ctx.globalAlpha = params.bgVideoOpacity;
                    ctx.filter = contrastStr;
                    ctx.drawImage(video, offsetX, offsetY, drawWidth, drawHeight);
                    ctx.filter = 'none'; // reset
                }

                const res = params.resolution;
                const gw = Math.max(1, Math.ceil(canvas.width / res));
                const gh = Math.max(1, Math.ceil(canvas.height / res));

                // 3. Resize offscreen canvas to grid size (Optimization)
                if (offscreenCanvas.width !== gw) offscreenCanvas.width = gw;
                if (offscreenCanvas.height !== gh) offscreenCanvas.height = gh;

                offscreenCtx.clearRect(0, 0, gw, gh);
                offscreenCtx.filter = contrastStr;
                
                // Draw video scaled down into tiny buffer
                offscreenCtx.drawImage(video, offsetX / res, offsetY / res, drawWidth / res, drawHeight / res);
                offscreenCtx.filter = 'none';

                // Extract pixel data (reading tiny buffer instead of full screen)
                const imgData = offscreenCtx.getImageData(0, 0, gw, gh).data;

                // 4. Set blending parameters for shapes
                ctx.globalAlpha = params.effectOpacity;
                ctx.globalCompositeOperation = params.blendMode;

                // Process grid (one buffer pixel == one grid cell)
                for (let row = 0; row < gh; row++) {
                    const y = row * res + res / 2;
                    for (let col = 0; col < gw; col++) {
                        const x = col * res + res / 2;
                        
                        // Calculate 1D index for tiny image data array (rgba)
                        const index = (row * gw + col) * 4;

                        const r = imgData[index];
                        const g = imgData[index + 1];
                        const b = imgData[index + 2];

                        // Relative luminance calculation
                        const brightness = (0.299 * r + 0.587 * g + 0.114 * b) / 255;

                        // Check threshold bounds
                        if (brightness >= params.minBrightness && brightness <= params.maxBrightness) {
                            
                            // Size depends on brightness (brighter = larger)
                            const size = brightness * res * params.sizeMultiplier;
                            
                            // Stable random shape type keyed on cell coords directly
                            const shapeType = Math.floor(pseudoRandom(col, row) * 14);
                            
                            ctx.fillStyle = `rgb(${r},${g},${b})`;
                            
                            // Draw the shape if size is meaningful
                            if (size > 0.5) {
                                drawShape(ctx, shapeType, x, y, size);
                            }
                        }
                    }
                }
            }
        }

        // Auto-start video and animation loop
        video.play().catch(e => console.log("Video autoplay prevented:", e));
        animate();