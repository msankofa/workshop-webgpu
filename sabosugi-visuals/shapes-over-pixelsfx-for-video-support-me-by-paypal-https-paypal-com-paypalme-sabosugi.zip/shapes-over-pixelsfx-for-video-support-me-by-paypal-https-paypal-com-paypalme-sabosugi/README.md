# Shapes Over Pixels - FX for Video  – Support me by PayPal: https://paypal.com/paypalme/sabosugi

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/BypLMMN](https://codepen.io/sabosugi/pen/BypLMMN).

