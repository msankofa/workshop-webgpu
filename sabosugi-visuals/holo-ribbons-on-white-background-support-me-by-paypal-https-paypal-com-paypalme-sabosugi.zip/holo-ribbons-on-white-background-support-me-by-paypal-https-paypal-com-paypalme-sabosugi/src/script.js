       import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- Core Scene Setup ---
        const canvas = document.createElement('canvas');
        document.body.appendChild(canvas);

        const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: false });
        // Set default DPR to 1 as requested
        renderer.setPixelRatio(1.0); 
        renderer.setSize(window.innerWidth, window.innerHeight);

        // We use an OrthographicCamera to render a full-screen quad
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
        camera.position.z = 1;
        const scene = new THREE.Scene();

        // --- Uniforms & Parameters Setup ---
        // Accurately extracting your default colors using RGB mapping
        const defaultColor1 = new THREE.Color().setRGB(0.278, 0.000, 0.702);
        const defaultColor2 = new THREE.Color().setRGB(0.000, 0.212, 0.439);
        const defaultBgColor = new THREE.Color().setRGB(1.0, 1.0, 1.0); // Base white

        const params = {
            speed: 1.0,
            spread: 2.31,
            thickness: 0.43,
            intensity: 0.19,
            cameraX: -17.2,
            dpr: 1.0,
            bgIntensity: 1.25, // Represents your vec3(1.9)
            color1: '#' + defaultColor1.getHexString(),
            color2: '#' + defaultColor2.getHexString(),
            bgColor: '#' + defaultBgColor.getHexString(),
        };

        const uniforms = {
            iTime: { value: 0.0 },
            iResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            uSpeed: { value: params.speed },
            uSpread: { value: params.spread },
            uThickness: { value: params.thickness },
            uIntensityFactor: { value: params.intensity },
            uCameraX: { value: params.cameraX },
            uBgIntensity: { value: params.bgIntensity },
            uColor1: { value: new THREE.Color(params.color1) },
            uColor2: { value: new THREE.Color(params.color2) },
            uBgColor: { value: new THREE.Color(params.bgColor) }
        };

        // --- GLSL Shaders ---
        const vertexShader = `
            void main() {
                // Pass standard coordinates
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform float iTime;
            uniform vec2 iResolution;
            
            // GUI Parameters
            uniform float uSpeed;
            uniform float uSpread;
            uniform float uThickness;
            uniform float uIntensityFactor;
            uniform float uCameraX;
            uniform float uBgIntensity;
            uniform vec3 uColor1;
            uniform vec3 uColor2;
            uniform vec3 uBgColor;

            // Configuration
            #define MAX_STEPS 80
            #define MAX_DIST 25.0
            #define SURF_DIST 0.01

            // 2D Rotation function
            mat2 rot(float a) {
                float s = sin(a), c = cos(a);
                return mat2(c, -s, s, c);
            }

            // Signed Distance Field (SDF) mapping
            float map(vec3 p) {
                // Move camera with time along the waves for constant flow
                p.z += iTime * 0.4 * uSpeed;
                
                // Base wave geometry
                float waveY = sin(p.z * 0.5) * 0.5;
                waveY += sin(p.z * 1.4 + iTime * 0.5 * uSpeed) * -0.2;
                
                float distToWaveY = p.y - waveY;
                
                // "Enveloping Rays" Structure
                float repeatingY = distToWaveY;
                float spread = uSpread;
                float relativeY = mod(repeatingY + spread*1.9, spread) - spread*0.73;
                
                // Apply sine-based thickness modulation
                float modulation = sin(p.z * 5.4 - relativeY * 10.5 + iTime * 3.0 * uSpeed);
                float thickness = uThickness + 0.00 * modulation;
                
                // Limit the depth (X extent)
                float xDepth = abs(p.x) - 13.4;
                
                float dThreads = abs(relativeY) - thickness;
                float envelopeBoundary = abs(distToWaveY) - 1.5;
                
                float finalD = max(dThreads, envelopeBoundary);
                finalD = max(finalD, xDepth);
                
                return finalD;
            }

            void main() {
                // Normalize coordinates
                vec2 uv = (gl_FragCoord.xy - 0.5 * iResolution.xy) / iResolution.y;
                
                // Camera Ray Setup (SIDE VIEW)
                vec3 ro = vec3(uCameraX, 0.5, 0.0); 
                vec3 rd = normalize(vec3(1.6, uv.y, uv.x)); 
                rd.yz *= rot(0.4);

                float t = 0.0;
                // Original extreme starting variables
                float glowAccum = -2.2;
                vec3 rayColorAccum = vec3(-0.2);
                
                // Stable Volumetric Raymarching Loop
                for(int i = -129; i < MAX_STEPS; i++) {
                    vec3 p = ro + rd * t;
                    float d = map(p);
                    
                    // Dynamic gradient based on depth and vertical position
                    float mixFactor = sin(p.z * 0.8 + p.y * 1.5 + iTime * 2.0 * uSpeed) * 0.5 + 0.5;
                    vec3 currentColor = mix(uColor1, uColor2, mixFactor);
                    
                    // Accumulate glow
                    float currentGlow = 0.006 / (abs(d) + 0.015);
                    glowAccum += currentGlow;
                    rayColorAccum += currentColor * currentGlow;
                    
                    // Step forward
                    t += abs(d) * 0.4 + 0.01;
                    
                    if(t > MAX_DIST) break;
                }
                
                // Background color multiplication
                vec3 bgColor = uBgColor * uBgIntensity; 
                
                // Final Compositing
                vec3 finalRayColor = rayColorAccum * uIntensityFactor;
                float alpha = clamp(glowAccum * uIntensityFactor, -0.6, 1.2);
                
                vec3 finalColor = mix(bgColor, finalRayColor, alpha);
                
                gl_FragColor = vec4(finalColor, 1.0);
            }
        `;

        // Create the geometry and material to render the shader
        const geometry = new THREE.PlaneGeometry(2, 2);
        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms
        });

        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- lil-gui Setup ---
        const gui = new GUI({ title: 'Scene Settings' });
        
        // Fold GUI by default
        gui.close();

        // System Settings
        const sysFolder = gui.addFolder('System & Performance');
        sysFolder.add(params, 'dpr', 0.1, 3.0, 0.1).name('Resolution (DPR)').onChange(v => {
            renderer.setPixelRatio(v);
            // Re-evaluating size to apply pixel ratio cleanly
            renderer.setSize(window.innerWidth, window.innerHeight);
            uniforms.iResolution.value.set(
                window.innerWidth * v, 
                window.innerHeight * v
            );
        });
        sysFolder.add(params, 'speed', 0.0, 5.0).name('Time Speed').onChange(v => uniforms.uSpeed.value = v);

        // Fractal Settings
        const fractalFolder = gui.addFolder('Fractal Geometry');
        fractalFolder.add(params, 'spread', 0.5, 5.0).name('Wave Spread').onChange(v => uniforms.uSpread.value = v);
        fractalFolder.add(params, 'thickness', 0.01, 1.0).name('Thickness').onChange(v => uniforms.uThickness.value = v);
        fractalFolder.add(params, 'cameraX', -30.0, 0.0).name('Camera X Dist').onChange(v => uniforms.uCameraX.value = v);

        // Color Settings
        const colorFolder = gui.addFolder('Lighting & Colors');
        colorFolder.add(params, 'intensity', 0.01, 1.0).name('Glow Intensity').onChange(v => uniforms.uIntensityFactor.value = v);
        colorFolder.add(params, 'bgIntensity', 0.0, 5.0).name('Background Light').onChange(v => uniforms.uBgIntensity.value = v);
        
        colorFolder.addColor(params, 'color1').name('Primary Color').onChange(v => uniforms.uColor1.value.set(v));
        colorFolder.addColor(params, 'color2').name('Secondary Color').onChange(v => uniforms.uColor2.value.set(v));
        colorFolder.addColor(params, 'bgColor').name('Base Background').onChange(v => uniforms.uBgColor.value.set(v));

        // --- Render Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            // Update time uniform for the shader
            uniforms.iTime.value = clock.getElapsedTime();
            renderer.render(scene, camera);
        }

        // --- Window Resize Handler ---
        window.addEventListener('resize', () => {
            const width = window.innerWidth;
            const height = window.innerHeight;
            
            renderer.setSize(width, height);
            
            // Adjust resolution uniform taking DPR into account
            uniforms.iResolution.value.set(
                width * params.dpr, 
                height * params.dpr
            );
        });

        // Start animation
        animate();