# Holo Ribbons on White Background – Support me by PayPal: https://paypal.com/paypalme/sabosugi

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/vEgGvKR](https://codepen.io/sabosugi/pen/vEgGvKR).

