        import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- Application State & Configuration ---
        // Applied values from user's screenshot
        const config = {
            images: [
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=2564&auto=format&fit=crop', // Portrait 1 (Clean)
                'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=2564&auto=format&fit=crop', // Portrait 2 (Moody)
                'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=2564&auto=format&fit=crop', // Portrait 3 (Fashion)
                'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?q=80&w=2564&auto=format&fit=crop'  // Portrait 4 (Bright)
            ],
            currentImageIndex: 0,
            nextImageIndex: 1,
            isAnimating: false,
            isSingleMode: false,
            
            // Timings
            slideDurationSecs: 10.0, 
            transitionDuration: 1.5,
            scanDuration: 8.0, 
            
            scanProgress: 0.75672, // From screenshot
            isScanning: false,

            // Shader parameters (From Screenshot)
            lumaMin: 0.05, 
            lumaMax: 1.0,
            effectIntensity: 1.473, 
            effectColor: [66/255, 170/255, 255/255], // #42aaff to normalized RGB
            
            // Fractal parameters (From Screenshot)
            pixelSize: 15.0, 
            fractalScale: 1.7248,
            fractalSpeed: 0.7595,
            fractalSmoothness: 0.07285,
            
            // Contour parameters (From Screenshot)
            contourSensitivity: 0.12901,
            contourMultiplier: 0.98, 
            
            // NEW: Relief (Depth) parameter
            reliefStrength: 0.61,
            
            uploadImages: () => {
                document.getElementById('image-upload').click();
            }
        };

        let scene, camera, renderer, material;
        let textures = [];
        let clock = new THREE.Clock();
        let slideshowTimer; 
        let waveAnimId = null; 

        // --- Shaders ---

        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform sampler2D tDiffuse1;
            uniform sampler2D tDiffuse2;
            uniform vec2 uResolution;
            uniform vec2 uImageRes1;
            uniform vec2 uImageRes2;
            uniform float uProgress;
            uniform float uTime;
            
            // Effect uniforms
            uniform float uLumaMin;
            uniform float uLumaMax;
            uniform float uScanProgress;
            uniform float uEffectFade; 
            uniform float uEffectIntensity;
            uniform vec3 uEffectColor;
            
            uniform float uPixelSize;
            uniform float uFractalSpeed;
            uniform float uFractalScale;
            uniform float uFractalSmoothness; 
            
            uniform float uContourSensitivity;
            uniform float uContourMultiplier;
            uniform float uReliefStrength;

            varying vec2 vUv;

            // Simple Random Function
            float random(vec2 st) {
                return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
            }

            // Function to calculate "cover" UVs maintaining aspect ratio
            vec2 getCoverUV(vec2 uv, vec2 resolution, vec2 texResolution) {
                vec2 ratio = vec2(
                    min((resolution.x / resolution.y) / (texResolution.x / texResolution.y), 1.0),
                    min((resolution.y / resolution.x) / (texResolution.y / texResolution.x), 1.0)
                );
                return uv * ratio + (1.0 - ratio) * 0.5;
            }

            // Luminance calculation
            float getLuma(vec3 color) {
                return dot(color, vec3(0.299, 0.587, 0.114));
            }

            // Organic Light Fractal flowing over a simulated 3D Relief
            float generateLightFractal(vec2 uv, float time, float speed, float scale, float contour, float depth, vec2 surfaceGradient) {
                vec2 p = uv * scale;
                
                // 1. Contour distortion: pinches the light around sharp edges
                p += contour * 2.0; 
                
                // 2. Relief distortion (Simulated 3D Depth)
                // We use the surface gradient (slope) to bend the light, as if it's flowing over a physical object
                p += surfaceGradient * uReliefStrength * 30.0;
                
                // 3. Perspective distortion (objects closer/brighter appear slightly larger to the fractal field)
                p *= (1.0 - depth * 0.15 * uReliefStrength);
                
                float t = time * speed * 0.5;
                float result = 0.0;
                float amp = 1.0;
                
                for (int i = 0; i < 6; i++) {
                    // Trigonometric domain warping
                    vec2 shift = vec2(sin(p.y + t), cos(p.x + t));
                    p += shift * 0.5;
                    p *= 1.5;
                    
                    // Generate glowing bands/threads
                    float band = abs(sin(p.x + p.y));
                    float glow = uFractalSmoothness / (band + 0.02);
                    
                    result += glow * amp;
                    amp *= 0.6; 
                    t *= 1.2;   
                }
                
                return clamp(result * 0.15, 0.0, 1.0);
            }

            void main() {
                // Calculate cover UVs
                vec2 uv1 = getCoverUV(vUv, uResolution, uImageRes1);
                vec2 uv2 = getCoverUV(vUv, uResolution, uImageRes2);

                vec4 color1 = texture2D(tDiffuse1, uv1);
                vec4 color2 = texture2D(tDiffuse2, uv2);

                // Base Fade In / Fade Out Transition
                vec4 baseColor = mix(color1, color2, uProgress);
                float luma = getLuma(baseColor.rgb);

                // Pixelate the UVs for the effects to make Pixel Size visibly blocky
                vec2 pixelUV = vUv;
                if(uPixelSize > 1.0) {
                     pixelUV = floor(vUv * (uResolution / uPixelSize)) * (uPixelSize / uResolution);
                }
                
                // Recalculate pixelated luma so the wave edges snap to the grid
                vec2 pixUv1 = getCoverUV(pixelUV, uResolution, uImageRes1);
                vec2 pixUv2 = getCoverUV(pixelUV, uResolution, uImageRes2);
                float pixLuma = getLuma(mix(texture2D(tDiffuse1, pixUv1), texture2D(tDiffuse2, pixUv2), uProgress).rgb);

                // --- Depth & Contour Analysis (Using smooth luma for quality edges) ---
                // We calculate how fast the luma is changing across X and Y axes
                vec2 lumaGradient = vec2(dFdx(luma), dFdy(luma));
                
                // Edge intensity
                float edge = length(lumaGradient);
                float contour = smoothstep(0.0, uContourSensitivity, edge);

                // Correct aspect ratio
                vec2 squareUV = pixelUV;
                squareUV.x *= uResolution.x / uResolution.y;

                // --- Luma Wave Logic (Using pixelated luma) ---
                float scanThreshold = mix(uLumaMax, uLumaMin, uScanProgress);
                float waveEdge = scanThreshold;
                float finalMask = smoothstep(waveEdge - 0.05, waveEdge + 0.05, pixLuma);

                // --- Relief-Aware Fractal Pattern ---
                // We pass the absolute luma (as depth) and the gradient (as surface normals/slope)
                float fractalPattern = generateLightFractal(squareUV, uTime, uFractalSpeed, uFractalScale, contour, pixLuma, lumaGradient);

                // Amplify where contours are sharp
                float effectPattern = fractalPattern * (1.0 + contour * uContourMultiplier);

                // Apply to final color
                vec3 finalColor = mix(baseColor.rgb, baseColor.rgb + uEffectColor * effectPattern * uEffectIntensity, finalMask * uEffectFade);

                gl_FragColor = vec4(finalColor, 1.0);
            }
        `;

        // --- Initialization ---

        async function init() {
            const container = document.getElementById('canvas-container');

            scene = new THREE.Scene();
            camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
            camera.position.z = 1;

            renderer = new THREE.WebGLRenderer({ antialias: false });
            renderer.setSize(window.innerWidth, window.innerHeight);
            
            const dpr = Math.min(window.devicePixelRatio, 2);
            renderer.setPixelRatio(dpr);
            container.appendChild(renderer.domElement);

            const textureLoader = new THREE.TextureLoader();
            textureLoader.setCrossOrigin('anonymous');
            
            const loadTexture = (url) => {
                return new Promise((resolve) => {
                    textureLoader.load(url, resolve, undefined, (err) => {
                        console.error('Texture load error:', err);
                        resolve(new THREE.Texture());
                    });
                });
            };

            textures[0] = await loadTexture(config.images[config.currentImageIndex]);
            textures[1] = await loadTexture(config.images[config.nextImageIndex]);

            document.getElementById('loader').style.opacity = '0';

            material = new THREE.ShaderMaterial({
                vertexShader,
                fragmentShader,
                derivatives: true, // Required for dFdx / dFdy relief calculation
                uniforms: {
                    tDiffuse1: { value: textures[0] },
                    tDiffuse2: { value: textures[1] },
                    uResolution: { value: new THREE.Vector2(window.innerWidth * dpr, window.innerHeight * dpr) },
                    uImageRes1: { value: new THREE.Vector2(textures[0].image.width, textures[0].image.height) },
                    uImageRes2: { value: new THREE.Vector2(textures[1].image.width, textures[1].image.height) },
                    uProgress: { value: 0.0 },
                    uTime: { value: 0.0 },
                    
                    uLumaMin: { value: config.lumaMin },
                    uLumaMax: { value: config.lumaMax },
                    uScanProgress: { value: config.scanProgress },
                    uEffectFade: { value: 0.0 }, 
                    uEffectIntensity: { value: config.effectIntensity },
                    uEffectColor: { value: new THREE.Vector3(...config.effectColor) },
                    
                    uPixelSize: { value: config.pixelSize },
                    uFractalSpeed: { value: config.fractalSpeed },
                    uFractalScale: { value: config.fractalScale },
                    uFractalSmoothness: { value: config.fractalSmoothness },
                    
                    uContourSensitivity: { value: config.contourSensitivity },
                    uContourMultiplier: { value: config.contourMultiplier },
                    uReliefStrength: { value: config.reliefStrength }
                }
            });

            const geometry = new THREE.PlaneGeometry(2, 2);
            const mesh = new THREE.Mesh(geometry, material);
            scene.add(mesh);

            setupGUI();
            setupFileUpload();

            window.addEventListener('resize', onWindowResize, false);

            animate();
            startScanningWave();
            resetSlideshowTimer();
        }

        // --- Auto Slideshow Logic ---
        
        function resetSlideshowTimer() {
            clearTimeout(slideshowTimer);
            if (config.isSingleMode) return; 

            slideshowTimer = setTimeout(() => {
                if (!config.isAnimating) {
                    startTransition();
                }
            }, config.slideDurationSecs * 1000);
        }

        // --- File Upload Logic ---
        
        function setupFileUpload() {
            const uploadInput = document.getElementById('image-upload');
            
            uploadInput.addEventListener('change', async (event) => {
                const files = Array.from(event.target.files).slice(0, 5); 
                if (files.length === 0) return;
                
                config.isSingleMode = (files.length === 1);

                clearTimeout(slideshowTimer);
                if (waveAnimId) cancelAnimationFrame(waveAnimId); 
                
                config.isAnimating = true; 
                document.getElementById('loader').style.opacity = '1';
                document.getElementById('loader').innerText = 'Loading New Images...';

                let newImageUrls = files.map(file => URL.createObjectURL(file));
                
                if (newImageUrls.length === 1) {
                    newImageUrls.push(newImageUrls[0]);
                }

                config.images = newImageUrls;
                config.currentImageIndex = 0;
                config.nextImageIndex = 1 % config.images.length;

                const textureLoader = new THREE.TextureLoader();
                const loadTexture = (url) => new Promise(resolve => textureLoader.load(url, resolve));

                textures[0] = await loadTexture(config.images[config.currentImageIndex]);
                textures[1] = await loadTexture(config.images[config.nextImageIndex]);

                material.uniforms.tDiffuse1.value = textures[0];
                material.uniforms.uImageRes1.value.set(textures[0].image.width, textures[0].image.height);
                material.uniforms.tDiffuse2.value = textures[1];
                material.uniforms.uImageRes2.value.set(textures[1].image.width, textures[1].image.height);
                
                material.uniforms.uProgress.value = 0.0;
                
                document.getElementById('loader').style.opacity = '0';
                config.isAnimating = false;
                uploadInput.value = '';
                
                startScanningWave();
                resetSlideshowTimer();
            });
        }

        // --- GUI Setup ---
        
        function setupGUI() {
            const gui = new GUI({ title: 'Scene Settings' });
            
            gui.add(config, 'uploadImages').name('Upload Images (Max 5)');

            const timingFolder = gui.addFolder('Timing Parameters');
            timingFolder.add(config, 'slideDurationSecs', 1.0, 30.0).name('Slide Duration (s)').onChange(resetSlideshowTimer);
            timingFolder.add(config, 'transitionDuration', 0.1, 5.0).name('Transition (s)');
            timingFolder.add(config, 'scanDuration', 0.5, 10.0).name('Wave Duration (s)');

            const effectFolder = gui.addFolder('Wave & Core Parameters');
            effectFolder.add(config, 'lumaMin', 0.0, 1.0).name('Wave End (Darkest)').onChange(v => material.uniforms.uLumaMin.value = v);
            effectFolder.add(config, 'lumaMax', 0.0, 1.0).name('Wave Start (Brightest)').onChange(v => material.uniforms.uLumaMax.value = v);
            effectFolder.add(config, 'scanProgress', 0.0, 1.0).name('Manual Scan Progress').onChange(v => material.uniforms.uScanProgress.value = v).listen();
            effectFolder.add(config, 'effectIntensity', 0.0, 3.0).name('Effect Intensity').onChange(v => material.uniforms.uEffectIntensity.value = v);
            effectFolder.addColor(config, 'effectColor').name('Effect Color').onChange(v => material.uniforms.uEffectColor.value.set(v[0], v[1], v[2]));
            
            const techFolder = gui.addFolder('Fractal, Relief & Contours');
            techFolder.add(config, 'reliefStrength', 0.0, 5.0).name('3D Relief Strength').onChange(v => material.uniforms.uReliefStrength.value = v);
            techFolder.add(config, 'contourMultiplier', 0.0, 20.0).name('Contour Brightness').onChange(v => material.uniforms.uContourMultiplier.value = v);
            techFolder.add(config, 'contourSensitivity', 0.01, 0.2).name('Contour Sensitivity').onChange(v => material.uniforms.uContourSensitivity.value = v);
            
            // Increased max limit to 128 so pixelation is highly visible on modern displays
            techFolder.add(config, 'pixelSize', 1.0, 128.0).step(1.0).name('Pixel Size').onChange(v => material.uniforms.uPixelSize.value = v);
            
            techFolder.add(config, 'fractalScale', 0.1, 5.0).name('Fractal Scale').onChange(v => material.uniforms.uFractalScale.value = v);
            techFolder.add(config, 'fractalSpeed', 0.1, 5.0).name('Fractal Speed').onChange(v => material.uniforms.uFractalSpeed.value = v);
            techFolder.add(config, 'fractalSmoothness', 0.001, 0.5).name('Fractal Smoothness').onChange(v => material.uniforms.uFractalSmoothness.value = v);
        }

        // --- Animation Logics ---

        function startTransition() {
            if (config.isAnimating) return;
            config.isAnimating = true;
            let startTime = performance.now();
            
            function animateTransition(time) {
                let elapsed = (time - startTime) / 1000;
                let progress = elapsed / config.transitionDuration;
                
                if (progress < 1.0) {
                    let easedProgress = progress * progress * (3.0 - 2.0 * progress);
                    material.uniforms.uProgress.value = easedProgress;
                    requestAnimationFrame(animateTransition);
                } else {
                    material.uniforms.uProgress.value = 1.0;
                    completeTransition();
                }
            }
            
            requestAnimationFrame(animateTransition);
        }

        function completeTransition() {
            material.uniforms.tDiffuse1.value = material.uniforms.tDiffuse2.value;
            material.uniforms.uImageRes1.value.copy(material.uniforms.uImageRes2.value);
            
            material.uniforms.uProgress.value = 0.0;
            
            config.currentImageIndex = config.nextImageIndex;
            config.nextImageIndex = (config.nextImageIndex + 1) % config.images.length;
            
            const loader = new THREE.TextureLoader();
            loader.setCrossOrigin('anonymous');
            loader.load(config.images[config.nextImageIndex], (tex) => {
                material.uniforms.tDiffuse2.value = tex;
                material.uniforms.uImageRes2.value.set(tex.image.width, tex.image.height);
                config.isAnimating = false;
                
                startScanningWave();
                resetSlideshowTimer();
            });
        }

        function startScanningWave() {
            if (waveAnimId) cancelAnimationFrame(waveAnimId); 
            
            config.isScanning = true;
            config.scanProgress = 0.0;
            
            material.uniforms.uScanProgress.value = 0.0;
            material.uniforms.uEffectFade.value = 0.0; 

            let startTime = performance.now();

            function animateWave(time) {
                let elapsed = (time - startTime) / 1000;
                
                if (config.isSingleMode) {
                    // Infinite sweeping back-and-forth wave
                    let cycle = elapsed / config.scanDuration;
                    let phase = cycle % 2.0;
                    let progress = phase <= 1.0 ? phase : 2.0 - phase;
                    
                    let easedProgress = 1.0 - Math.pow(1.0 - progress, 2.0);
                    
                    config.scanProgress = easedProgress;
                    material.uniforms.uScanProgress.value = easedProgress;
                    
                    material.uniforms.uEffectFade.value = Math.min(1.0, elapsed / 1.5); 
                    
                    waveAnimId = requestAnimationFrame(animateWave);
                } else {
                    // Normal One-Shot Wave
                    let progress = elapsed / config.scanDuration;

                    if (progress < 1.0) {
                        let easedProgress = 1.0 - Math.pow(1.0 - progress, 2.0);
                        config.scanProgress = easedProgress;
                        material.uniforms.uScanProgress.value = easedProgress;
                        
                        material.uniforms.uEffectFade.value = Math.sin(progress * Math.PI);
                        
                        waveAnimId = requestAnimationFrame(animateWave);
                    } else {
                        config.scanProgress = 1.0;
                        material.uniforms.uScanProgress.value = 1.0;
                        material.uniforms.uEffectFade.value = 0.0; 
                        config.isScanning = false;
                        waveAnimId = null;
                    }
                }
            }
            waveAnimId = requestAnimationFrame(animateWave);
        }

        // --- Resize Handler ---

        function onWindowResize() {
            const width = window.innerWidth;
            const height = window.innerHeight;
            const dpr = Math.min(window.devicePixelRatio, 2);

            renderer.setSize(width, height);
            material.uniforms.uResolution.value.set(width * dpr, height * dpr);
        }

        // --- Main Animation Loop ---

        function animate() {
            requestAnimationFrame(animate);
            material.uniforms.uTime.value = clock.getElapsedTime();
            renderer.render(scene, camera);
        }

        window.onload = init;
