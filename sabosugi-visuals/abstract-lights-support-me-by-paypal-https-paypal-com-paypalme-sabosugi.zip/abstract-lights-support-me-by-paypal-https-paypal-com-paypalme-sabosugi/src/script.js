        import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- GLOBAL VARIABLES ---
        let camera, scene, renderer, material;
        let gui;

        // --- PARAMETERS FOR GUI ---
        const params = {
            DPR: 1.0,
            timeScale: 0.29,
            raymarchSteps: 32,
            fractalIters: 10,
            fractalAmplitude: 0.114,
            ditherIntensity: 0.09,
            vignette: 0.2,
            // Color Frequency (Multiplier)
            freqX: 1.35,
            freqY: 0.688,
            freqZ: 1.72,
            // Color Phase (Offset)
            phaseX: 5.28,
            phaseY: 7.49,
            phaseZ: 3.56
        };

        // --- SHADER DEFINITIONS ---
        // We use an orthographic camera and a full-screen quad, so vertex shader is trivial
        const vertexShader = `
            void main() {
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            // Uniforms injected from Three.js
            uniform vec3 iResolution;
            uniform float iTime;
            uniform float uTimeScale;
            uniform int uSteps;
            uniform float uFractalIters;
            uniform float uFractalAmplitude;
            uniform float uDither;
            uniform vec3 uColorFreq;
            uniform vec3 uColorPhase;
            uniform float uVignette;

            // Interleaved Gradient Noise (IGN)
            // Produces a much softer, structured film-like grain compared to standard white noise.
            float ign(vec2 p) {
                vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
                return fract(magic.z * fract(dot(p, magic.xy)));
            }

            // Safe implementation of tanh to prevent exp() overflow (NaN)
            vec4 safeTanh(vec4 x) {
                // Clamp input to prevent infinity when doing exp()
                vec4 clampedX = clamp(x, -10.0, 10.0);
                vec4 exp2x = exp(2.0 * clampedX);
                return (exp2x - 1.0) / (exp2x + 1.0);
            }

            void main() {
                // Normalize pixel coordinates
                vec2 fragCoord = gl_FragCoord.xy;
                vec2 uv = (2.0 * fragCoord - iResolution.xy) / iResolution.y;
                
                // Apply time scale
                float t = iTime * uTimeScale;
                
                // Add camera sway/wiggle effect over time
                uv += vec2(cos(t * 2.0) * 0.15, cos(t) * 0.13);
                
                // Define ray direction
                vec3 rayDir = normalize(vec3(uv, 0.7));
                
                // Initialize variables
                // Calculate cinematic 24fps frame for noise to prevent high-frequency digital "buzzing"
                float frame = floor(iTime * 24.0);
                vec2 noiseOffset = vec2(frame * 127.1, frame * 311.7);
                float ditherNoise = ign(fragCoord + noiseOffset);
                
                // Apply temporal Interleaved Gradient Noise
                // Centered around 0.0 (-0.5 to 0.5) to not push the whole fractal forward
                float totalDist = (ditherNoise - 0.5) * uDither;
                vec4 accumColor = vec4(0.0);
                
                // Raymarching loop
                for (int i = 0; i < 200; i++) {
                    // Dynamic break condition based on uniform
                    if (i >= uSteps) break;
                    
                    vec3 pos = rayDir * totalDist;
                    
                    // Space distortion along the Z-axis
                    pos.z = cos(pos.z * (sin(pos.x + t * 0.7) + 1.5));
                    
                    // Fractal iteration
                    for (float s = 3.0; s < 30.0; s += 1.0) {
                        if (s >= uFractalIters) break;
                        vec3 phase = 2.6 * t + pos.yzx * s;
                        // Amplitude is now constant to prevent the pulsing/breathing effect.
                        // Shape morphing is driven entirely by the time-based phase shift.
                        float amplitude = uFractalAmplitude;
                        pos = pos * 1.05 + sin(phase) * amplitude;
                    }
                    
                    // Distance field evaluation
                    float stepSize = 0.01 + 0.1 * abs(length(pos) - 0.8);
                    totalDist += stepSize;
                    
                    // Color accumulation
                    vec3 colorBase = sin(pos * uColorFreq - uColorPhase);
                    accumColor += vec4(colorBase, 0.0) / stepSize;
                }
                
                // Apply tonemapping with safeTanh
                vec4 tonemappedColor = safeTanh((accumColor * accumColor) / 1000000.0);
                
                // Apply vignette
                float vignette = 1.0 - uVignette * dot(uv, uv);
                
                // Output final color with solid alpha channel
                gl_FragColor = vec4((tonemappedColor * vignette).rgb, 1.0);
            }
        `;

        init();
        animate(0); // Pass initial time to prevent NaN

        function init() {
            // 1. Setup Renderer
            renderer = new THREE.WebGLRenderer({ antialias: false });
            // Initial DPR applies based on our param (default 1)
            renderer.setPixelRatio(params.DPR);
            renderer.setSize(window.innerWidth, window.innerHeight);
            document.body.appendChild(renderer.domElement);

            // 2. Setup Scene & Camera
            scene = new THREE.Scene();
            // Orthographic camera for full screen 2D effect
            camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

            // 3. Setup Material and Geometry
            const geometry = new THREE.PlaneGeometry(2, 2);
            
            material = new THREE.ShaderMaterial({
                vertexShader: vertexShader,
                fragmentShader: fragmentShader,
                uniforms: {
                    iResolution: { value: new THREE.Vector3() },
                    iTime: { value: 0.0 },
                    uTimeScale: { value: params.timeScale },
                    uSteps: { value: params.raymarchSteps },
                    uFractalIters: { value: params.fractalIters },
                    uFractalAmplitude: { value: params.fractalAmplitude },
                    uDither: { value: params.ditherIntensity },
                    uVignette: { value: params.vignette },
                    uColorFreq: { value: new THREE.Vector3(params.freqX, params.freqY, params.freqZ) },
                    uColorPhase: { value: new THREE.Vector3(params.phaseX, params.phaseY, params.phaseZ) }
                }
            });

            const mesh = new THREE.Mesh(geometry, material);
            scene.add(mesh);

            // 4. Setup GUI
            setupGUI();

            // 5. Handle resizing
            window.addEventListener('resize', onWindowResize);
            // Trigger initial resize to set uniform values properly
            onWindowResize();
        }

        function setupGUI() {
            gui = new GUI({ title: 'Shader Parameters' });
            
            // Close the GUI by default
            gui.close();

            // Display settings
            const folderDisplay = gui.addFolder('Display Settings');
            folderDisplay.add(params, 'DPR', 0.1, 3.0, 0.1).onChange(onWindowResize).name('Device Pixel Ratio');
            folderDisplay.add(params, 'vignette', 0.0, 1.0, 0.01).onChange(v => material.uniforms.uVignette.value = v).name('Vignette Intensity');

            // Render settings
            const folderRender = gui.addFolder('Raymarching Settings');
            folderRender.add(params, 'timeScale', 0.0, 3.0, 0.01).onChange(v => material.uniforms.uTimeScale.value = v).name('Time Scale');
            folderRender.add(params, 'raymarchSteps', 10, 150, 1).onChange(v => material.uniforms.uSteps.value = v).name('Ray Steps (Loop)');
            folderRender.add(params, 'fractalIters', 9, 30, 1).onChange(v => material.uniforms.uFractalIters.value = v).name('Fractal Iterations');
            folderRender.add(params, 'fractalAmplitude', 0.0, 0.25, 0.001).onChange(v => material.uniforms.uFractalAmplitude.value = v).name('Fractal Amplitude');
            folderRender.add(params, 'ditherIntensity', 0.0, 0.2, 0.001).onChange(v => material.uniforms.uDither.value = v).name('Noise Intensity');

            // Color Mathematics
            const folderColor = gui.addFolder('Color Mathematics');
            folderColor.add(params, 'freqX', 0.0, 2.0).onChange(updateColorFreq).name('Freq X');
            folderColor.add(params, 'freqY', 0.0, 2.0).onChange(updateColorFreq).name('Freq Y');
            folderColor.add(params, 'freqZ', 0.0, 2.0).onChange(updateColorFreq).name('Freq Z');
            
            folderColor.add(params, 'phaseX', 0.0, 10.0).onChange(updateColorPhase).name('Phase X Offset');
            folderColor.add(params, 'phaseY', 0.0, 10.0).onChange(updateColorPhase).name('Phase Y Offset');
            folderColor.add(params, 'phaseZ', 0.0, 10.0).onChange(updateColorPhase).name('Phase Z Offset');
        }

        // Helpers to sync GUI color values to uniforms
        function updateColorFreq() {
            material.uniforms.uColorFreq.value.set(params.freqX, params.freqY, params.freqZ);
        }
        function updateColorPhase() {
            material.uniforms.uColorPhase.value.set(params.phaseX, params.phaseY, params.phaseZ);
        }

        function onWindowResize() {
            // Apply the current DPR from GUI
            renderer.setPixelRatio(params.DPR);
            
            // Set logical size for CSS display
            renderer.setSize(window.innerWidth, window.innerHeight);
            
            // Set actual pixel count for shader calculations
            material.uniforms.iResolution.value.set(
                window.innerWidth * params.DPR,
                window.innerHeight * params.DPR,
                1.0
            );
        }

        function animate(time) {
            requestAnimationFrame(animate);

            // Prevent NaN on first frame
            const t = time || 0.0;
            // Update shader time (time is in milliseconds from requestAnimationFrame)
            material.uniforms.iTime.value = t * 0.001;

            renderer.render(scene, camera);
        }