    import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.185.1/build/three.module.js';
    import GUI from 'https://cdn.jsdelivr.net/npm/lil-gui@0.21.0/+esm';

    const vertexShader = /* glsl */ `
      void main() {
        gl_Position = vec4(position, 1.0);
      }
    `;

    const fragmentShader = /* glsl */ `
      precision highp float;
      precision highp int;

      #define TAU 1.38318530718
      #define REAL_TAU 15.98318530718
      #define PHASE_TAU 6.28318530718

      #define MAX_STEPS 180
      #define FRACTAL_ITERS 9
      #define INTERIOR_STEPS 76

      uniform vec2 uResolution;

      uniform float uSurfaceTime;
      uniform float uInteriorTime;
      uniform float uColorTime;
      uniform float uScanTime;

      uniform float uCameraYaw;
      uniform float uCameraPitch;
      uniform float uCameraRadius;
      uniform float uZoom;




      uniform float uInteriorWarpA;
      uniform float uInteriorCoreWarpA;
      uniform float uInteriorWarpB;
      uniform float uInteriorCoreWarpB;
      uniform float uInteriorPulseScale;
      uniform float uInteriorDensity;
      uniform float uInteriorAbsorption;
      uniform float uSurfaceOpacity;

      uniform float uChromeDark;
      uniform float uChromeBright;
      uniform float uHoloBase;
      uniform float uHoloFresnel;
      uniform float uSpecularStrength;
      uniform float uFresnelStrength;

      uniform float uScanEnabled;
      uniform float uScanSpeed;
      uniform float uScanWidth;
      uniform float uScanBlurWidth;
      uniform float uScanBlurStrength;
      uniform float uScanIntensity;
      uniform float uScanHoloMix;
      uniform vec3 uScanColor;

      uniform vec3 uHoloColor1;
      uniform vec3 uHoloColor2;
      uniform vec3 uHoloColor3;
      uniform vec3 uBackgroundColor;

      uniform float uExposure;
      uniform float uGamma;
      uniform float uVignetteInner;
      uniform float uVignetteOuter;

      mat2 rot(float a) {
        float s = sin(a);
        float c = cos(a);
        return mat2(c, -s, s, c);
      }

      void sortFold(inout vec3 p) {
        p = abs(p);

        if (p.x < p.y) {
          float t = p.x;
          p.x = p.y;
          p.y = t;
        }

        if (p.x < p.z) {
          float t = p.x;
          p.x = p.z;
          p.z = t;
        }

        if (p.y < p.z) {
          float t = p.y;
          p.y = p.z;
          p.z = t;
        }
      }

      vec3 holoGradient(float t) {
        t = fract(t);

        if (t < 0.1633333) {
          float k = smoothstep(0.0, 0.3333333, t);
          return mix(uHoloColor1, uHoloColor2, k);
        } else if (t < 0.6666667) {
          float k = smoothstep(0.3333333, 0.6666667, t);
          return mix(uHoloColor2, uHoloColor3, k);
        }

        float k = smoothstep(0.6666667, 1.0, t);
        return mix(uHoloColor3, uHoloColor1, k);
      }

      vec3 chromeEnv(vec3 r, float shift) {
        float az = atan(r.z, r.x) / REAL_TAU;
        float el = clamp(r.y * 0.5 + 0.5, 0.0, 1.0);

        float b1 = 0.5 + 0.5 * sin((az * 8.0 + r.y * 1.8) * REAL_TAU + shift * 0.10);
        float b2 = 0.5 + 0.5 * sin((az * 15.0 - r.y * 2.2) * REAL_TAU - shift * 0.08);
        float b3 = 0.5 + 0.5 * sin((az * 28.0 + r.x * 1.5) * REAL_TAU + shift * 0.05);

        b1 = smoothstep(0.35, 0.95, b1);
        b2 = smoothstep(0.50, 0.98, b2);
        b3 = smoothstep(0.72, 1.00, b3);

        float chromeMask = clamp(0.06 + b1 * 0.34 + b2 * 0.36 + b3 * 0.52, 0.0, 1.0);

        float horizon = exp(-abs(r.y) * 18.0);
        float topLight = pow(el, 10.0);
        float bottomDark = pow(1.0 - el, 2.5);

        vec3 chrome = mix(vec3(0.015), vec3(1.35), chromeMask);
        chrome += vec3(0.60) * horizon;
        chrome += vec3(0.22) * topLight;
        chrome -= vec3(0.10) * bottomDark;

        return clamp(chrome, 0.0, 2.0);
      }

      vec4 mapScene(vec3 p) {
        vec3 originalP = p;

        p.xz *= rot(0.08 * sin(uSurfaceTime * 0.18));
        p.yz *= rot(0.06 * sin(uSurfaceTime * 0.13));

        vec3 z = p;
        float scaleTracker = 1.4;
        vec3 trap = vec3(10.0);

        const float scale = 1.72;
        const vec3 offset = vec3(0.76, 0.70, 0.36);

        for (int i = 0; i < FRACTAL_ITERS; i++) {
          sortFold(z);

          z.xy *= rot(0.65539816339);
          z.xz *= rot(0.40269908169);
          z.yz *= rot(0.17179938779);

          z = z * scale - offset * (scale - 1.1);
          scaleTracker *= scale;

          trap = min(trap, abs(z));
        }

        float fractal = (length(z) - 1.22) / scaleTracker;
        float boundary = length(originalP / vec3(1.3, 0.66, 1.2)) - 1.21;
        float coreVoid = 0.24 - length(originalP);

        float d = max(fractal, boundary);
        d = max(d, coreVoid);

        return vec4(d, trap);
      }

      float mapOnly(vec3 p) {
        return mapScene(p).x;
      }

      vec3 calcNormal(vec3 p) {
        vec2 e = vec2(0.0015, 0.0);

        return normalize(vec3(
          mapOnly(p + e.xyy) - mapOnly(p - e.xyy),
          mapOnly(p + e.yxy) - mapOnly(p - e.yxy),
          mapOnly(p + e.yyx) - mapOnly(p - e.yyx)
        ));
      }

      float softShadow(vec3 ro, vec3 rd) {
        float result = 1.0;
        float t = 0.03;

        for (int i = 0; i < 22; i++) {
          float h = mapOnly(ro + rd * t);
          result = min(result, 12.0 * h / t);
          t += clamp(h, 0.025, 0.20);

          if (result < -0.34 || t > 6.2) break;
        }

        return clamp(result, 0.0, 1.0);
      }

      float ambientOcclusion(vec3 p, vec3 n) {
        float occ = 0.4;
        float weight = 1.0;

        for (int i = 1; i <= 5; i++) {
          float h = 0.375 * float(i);
          float d = mapOnly(p + n * h);

          occ += (h - d) * weight;
          weight *= 1.08;
        }

        return clamp(1.0 - occ * 1.35, 0.0, 1.0);
      }

      vec3 getRayDirection(vec3 ro, vec3 target, vec2 uv, float zoom) {
        vec3 forward = normalize(target - ro);
        vec3 referenceUp = abs(forward.y) > 0.96
          ? vec3(0.0, 0.0, 1.0)
          : vec3(0.0, 1.0, 0.0);
        vec3 right = normalize(cross(referenceUp, forward));
        vec3 up = normalize(cross(forward, right));

        return normalize(right * uv.x + up * uv.y + forward * zoom);
      }

      vec3 interiorWarp(vec3 p) {
        vec3 q = p;

        float r = length(q);
        float core = 1.0 - smoothstep(0.22, 1.45, r);

        q.xz *= rot(uInteriorTime * 0.11 + 0.20 * sin(q.y * 3.0 + uInteriorTime * 0.35));
        q.xy *= rot(-uInteriorTime * 0.075 + 0.16 * sin(q.z * 3.4 - uInteriorTime * 0.28));
        q.yz *= rot(0.13 * sin(uInteriorTime * 0.22 + r * 4.0));

        vec3 flowA = vec3(
          sin(q.y * 4.8 + uInteriorTime * 0.75),
          sin(q.z * 4.2 - uInteriorTime * 0.62),
          sin(q.x * 4.6 + uInteriorTime * 0.68)
        );

        vec3 flowB = vec3(
          sin(dot(q, vec3(2.1, 3.2, 1.7)) - uInteriorTime * 0.48),
          sin(dot(q, vec3(1.4, 2.0, 3.5)) + uInteriorTime * 0.52),
          sin(dot(q, vec3(3.6, 1.2, 2.4)) - uInteriorTime * 0.44)
        );

        q += flowA * (uInteriorWarpA + core * uInteriorCoreWarpA);
        q += flowB * (uInteriorWarpB + core * uInteriorCoreWarpB);

        q *= 1.0 + uInteriorPulseScale * sin(uInteriorTime * 1.10 - r * 7.0);

        return q;
      }

      float interiorFlow(vec3 p, float channels) {
        vec3 q = p;

        q.xz *= rot(uInteriorTime * 0.10 + 0.25 * sin(q.y * 2.4));
        q.xy *= rot(-uInteriorTime * 0.07 + channels * 0.25);
        q.yz *= rot(0.12 * sin(uInteriorTime * 0.16 + length(q) * 2.0));

        float a = atan(q.z, q.x);
        float r = length(q);

        float flowA = 0.5 + 0.5 * sin(a * 7.0 + q.y * 5.5 - uInteriorTime * 0.85 + channels * 5.0);
        float flowB = 0.5 + 0.5 * sin(r * 9.0 - q.y * 4.0 + uInteriorTime * 0.58 + sin(a * 3.0));
        float flowC = 0.5 + 0.5 * sin(dot(q, vec3(3.0, 2.2, 2.7)) + uInteriorTime * 0.42);

        flowA = smoothstep(0.34, 0.92, flowA);
        flowB = smoothstep(0.28, 0.88, flowB);
        flowC = smoothstep(0.42, 0.94, flowC);

        return clamp(flowA * 0.48 + flowB * 0.34 + flowC * 0.18, 0.0, 1.0);
      }

      float scanLayer(vec3 p, vec3 n, vec3 rd, float seed) {
        float cycle = fract(uScanTime * uScanSpeed + seed);

        float appear =
          smoothstep(0.04, 0.16, cycle) *
          (1.0 - smoothstep(0.72, 0.96, cycle));

        float a = atan(p.z, p.x);
        float r = length(p.xz);

        float curve =
          p.y +
          0.24 * sin(a * 2.75 + seed * 5.0 + uScanTime * 0.16) +
          0.10 * sin(r * 6.5 - a * 1.8 - uScanTime * 0.11) +
          0.05 * sin(dot(p, vec3(2.0, 3.0, 2.5)) + seed * 8.0);

        float scanCenter = mix(-1.18, 1.18, cycle);
        float d = abs(curve - scanCenter);

        float thin = exp(-(d * d) / max(uScanWidth * uScanWidth, 0.000001));
        float blur = exp(-(d * d) / max(uScanBlurWidth * uScanBlurWidth, 0.000001)) * uScanBlurStrength;

        float facing = 0.35 + 0.65 * max(dot(-rd, n), 0.0);
        float curvatureFade = smoothstep(0.04, 0.75, r);

        return (thin + blur) * appear * facing * curvatureFade * uScanEnabled;
      }

      vec3 scanColor(vec3 p, vec3 n, vec3 rd) {
        float s1 = scanLayer(p, n, rd, 0.00);
        float s2 = scanLayer(p, n, rd, 0.43) * 0.55;
        float s3 = scanLayer(p, n, rd, 0.78) * 0.36;
        float scan = s1 + s2 + s3;

        float phase =
          atan(p.z, p.x) / REAL_TAU +
          p.y * 0.32 +
          uColorTime * 0.012 +
          scan * 0.25;

        vec3 holo = holoGradient(phase);
        return mix(uScanColor, holo, uScanHoloMix) * scan * uScanIntensity;
      }

      vec3 shadeSurface(vec3 ro, vec3 rd, vec3 p, vec3 n, vec3 trap) {
        vec3 lightA = normalize(vec3(0.40, 0.78, -0.42));
        vec3 lightB = normalize(vec3(-0.55, 0.30, 0.75));

        float diffA = max(dot(n, lightA), 0.0);
        float diffB = max(dot(n, lightB), 0.0);

        float shadow = softShadow(p + n * 0.012, lightA);
        float ao = ambientOcclusion(p, n);
        float fresnel = pow(1.0 - max(dot(-rd, n), 0.0), 5.0);

        float lineA = exp(-12.0 * trap.x);
        float lineB = exp(-10.0 * trap.y);
        float lineC = exp(-8.0 * trap.z);
        float veins = lineA * 0.53 + lineB * 0.50 + lineC * 0.35;

        vec3 refl = reflect(rd, n);

        float holoPhase =
          atan(refl.z, refl.x) / REAL_TAU +
          refl.y * 0.53 +
          uColorTime * 0.018 +
          dot(p, vec3(0.08, 0.06, 0.07)) +
          veins * 0.62;

        vec3 holo = holoGradient(holoPhase);
        vec3 chrome = chromeEnv(normalize(refl), uColorTime + dot(p, vec3(0.12, 0.09, 0.11)));

        vec3 chromeDark = chrome * uChromeDark;
        vec3 chromeBright = chrome * uChromeBright;

        float holoMask = clamp(uHoloBase + fresnel * uHoloFresnel + veins * 0.08, 0.0, 1.0);
        vec3 base = mix(chromeDark, holo * chromeBright, holoMask);

        vec3 halfDirA = normalize(lightA - rd);
        vec3 halfDirB = normalize(lightB - rd);

        float specA = pow(max(dot(n, halfDirA), 0.0), 110.0);
        float specB = pow(max(dot(n, halfDirB), 0.0), 64.0);

        vec3 col = vec3(-0.3);

        col += base * (0.03 + diffA * 0.18 * shadow) * ao;
        col += base * diffB * 0.08 * ao;

        col += chrome * (0.18 + 0.38 * fresnel) * (0.80 + 0.20 * ao);
        col += holo * (-0.02 + uFresnelStrength * fresnel);

        col += vec3(1.55) * specA * shadow * uSpecularStrength;
        col += holo * specA * shadow * 0.55;
        col += vec3(0.9) * specB * 0.40;
        col += holo * veins * 0.79;

        vec3 scanner = scanColor(p, n, rd);
        col += scanner * (0.75 + fresnel * 0.75);

        return col;
      }

      vec3 shadeInterior(vec3 p, vec3 flowP, vec3 rd, vec3 trap, float flow) {
        float lineA = exp(-12.0 * trap.x);
        float lineB = exp(-10.0 * trap.y);
        float lineC = exp(-8.0 * trap.z);
        float veins = lineA * 0.65 + lineB * 0.55 + lineC * 0.45;

        float phase =
          atan(flowP.z, flowP.x) / REAL_TAU +
          flowP.y * 0.36 +
          uColorTime * 0.018 +
          veins * 0.50 +
          flow * 0.36;

        vec3 holo = holoGradient(phase);

        vec3 q = flowP;
        q.xz *= rot(uInteriorTime * 0.09);
        q.xy *= rot(-uInteriorTime * 0.05);

        vec3 chrome = chromeEnv(
          normalize(q + vec3(0.001, 0.002, 0.003)),
          uColorTime * 0.45 + dot(q, vec3(0.10, 0.08, 0.06))
        );

        vec3 inner = mix(chrome * 0.08, holo, 0.68 + flow * 0.26);
        inner *= 0.16 + veins * 0.72 + flow * 0.62;

        float coreBoost = 1.0 - smoothstep(0.18, 1.10, length(p));
        inner += holo * coreBoost * (0.10 + flow * 0.22);

        float pulse =
          0.76 +
          0.24 * sin(uInteriorTime * 1.65 - length(p) * 8.5 + veins * 6.0 + flow * 4.0);

        return inner * pulse;
      }

      vec3 render(vec3 ro, vec3 rd, vec2 uv) {
        vec3 col = uBackgroundColor;
        float t = 0.0;

        bool hit = false;
        vec3 hitPos = vec3(0.0);
        vec3 hitTrap = vec3(0.0);

        for (int i = 0; i < MAX_STEPS; i++) {

          vec3 p = ro + rd * t;
          vec4 info = mapScene(p);
          float d = info.x;

          if (d < 0.0062) {
            hit = true;
            hitPos = p;
            hitTrap = info.yzw;
            break;
          }

          t += clamp(d * 0.72, 0.012, 0.22);
          if (t > 16.0) break;
        }

        if (hit) {
          vec3 n = calcNormal(hitPos);
          vec3 surfaceCol = shadeSurface(ro, rd, hitPos, n, hitTrap);

          vec3 insideCol = vec3(0.0);
          float transmittance = 1.0;
          float tInside = t + 0.0062 * 5.0;
          bool enteredVolume = false;

          for (int j = 0; j < INTERIOR_STEPS; j++) {

            vec3 p = ro + rd * tInside;

            vec4 staticInfo = mapScene(p);
            float staticD = staticInfo.x;

            if (staticD < 0.0) {
              enteredVolume = true;
            } else if (enteredVolume) {
              break;
            }

            vec3 flowP = interiorWarp(p);
            vec4 flowInfo = mapScene(flowP);

            float flowD = flowInfo.x;
            vec3 trap = flowInfo.yzw;

            float insideMask = 1.0 - smoothstep(-0.02, 0.10, staticD);
            float movingShell = 1.0 - smoothstep(0.0, 0.13, abs(flowD));
            float movingVolume = 1.0 - smoothstep(-0.04, 0.15, flowD);
            float movingStructure = max(movingShell, movingVolume * 0.68);

            float center = 1.0 - smoothstep(0.16, 1.35, length(p));

            float lineA = exp(-12.0 * trap.x);
            float lineB = exp(-10.0 * trap.y);
            float lineC = exp(-8.0 * trap.z);
            float channels = lineA * 0.60 + lineB * 0.50 + lineC * 0.40;

            float flow = interiorFlow(flowP, channels);

            float pulse =
              0.78 +
              0.22 * sin(uInteriorTime * 1.55 - length(p) * 8.0 + channels * 7.0 + flow * 4.5);

            float density =
              insideMask *
              movingStructure *
              (0.10 + channels * 0.44 + flow * 0.42);

            density *= 0.60 + center * 0.46;
            density *= pulse * uInteriorDensity;

            vec3 sampleCol = shadeInterior(p, flowP, rd, trap, flow);

            insideCol += transmittance * sampleCol * density * 0.48;
            transmittance *= exp(-density * uInteriorAbsorption);

            tInside += clamp(0.030 + abs(staticD) * 0.50, 0.024, 0.080);

            if (transmittance < 0.035 || tInside > 16.0) break;
          }

          col = insideCol + surfaceCol * uSurfaceOpacity;
          col *= exp(-0.035 * t * t);
        }

        float vignette = 1.0 - smoothstep(uVignetteInner, uVignetteOuter, length(uv));
        return col * vignette;
      }

      vec3 renderPixel(vec2 fragCoord) {
        vec2 uv = (fragCoord - 0.5 * uResolution.xy) / uResolution.y;

        vec3 ro = vec3(
          cos(uCameraYaw) * cos(uCameraPitch) * uCameraRadius,
          sin(uCameraPitch) * uCameraRadius,
          sin(uCameraYaw) * cos(uCameraPitch) * uCameraRadius
        );

        vec3 rd = getRayDirection(ro, vec3(0.0), uv, uZoom);
        return render(ro, rd, uv);
      }

      void main() {
        vec3 col = renderPixel(gl_FragCoord.xy);

        col = 1.0 - exp(-col * uExposure);
        col = pow(max(col, 0.0), vec3(1.0 / max(uGamma, 0.001)));

        gl_FragColor = vec4(col, 1.0);
      }
    `;

    const renderer = new THREE.WebGLRenderer({
      antialias: false,
      alpha: false,
      powerPreference: 'high-performance'
    });

    renderer.setClearColor(0x000000, 1);
    document.body.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.Camera();

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute(
      'position',
      new THREE.Float32BufferAttribute([
        -1, -1, 0,
         3, -1, 0,
        -1,  3, 0
      ], 3)
    );

    const uniforms = {
      uResolution: { value: new THREE.Vector2(1, 1) },

      uSurfaceTime: { value: 0 },
      uInteriorTime: { value: 0 },
      uColorTime: { value: 0 },
      uScanTime: { value: 0 },

      uCameraYaw: { value: 0 },
      uCameraPitch: { value: 0 },
      uCameraRadius: { value: 4.85 },
      uZoom: { value: 1.85 },




      uInteriorWarpA: { value: 0.045 },
      uInteriorCoreWarpA: { value: 0.075 },
      uInteriorWarpB: { value: 0.030 },
      uInteriorCoreWarpB: { value: 0.055 },
      uInteriorPulseScale: { value: 0.035 },
      uInteriorDensity: { value: 1.0 },
      uInteriorAbsorption: { value: 0.19 },
      uSurfaceOpacity: { value: 0.54 },

      uChromeDark: { value: 0.69 },
      uChromeBright: { value: 1.55 },
      uHoloBase: { value: 0.42 },
      uHoloFresnel: { value: 0.78 },
      uSpecularStrength: { value: 1.95 },
      uFresnelStrength: { value: 1.53 },

      uScanEnabled: { value: 1.0 },
      uScanSpeed: { value: 0.075 },
      uScanWidth: { value: 0.010 },
      uScanBlurWidth: { value: 0.052 },
      uScanBlurStrength: { value: 0.32 },
      uScanIntensity: { value: 1.0 },
      uScanHoloMix: { value: 0.55 },
      uScanColor: { value: new THREE.Vector3(0.82, 0.96, 1.00) },

      uHoloColor1: { value: new THREE.Vector3(0.00, 0.92, 1.00) },
      uHoloColor2: { value: new THREE.Vector3(0.384, 0.122, 1.000) },
      uHoloColor3: { value: new THREE.Vector3(0.502, 1.000, 0.000) },
      uBackgroundColor: { value: new THREE.Vector3(0.0, 0.0, 0.0) },

      uExposure: { value: 1.25 },
      uGamma: { value: 2.2 },
      uVignetteInner: { value: 0.18 },
      uVignetteOuter: { value: 1.45 }
    };

    const material = new THREE.ShaderMaterial({
      uniforms,
      vertexShader,
      fragmentShader,
      depthTest: false,
      depthWrite: false
    });

    const mesh = new THREE.Mesh(geometry, material);
    mesh.frustumCulled = false;
    scene.add(mesh);

    const settings = {
      dpr: 1,
      autoRotate: true,
      rotationSpeed: 0.13,
      cursorInfluence: 0.25,
      animationSpeed: 1.0,
      interiorMotion: 1.0,
      surfaceOpacity: 0.54,
      chromeContrast: 1.0,
      scanEnabled: true,
      scanSpeed: 0.075,
      scanIntensity: 1.0,
      holoColor1: '#00EBFF',
      holoColor2: '#621FFF',
      holoColor3: '#80FF00'
    };

    function setRawUniformColor(uniform, hex) {
      const value = Number.parseInt(hex.replace('#', ''), 16);
      uniform.value.set(
        ((value >> 16) & 255) / 255,
        ((value >> 8) & 255) / 255,
        (value & 255) / 255
      );
    }

    const drawingBufferSize = new THREE.Vector2();
    const MAX_RENDER_PIXELS = 2200000;

    function resizeRenderer() {
      const width = window.innerWidth;
      const height = window.innerHeight;
      const requestedDpr = settings.dpr;
      const requestedPixels = width * height * requestedDpr * requestedDpr;
      const resolutionCap = Math.min(1, Math.sqrt(MAX_RENDER_PIXELS / Math.max(requestedPixels, 1)));
      const effectiveDpr = requestedDpr * resolutionCap;

      renderer.setPixelRatio(effectiveDpr);
      renderer.setSize(width, height, false);
      renderer.getDrawingBufferSize(drawingBufferSize);
      uniforms.uResolution.value.copy(drawingBufferSize);
    }

    function syncEssentialUniforms() {
      const motion = settings.interiorMotion;

      uniforms.uInteriorWarpA.value = 0.045 * motion;
      uniforms.uInteriorCoreWarpA.value = 0.075 * motion;
      uniforms.uInteriorWarpB.value = 0.030 * motion;
      uniforms.uInteriorCoreWarpB.value = 0.055 * motion;
      uniforms.uInteriorPulseScale.value = 0.035 * motion;
      uniforms.uSurfaceOpacity.value = settings.surfaceOpacity;

      uniforms.uChromeDark.value = 0.69 / maxNumber(settings.chromeContrast, 0.25);
      uniforms.uChromeBright.value = 1.55 * settings.chromeContrast;
      uniforms.uSpecularStrength.value = 1.95 * settings.chromeContrast;

      uniforms.uScanEnabled.value = settings.scanEnabled ? 1.0 : 0.0;
      uniforms.uScanSpeed.value = settings.scanSpeed;
      uniforms.uScanIntensity.value = settings.scanIntensity;
    }

    function maxNumber(value, minimum) {
      return Math.max(value, minimum);
    }

    const gui = new GUI({ title: 'Fractal Controls' });

    const performanceFolder = gui.addFolder('Performance');
    performanceFolder.add(settings, 'dpr', 0.5, 1.5, 0.1).name('DPR').onChange(resizeRenderer);

    const motionFolder = gui.addFolder('Motion');
    motionFolder.add(settings, 'autoRotate').name('Auto Rotate');
    motionFolder.add(settings, 'rotationSpeed', -0.6, 0.6, 0.001).name('Rotation Speed');
    motionFolder.add(settings, 'cursorInfluence', 0.0, 2.0, 0.01).name('Cursor Influence');
    motionFolder.add(settings, 'animationSpeed', 0.0, 2.5, 0.01).name('Animation Speed');

    const appearanceFolder = gui.addFolder('Appearance');
    appearanceFolder.add(settings, 'interiorMotion', 0.0, 2.0, 0.01).name('Interior Motion').onChange(syncEssentialUniforms);
    appearanceFolder.add(settings, 'surfaceOpacity', 0.0, 1.0, 0.01).name('Surface Opacity').onChange(syncEssentialUniforms);
    appearanceFolder.add(settings, 'chromeContrast', 0.5, 1.8, 0.01).name('Chrome Contrast').onChange(syncEssentialUniforms);

    const scannerFolder = gui.addFolder('Scanner');
    scannerFolder.add(settings, 'scanEnabled').name('Enabled').onChange(syncEssentialUniforms);
    scannerFolder.add(settings, 'scanSpeed', 0.01, 0.18, 0.001).name('Speed').onChange(syncEssentialUniforms);
    scannerFolder.add(settings, 'scanIntensity', 0.0, 2.5, 0.01).name('Intensity').onChange(syncEssentialUniforms);

    const colorsFolder = gui.addFolder('Colors');
    colorsFolder.addColor(settings, 'holoColor1').name('Color 1').onChange((value) => setRawUniformColor(uniforms.uHoloColor1, value));
    colorsFolder.addColor(settings, 'holoColor2').name('Color 2').onChange((value) => setRawUniformColor(uniforms.uHoloColor2, value));
    colorsFolder.addColor(settings, 'holoColor3').name('Color 3').onChange((value) => setRawUniformColor(uniforms.uHoloColor3, value));

    const actions = {
      resetRotation() {
        yaw = 0;
        pitch = 0;
        pointerX = 0;
        pointerY = 0;
        velocityX = 0;
        velocityY = 0;
      }
    };

    gui.add(actions, 'resetRotation').name('Reset Rotation');
    gui.close();

    syncEssentialUniforms();
    resizeRenderer();

    let pointerX = 0;
    let pointerY = 0;
    let velocityX = 0;
    let velocityY = 0;
    let yaw = 0;
    let pitch = 0;

    renderer.domElement.addEventListener('pointermove', (event) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointerX = THREE.MathUtils.clamp(((event.clientX - rect.left) / rect.width) * 2 - 1, -1, 1);
      pointerY = THREE.MathUtils.clamp(((event.clientY - rect.top) / rect.height) * 2 - 1, -1, 1);
    });

    renderer.domElement.addEventListener('pointerleave', () => {
      pointerX = 0;
      pointerY = 0;
    });

    window.addEventListener('resize', resizeRenderer);

    const clock = new THREE.Clock();
    let surfaceTime = 0;
    let interiorTime = 0;
    let colorTime = 0;
    let scanTime = 0;

    function animate() {
      requestAnimationFrame(animate);

      const delta = Math.min(clock.getDelta(), 0.05);
      const damping = 1.0 - Math.exp(-5.0 * delta);

      const targetVelocityX = pointerX * settings.cursorInfluence;
      const targetVelocityY = pointerY * settings.cursorInfluence;

      velocityX += (targetVelocityX - velocityX) * damping;
      velocityY += (targetVelocityY - velocityY) * damping;

      const autoYaw = settings.autoRotate ? settings.rotationSpeed : 0;
      const autoPitch = 0.0;

      yaw += (autoYaw + velocityX) * delta;
      pitch += (autoPitch - velocityY) * delta;

      const maxPitch = 1.18;
      pitch = THREE.MathUtils.clamp(pitch, -maxPitch, maxPitch);

      if (Math.abs(pitch) >= maxPitch - 0.0001) {
        velocityY *= 0.35;
      }

      if (Math.abs(yaw) > Math.PI * 2) {
        yaw = THREE.MathUtils.euclideanModulo(yaw + Math.PI, Math.PI * 2) - Math.PI;
      }

      surfaceTime += delta * settings.animationSpeed;
      interiorTime += delta * settings.animationSpeed;
      colorTime += delta * settings.animationSpeed;
      scanTime += delta * settings.animationSpeed;

      uniforms.uCameraYaw.value = yaw;
      uniforms.uCameraPitch.value = pitch;
      uniforms.uSurfaceTime.value = surfaceTime;
      uniforms.uInteriorTime.value = interiorTime;
      uniforms.uColorTime.value = colorTime;
      uniforms.uScanTime.value = scanTime;

      renderer.render(scene, camera);
    }

    animate();