# Disco Ball – Support me by PayPal: https://paypal.com/paypalme/sabosugi

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/NPbvWLy](https://codepen.io/sabosugi/pen/NPbvWLy).

