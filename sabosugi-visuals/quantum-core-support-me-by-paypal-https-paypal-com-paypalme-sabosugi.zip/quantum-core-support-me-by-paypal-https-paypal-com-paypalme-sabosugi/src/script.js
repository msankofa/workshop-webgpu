        import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- Application State ---
        const state = {
            dpr: 1.0,
            cubeSize: 4.9,
            speed: 1.0,
            fractalScale: 1.0,
            distortion: 0.0,
            glow: 0.54,
            colorR: 2.0,
            colorG: 1.0,
            colorB: 0.0
        };

        // --- Mouse Interaction State ---
        let isDragging = false;
        let previousMousePosition = { x: 0, y: 0 };
        let targetRotation = { x: 0, y: 0 };
        let currentRotation = { x: 0, y: 0 };

        // --- Setup Three.js ---
        // OPTIMIZATION: antialias: false - MSAA is useless for full-screen shaders and wastes GPU memory/bandwidth
        const renderer = new THREE.WebGLRenderer({ antialias: false });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(state.dpr);
        document.body.appendChild(renderer.domElement);

        // We use an OrthographicCamera to render a full screen quad
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        const scene = new THREE.Scene();

        // --- Shader Material ---
        const uniforms = {
            iTime: { value: 0 },
            iResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            u_mouseRot: { value: new THREE.Vector2(0, 0) },
            u_speed: { value: state.speed },
            u_cubeSize: { value: state.cubeSize },
            u_scale: { value: state.fractalScale },
            u_distortion: { value: state.distortion },
            u_glow: { value: state.glow },
            u_colorOffset: { value: new THREE.Vector3(state.colorR, state.colorG, state.colorB) }
        };

        const fragmentShader = `
            uniform vec2 iResolution;
            uniform float iTime;
            uniform vec2 u_mouseRot;
            
            // GUI Uniforms
            uniform float u_speed;
            uniform float u_cubeSize;
            uniform float u_scale;
            uniform float u_distortion;
            uniform float u_glow;
            uniform vec3 u_colorOffset;

            // AABB (Axis-Aligned Bounding Box) intersection function
            vec2 intersectBox(vec3 ro, vec3 rd, vec3 extents) {
                vec3 m = 0.99 / rd;
                vec3 n = m * ro;
                vec3 k = abs(m) * extents;
                vec3 t1 = -n - k;
                vec3 t2 = -n + k;
                
                float tNear = max(max(t1.x, t1.y), t1.z);
                float tFar  = min(min(t2.x, t2.y), t2.z);
                
                if (tNear > tFar || tFar < 0.0) return vec2(-1.0);
                return vec2(max(tNear, 0.0), tFar);
            }

            // 2D Rotation Matrix
            mat2 rotate(float a) {
                float s = sin(a), c = cos(a);
                return mat2(c, -s, s, c);
            }

            void mainImage(out vec4 fragColor, in vec2 fragCoord) {
                // Normalize coordinates and fix aspect ratio
                vec2 uv = (fragCoord.xy * 2.0 - iResolution.xy) / iResolution.y;

                // --- Camera Setup ---
                vec3 ro = vec3(0.0, 0.0, -22.0);
                vec3 rd = normalize(vec3(uv, 2.2)); 
                
                // Rotation integrating both time (speed) and mouse drag
                float time = iTime * 0.3 * u_speed;
                
                // Apply mouse drag rotation mapping
                mat2 rotX = rotate(u_mouseRot.y); 
                mat2 rotY = rotate(time + u_mouseRot.x);
                
                ro.yz *= rotX;
                ro.xz *= rotY;
                rd.yz *= rotX;
                rd.xz *= rotY;

                // --- Cube Boundaries ---
                vec3 boxExtents = vec3(u_cubeSize);
                vec2 hit = intersectBox(ro, rd, boxExtents);
                
                // Start with a pure black canvas to avoid gray artifact backgrounds
                vec3 accumCol = vec3(0.0); 
                
                // --- Volumetric Raymarching ---
                if (hit.y > 0.0) {
                    float t = hit.x;      
                    float tMax = hit.y;   
                    
                    // OPTIMIZATION: Pre-calculate constants outside the expensive 100-step loop
                    // 0.09 is exactly 0.15 * 0.6 from the original float iterator shift
                    vec3 colorBase = u_colorOffset + (iTime * 2.0) + 0.09;
                    
                    // OPTIMIZATION: Use integer loop counter for better GPU compiler unrolling
                    for (int i = 0; i < 100; i++) {
                        if (t >= tMax) break;
                        
                        vec3 pos = ro + rd * t;
                        vec3 q = pos * u_scale; 
                        
                        // OPTIMIZATION: Replaced division with multiplication (q * 0.25 instead of q / 4.0)
                        vec3 pWrap = abs(fract(q * 0.25) * 4.0 - 2.0);
                        
                        float dStruct = min(max(pWrap.x, pWrap.y), 
                                        min(max(pWrap.y, pWrap.z), 
                                            max(pWrap.x, pWrap.z))) - 1.0;
                                            
                        float distortion = 0.0;
                        // OPTIMIZATION: Skip expensive sine/cosine calculation entirely if distortion is set to 0.0
                        if (u_distortion > 0.001) {
                            distortion = u_distortion * dot(sin(q * 1.2), cos(q.yzx * 1.0));
                        }
                        
                        float shape = abs(dStruct) + distortion;
                        
                        float stepSize = max(0.01, 0.7 * abs(shape));
                        
                        // Strict boundary clamping
                        stepSize = min(stepSize, tMax - t);
                        
                        // Dynamic color palette
                        vec3 colorPalette = 0.5 + 0.5 * cos(0.15 * float(i) + colorBase);
                        
                        // Soft Edge Fade (removed redundant smoothstep that always equaled 1.0)
                        float edgeFade = smoothstep(0.0, 0.5, t - hit.x);
                        
                        // Accumulate volume color properly
                        float weight = stepSize * edgeFade * (0.049 / (abs(shape) + 0.09));
                        accumCol += colorPalette * weight;
                        
                        t += stepSize;
                    }
                }
                
                // --- Post-Processing ---
                // Add the center screen glow outside the loop. Prevent division by zero.
                vec3 vignette = vec3(0.2, 0.4, 0.6) / max(length(uv) * 9.8, 0.001);
                accumCol += vignette * u_glow;
                
                // Smooth tone mapping
                vec3 finalColor = tanh(accumCol * 1.4);
                
                // Explicit pure black background for empty space
                if (hit.y < 0.0) finalColor = vec3(0.0);

                fragColor = vec4(finalColor, 1.0);
            }

            void main() {
                mainImage(gl_FragColor, gl_FragCoord.xy);
            }
        `;

        // OPTIMIZATION: Disabled depthWrite and depthTest as they are not needed for a flat 2D shader plane
        const material = new THREE.ShaderMaterial({
            fragmentShader: fragmentShader,
            uniforms: uniforms,
            depthWrite: false,
            depthTest: false
        });

        // Add a simple quad to render the shader onto
        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- GUI Setup (lil-gui) ---
        const gui = new GUI({ title: 'Shader Controls' });

        const renderFolder = gui.addFolder('Render Settings');
        renderFolder.add(state, 'dpr', 0.1, 2.0, 0.1).name('DPR (Resolution)').onChange(val => {
            renderer.setPixelRatio(val);
        });

        const sceneFolder = gui.addFolder('Scene Settings');
        sceneFolder.add(state, 'cubeSize', 1.0, 8.0, 0.1).name('Cube Size').onChange(v => uniforms.u_cubeSize.value = v);
        sceneFolder.add(state, 'speed', 0.0, 3.0, 0.1).name('Auto-Rotate Speed').onChange(v => uniforms.u_speed.value = v);

        const fractalFolder = gui.addFolder('Fractal Data');
        fractalFolder.add(state, 'fractalScale', 0.5, 3.0, 0.1).name('Grid Scale').onChange(v => uniforms.u_scale.value = v);
        fractalFolder.add(state, 'distortion', 0.0, 1.0, 0.01).name('Distortion').onChange(v => uniforms.u_distortion.value = v);

        const colorFolder = gui.addFolder('Appearance');
        colorFolder.add(state, 'glow', 0.0, 2.0, 0.01).name('Core Glow').onChange(v => uniforms.u_glow.value = v);
        
        const updateColor = () => {
            uniforms.u_colorOffset.value.set(state.colorR, state.colorG, state.colorB);
        };
        colorFolder.add(state, 'colorR', 0.0, 5.0, 0.1).name('Color Offset R').onChange(updateColor);
        colorFolder.add(state, 'colorG', 0.0, 5.0, 0.1).name('Color Offset G').onChange(updateColor);
        colorFolder.add(state, 'colorB', 0.0, 5.0, 0.1).name('Color Offset B').onChange(updateColor);

        // Fold GUI by default as requested
        gui.close();

        // --- Mouse / Pointer Interaction ---
        window.addEventListener('pointerdown', (e) => {
            isDragging = true;
            previousMousePosition = { x: e.offsetX, y: e.offsetY };
            document.body.classList.add('dragging');
        });

        window.addEventListener('pointerup', () => {
            isDragging = false;
            document.body.classList.remove('dragging');
        });

        window.addEventListener('pointerleave', () => {
            isDragging = false;
            document.body.classList.remove('dragging');
        });

        window.addEventListener('pointermove', (e) => {
            if (isDragging) {
                const deltaMove = {
                    x: e.offsetX - previousMousePosition.x,
                    y: e.offsetY - previousMousePosition.y
                };

                // Inverted horizontal rotation (drag right -> rotate right intuitively)
                targetRotation.x -= deltaMove.x * 0.01;
                targetRotation.y += deltaMove.y * 0.01;

                // Clamp Y rotation to avoid flipping the cube completely over
                targetRotation.y = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, targetRotation.y));

                previousMousePosition = { x: e.offsetX, y: e.offsetY };
            }
        });

        // --- Window Resize Handling ---
        window.addEventListener('resize', () => {
            const width = window.innerWidth;
            const height = window.innerHeight;
            renderer.setSize(width, height);
            uniforms.iResolution.value.set(width, height);
        });

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);

            // Update Time
            uniforms.iTime.value = clock.getElapsedTime();

            // Smooth interpolation (lerp) for mouse rotation inertia
            currentRotation.x += (targetRotation.x - currentRotation.x) * 0.1;
            currentRotation.y += (targetRotation.y - currentRotation.y) * 0.1;
            uniforms.u_mouseRot.value.set(currentRotation.x, currentRotation.y);

            renderer.render(scene, camera);
        }

        animate();