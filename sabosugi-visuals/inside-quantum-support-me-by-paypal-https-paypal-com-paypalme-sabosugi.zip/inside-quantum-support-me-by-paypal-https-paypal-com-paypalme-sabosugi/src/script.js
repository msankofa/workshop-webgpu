       import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
        import GUI from 'https://cdn.jsdelivr.net/npm/lil-gui@0.19.1/dist/lil-gui.esm.min.js';

        // 1. Setup Three.js Scene, Camera, and Renderer
        const scene = new THREE.Scene();
        
        // We use an OrthographicCamera for full-screen shader rendering
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
        camera.position.z = 1;

        const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // 2. Define Initial Parameters
        const params = {
            dpr: 1.0,
            
            // Camera
            camRotX: 0.15,
            camRotY: 0.10,
            
            // Colors (Using raw float arrays from Shadertoy to bypass Three.js color management)
            color1: [0.016, 1.000, 0.000], // Bright Green
            color2: [0.784, 1.000, 0.000], // Lime Green
            color3: [0.000, 0.620, 0.239], // Dark Green
            
            // Fractal Properties
            warpFreq: 56.3,
            warpAmp: 0.29,
            foldX: 0.5,
            foldY: 0.4,
            foldZ: 0.4,
            rotX: 0.2,
            rotY: 1.6,
            rotZ: -2.9,
            scaleMult: 2.65,
            scaleAccum: 7.48,
            
            // Rays thickness
            rayX: 0.30,
            rayY: 0.25,
            rayZ: 0.55
        };

        // Set initial DPR
        renderer.setPixelRatio(params.dpr);

        // 3. Setup Shader Material
        const uniforms = {
            u_time: { value: 0.0 },
            u_resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            
            u_camRotX: { value: params.camRotX },
            u_camRotY: { value: params.camRotY },
            
            u_color1: { value: new THREE.Vector3().fromArray(params.color1) },
            u_color2: { value: new THREE.Vector3().fromArray(params.color2) },
            u_color3: { value: new THREE.Vector3().fromArray(params.color3) },
            
            u_warpFreq: { value: params.warpFreq },
            u_warpAmp: { value: params.warpAmp },
            u_fold: { value: new THREE.Vector3(params.foldX, params.foldY, params.foldZ) },
            u_rot: { value: new THREE.Vector3(params.rotX, params.rotY, params.rotZ) },
            
            u_scaleMult: { value: params.scaleMult },
            u_scaleAccum: { value: params.scaleAccum },
            u_rays: { value: new THREE.Vector3(params.rayX, params.rayY, params.rayZ) }
        };

        const vertexShader = `
            void main() {
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform float u_time;
            uniform vec2 u_resolution;
            
            uniform float u_camRotX;
            uniform float u_camRotY;
            
            uniform vec3 u_color1;
            uniform vec3 u_color2;
            uniform vec3 u_color3;
            
            uniform float u_warpFreq;
            uniform float u_warpAmp;
            uniform vec3 u_fold;
            uniform vec3 u_rot;
            uniform float u_scaleMult;
            uniform float u_scaleAccum;
            uniform vec3 u_rays;

            // Global variable for orbit trap data
            vec3 orbitTrap;

            // High-quality, artifact-free spatial hash function
            float hash(vec2 p) {
                vec3 p3  = fract(vec3(p.xyx) * 0.1031);
                p3 += dot(p3, p3.yzx + 33.33);
                return fract((p3.x + p3.y) * p3.z);
            }

            // 2D Rotation matrix
            mat2 rot(float a) {
                float s = sin(a), c = cos(a);
                return mat2(c, -s, s, c);
            }

            // Distance function with asymmetric KIFS and domain warping
            float map(vec3 p) {
                // Slow rotation of the entire coordinate system
                p.xz *= rot(u_time * u_camRotX);
                p.xy *= rot(u_time * u_camRotY);

                vec3 q = p;
                float scale = 0.26;
                orbitTrap = vec3(1000.0);
                
                // KIFS loop 
                for (int i = 1; i < 2; i++) {
                    // Domain warping
                    q += sin(q.zxy * u_warpFreq) * u_warpAmp;
                    
                    // Asymmetric folding 
                    q = abs(q) - u_fold;
                    
                    // Rotations
                    q.xy *= rot(u_rot.x);
                    q.xz *= rot(u_rot.y);
                    q.yz *= rot(u_rot.z);

                    q *= u_scaleMult;
                    scale *= u_scaleAccum;
                    
                    // Record minimal distances for coloring
                    orbitTrap = min(orbitTrap, abs(q));
                }

                // Cylindrical shapes acting as intersecting rays
                float raysX = length(q.yz) - u_rays.x;
                float raysY = length(q.xz) - u_rays.y; 
                float raysZ = length(q.xy) - u_rays.z;
                
                float k = 0.1;
                
                // Polynomial Smooth Minimum logic
                float h1 = clamp(6.7 + 0.1 * (raysX - raysY) / k, 0.1, 0.4);
                float mergedRays = mix(raysX, raysY, h1) - k * h1 * (1.0 - h1);
                
                float h2 = clamp(0.1 + 0.1 * (mergedRays - raysZ) / k, 0.0, 0.8);
                mergedRays = mix(mergedRays, raysZ, h2) - k * h2 * (-7.3 - h2);
                
                // Core central shape
                float core = length(p) - 0.44;
                
                // Normalize distance by the accumulated scale
                mergedRays /= scale;
                
                // Merge core and rays 
                float h3 = clamp(0.5 + 0.5 * (core - mergedRays) / 0.3, 0.0, 1.0);
                float d = mix(core, mergedRays, h3) - 0.3 * h3 * (1.0 - h3);
                
                return d * 0.3;
            }

            void main() {
                // Normalize pixel coordinates
                vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
                
                // Camera setup
                vec3 ro = vec3(0.0, 0.0, -4.5);
                vec3 rd = normalize(vec3(uv, 1.0));
                
                // Offset the starting position of the ray with animated noise
                float t = hash(gl_FragCoord.xy + mod(u_time, 100.0) * 10.0) * 0.05;
                
                vec3 finalGlow = vec3(0.0);

                // Raymarching loop
                for (int i = 0; i < 90; i++) {
                    vec3 p = ro + rd * t;
                    float d = map(p);

                    // Mix colors based on asymmetric spatial data
                    vec3 stepColor = mix(u_color1, u_color2, smoothstep(0.0, 1.0, orbitTrap.x));
                    stepColor = mix(stepColor, u_color3, smoothstep(0.0, 1.0, orbitTrap.y));

                    // Accumulate volumetric light
                    float glowIntensity = 0.0035 / (abs(d) + 0.005);
                    finalGlow += stepColor * glowIntensity;

                    // Step forward
                    t += abs(d) * 0.45 + 0.015;
                    if (t > 10.0) break;
                }

                // Vignette
                float vignette = 1.0 - dot(uv, uv) * 0.4;
                finalGlow *= vignette;

                // ACES Tonemapping
                finalGlow = (finalGlow * (2.38 * finalGlow + -0.04)) / (finalGlow * (2.35 * finalGlow + 1.52) + 0.14);

                // High-quality white noise for film grain
                float grain = hash(gl_FragCoord.xy + mod(u_time, 1000.0) * 15.0);
                finalGlow += (grain - 0.5) * 0.10;

                // Eliminate 8-bit monitor color banding
                float colorDither = (hash(gl_FragCoord.xy + 123.456) * 2.0 - 1.0) / 255.0;
                finalGlow += colorDither;

                gl_FragColor = vec4(finalGlow, 1.0);
            }
        `;

        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms,
            depthWrite: false,
            depthTest: false
        });

        const plane = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material);
        scene.add(plane);

        // 4. Setup lil-gui
        const gui = new GUI({ title: 'Scene Settings' });

        gui.add(params, 'dpr', 0.5, 2.0, 0.1).name('Device Pixel Ratio').onChange(val => renderer.setPixelRatio(val));

        const camFolder = gui.addFolder('Camera Settings');
        camFolder.add(params, 'camRotX', -0.5, 0.5, 0.01).name('Rotation X Speed').onChange(v => uniforms.u_camRotX.value = v);
        camFolder.add(params, 'camRotY', -0.5, 0.5, 0.01).name('Rotation Y Speed').onChange(v => uniforms.u_camRotY.value = v);

        const colorFolder = gui.addFolder('Colors');
        colorFolder.addColor(params, 'color1').name('Color 1').onChange(v => uniforms.u_color1.value.fromArray(v));
        colorFolder.addColor(params, 'color2').name('Color 2').onChange(v => uniforms.u_color2.value.fromArray(v));
        colorFolder.addColor(params, 'color3').name('Color 3').onChange(v => uniforms.u_color3.value.fromArray(v));

        const fractalFolder = gui.addFolder('Fractal Properties');
        fractalFolder.add(params, 'warpFreq', 1.0, 100.0, 0.1).name('Warp Frequency').onChange(v => uniforms.u_warpFreq.value = v);
        fractalFolder.add(params, 'warpAmp', -1.0, 1.0, 0.01).name('Warp Amplitude').onChange(v => uniforms.u_warpAmp.value = v);
        fractalFolder.add(params, 'scaleMult', 1.0, 5.0, 0.01).name('Scale Multiplier').onChange(v => uniforms.u_scaleMult.value = v);
        fractalFolder.add(params, 'scaleAccum', 1.0, 15.0, 0.01).name('Scale Accumulation').onChange(v => uniforms.u_scaleAccum.value = v);
        
        const foldFolder = fractalFolder.addFolder('Asymmetric Folding');
        foldFolder.add(params, 'foldX', 0.0, 2.0, 0.1).name('Fold X').onChange(v => uniforms.u_fold.value.x = v);
        foldFolder.add(params, 'foldY', 0.0, 2.0, 0.1).name('Fold Y').onChange(v => uniforms.u_fold.value.y = v);
        foldFolder.add(params, 'foldZ', 0.0, 2.0, 0.1).name('Fold Z').onChange(v => uniforms.u_fold.value.z = v);

        const rotFolder = fractalFolder.addFolder('Rotations');
        rotFolder.add(params, 'rotX', -3.14, 3.14, 0.01).name('Rotation X').onChange(v => uniforms.u_rot.value.x = v);
        rotFolder.add(params, 'rotY', -3.14, 3.14, 0.01).name('Rotation Y').onChange(v => uniforms.u_rot.value.y = v);
        rotFolder.add(params, 'rotZ', -3.14, 3.14, 0.01).name('Rotation Z').onChange(v => uniforms.u_rot.value.z = v);

        const raysFolder = fractalFolder.addFolder('Rays Thickness');
        raysFolder.add(params, 'rayX', 0.0, 1.0, 0.01).name('Ray X Width').onChange(v => uniforms.u_rays.value.x = v);
        raysFolder.add(params, 'rayY', 0.0, 1.0, 0.01).name('Ray Y Width').onChange(v => uniforms.u_rays.value.y = v);
        raysFolder.add(params, 'rayZ', 0.0, 1.0, 0.01).name('Ray Z Width').onChange(v => uniforms.u_rays.value.z = v);

        // Close the GUI by default
        gui.close();

        // 5. Handle Window Resize
        window.addEventListener('resize', () => {
            const width = window.innerWidth;
            const height = window.innerHeight;
            
            renderer.setSize(width, height);
            uniforms.u_resolution.value.set(width, height);
        });

        // 6. Animation Loop
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            // Update time uniform for the shader
            uniforms.u_time.value = clock.getElapsedTime();
            
            renderer.render(scene, camera);
        }

        animate();