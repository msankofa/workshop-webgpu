       import * as THREE from 'three';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { AfterimagePass } from 'three/addons/postprocessing/AfterimagePass.js';
        import GUI from 'lil-gui';

        // --- Core Variables ---
        let camera, scene, renderer, composer, afterimagePass;
        let movingMeshes = [];
        let baseMesh = null;
        let baseTexture = null;
        let currentTextures = [];
        let currentImageAspect = 1;
        let currentImgObj = null;
        let startupFade = 0.0;
        let particleSystem = null;
        
        // --- Settings ---
        const params = {
            speed: 2.0,
            blurAmount: 0.86328,
            fadeStartDistance: -902,
            layers: 5,
            staticDarkLayers: 1,      
            edgeSmoothing: 0.897,     
            groupDepth: 600,
            baseImageOpacity: 0.79,
            particlesEnabled: true,
            particleCount: 500000,
            particleSize: 1.5,
            particleBrightness: 1.0,
            uploadImage: () => document.getElementById('file-input').click()
        };

        const loadingEl = document.getElementById('loading');

        init();
        animate();

        function init() {
            // 1. Setup Scene and Camera
            scene = new THREE.Scene();
            camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 3000);
            camera.position.z = 0;

            // 2. Setup Renderer
            renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
            renderer.setPixelRatio(window.devicePixelRatio);
            renderer.setSize(window.innerWidth, window.innerHeight);
            document.body.appendChild(renderer.domElement);

            // 3. Setup Post-Processing (Motion Blur via Afterimage)
            composer = new EffectComposer(renderer);
            const renderPass = new RenderPass(scene, camera);
            composer.addPass(renderPass);

            afterimagePass = new AfterimagePass();
            afterimagePass.uniforms['damp'].value = params.blurAmount;
            composer.addPass(afterimagePass);

            // 4. Setup GUI
            setupGUI();

            // 5. Setup Events
            window.addEventListener('resize', onWindowResize);
            document.getElementById('file-input').addEventListener('change', handleFileUpload);

            // 6. Load Initial Default Image
            loadDefaultImage();
        }

        function setupGUI() {
            const gui = new GUI({ title: 'Scene Settings' });
            
            gui.add(params, 'speed', 0.1, 10.0).name('Movement Speed');
            gui.add(params, 'blurAmount', 0.0, 0.99).name('Motion Blur').onChange(v => {
                afterimagePass.uniforms['damp'].value = v;
            });
            gui.add(params, 'fadeStartDistance', -1500, 0).name('Fade Out Distance');
            
            // Texture regeneration folder
            const visualFolder = gui.addFolder('Visual Quality');
            visualFolder.add(params, 'baseImageOpacity', 0.0, 1.0, 0.01).name('Base Image Opacity');
            visualFolder.add(params, 'layers', 3, 16, 1).name('Total Layers').onFinishChange(reprocessImage);
            visualFolder.add(params, 'staticDarkLayers', 0, 10, 1).name('Static Dark Layers').onFinishChange(buildScene);
            visualFolder.add(params, 'edgeSmoothing', 0.0, 1.0).name('Edge Smoothing').onFinishChange(reprocessImage);
            
            // Particles folder
            const particlesFolder = gui.addFolder('Particles');
            particlesFolder.add(params, 'particlesEnabled').name('Enable Particles').onChange(toggleParticles);
            particlesFolder.add(params, 'particleCount', 1000, 500000, 1000).name('Particle Count').onFinishChange(reprocessImage);
            particlesFolder.add(params, 'particleSize', 1.0, 10.0, 0.1).name('Particle Size').onChange(v => {
                if (particleSystem) particleSystem.material.size = v;
            });
            particlesFolder.add(params, 'particleBrightness', 0.1, 5.0, 0.1).name('Particle Brightness').onFinishChange(reprocessImage);

            gui.add(params, 'uploadImage').name('Upload Custom Image');
        }

        function loadDefaultImage() {
            loadingEl.style.display = 'block';
            const img = new Image();
            img.crossOrigin = 'Anonymous';
            
            img.onload = () => {
                currentImgObj = img;
                processImageIntoLayers(img);
                loadingEl.style.display = 'none';
            };
            
            img.onerror = () => {
                console.error('Failed to load default image. CORS issue?');
                loadingEl.innerText = 'Error loading image';
                
                // Fallback image in case of CORS error from ImageKit/Unsplash
                const canvas = document.createElement('canvas');
                canvas.width = 1024;
                canvas.height = 1024;
                const ctx = canvas.getContext('2d');
                const grad = ctx.createLinearGradient(0, 0, 1024, 1024);
                grad.addColorStop(0, '#0f0c29');
                grad.addColorStop(0.5, '#302b63');
                grad.addColorStop(1, '#24243e');
                ctx.fillStyle = grad;
                ctx.fillRect(0, 0, 1024, 1024);
                for(let i = 0; i < 150; i++) {
                    ctx.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.8})`;
                    ctx.beginPath();
                    ctx.arc(Math.random() * 1024, Math.random() * 1024, Math.random() * 60, 0, Math.PI * 2);
                    ctx.fill();
                }
                img.onerror = null; 
                img.src = canvas.toDataURL(); 
            };
            
            img.src = 'https://images.pexels.com/photos/11443389/pexels-photo-11443389.jpeg';
        }

        function handleFileUpload(e) {
            const file = e.target.files[0];
            if (!file) return;
            
            loadingEl.style.display = 'block';
            
            const reader = new FileReader();
            reader.onload = (event) => {
                const img = new Image();
                img.onload = () => {
                    currentImgObj = img;
                    setTimeout(() => {
                        processImageIntoLayers(img);
                        loadingEl.style.display = 'none';
                    }, 50);
                };
                img.src = event.target.result;
            };
            reader.readAsDataURL(file);
        }

        function reprocessImage() {
            if (currentImgObj) {
                loadingEl.style.display = 'block';
                setTimeout(() => {
                    processImageIntoLayers(currentImgObj);
                    loadingEl.style.display = 'none';
                }, 50);
            }
        }

        function removeParticles() {
            if (particleSystem) {
                scene.remove(particleSystem);
                particleSystem.geometry.dispose();
                particleSystem.material.dispose();
                particleSystem = null;
            }
        }

        function toggleParticles(enabled) {
            if (enabled && currentImgObj) {
                reprocessImage();
            } else {
                removeParticles();
                
                // Show layers again when particles are disabled
                movingMeshes.forEach(mesh => {
                    mesh.visible = true;
                });
            }
        }

        function createParticles(baseData, w, h) {
            removeParticles();

            const particleCount = params.particleCount;
            const geometry = new THREE.BufferGeometry();
            const positions = new Float32Array(particleCount * 3);
            const colors = new Float32Array(particleCount * 4); // Changed to 4 to support RGBA (Alpha channel)
            
            const loopDepth = params.groupDepth * 3;
            const tempColor = new THREE.Color();

            for (let i = 0; i < particleCount; i++) {
                // Pick a random pixel coordinate
                const x = Math.floor(Math.random() * w);
                const y = Math.floor(Math.random() * h);
                const index = (y * w + x) * 4;

                // Extract color from image pixels and convert to linear space to fix washed out look
                tempColor.setRGB(
                    baseData.data[index] / 255,
                    baseData.data[index + 1] / 255,
                    baseData.data[index + 2] / 255
                );
                tempColor.convertSRGBToLinear();
                tempColor.multiplyScalar(params.particleBrightness);

                colors[i * 4] = tempColor.r;
                colors[i * 4 + 1] = tempColor.g;
                colors[i * 4 + 2] = tempColor.b;
                colors[i * 4 + 3] = 0.0; // Initial alpha

                // Map coordinates to 3D space (-0.5 to 0.5 so it scales correctly with updateCoverUVs)
                positions[i * 3] = (x / w) - 0.5;
                positions[i * 3 + 1] = 0.5 - (y / h); // Invert Y
                positions[i * 3 + 2] = Math.random() * -loopDepth; // Random depth
            }

            geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
            geometry.setAttribute('color', new THREE.BufferAttribute(colors, 4)); // Using 4 allows varying opacity per particle

            const material = new THREE.PointsMaterial({
                size: params.particleSize,
                vertexColors: true,
                transparent: true,
                opacity: 1.0, // Global opacity is 1, individual particles controlled via vertex alpha
                blending: THREE.NormalBlending, // Changed from AdditiveBlending to NormalBlending
                depthWrite: false,
                sizeAttenuation: false
            });

            particleSystem = new THREE.Points(geometry, material);
            scene.add(particleSystem);
        }

        // Core logic: Improved Continuous Blending for Artifact-Free Edge Smoothing
        function processImageIntoLayers(img) {
            currentImageAspect = img.width / img.height;
            
            currentTextures.forEach(tex => tex.dispose());
            currentTextures = [];

            const canvas = document.createElement('canvas');
            const maxSize = 1024;
            let w = img.width;
            let h = img.height;
            if (w > maxSize || h > maxSize) {
                const ratio = Math.min(maxSize / w, maxSize / h);
                w = Math.floor(w * ratio);
                h = Math.floor(h * ratio);
            }
            
            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext('2d', { willReadFrequently: true });
            ctx.drawImage(img, 0, 0, w, h);
            
            // Create full base texture for the static background
            if (baseTexture) baseTexture.dispose();
            baseTexture = new THREE.CanvasTexture(canvas);
            baseTexture.colorSpace = THREE.SRGBColorSpace;
            baseTexture.matrixAutoUpdate = false;
            
            const baseData = ctx.getImageData(0, 0, w, h);
            const totalPixels = baseData.data.length;

            // Generate particles from pixel data if enabled
            if (params.particlesEnabled) {
                createParticles(baseData, w, h);
            } else {
                removeParticles();
            }

            const numLayers = params.layers;

            // --- Pre-calculate smooth layer index array to avoid artifacts ---
            const steppedXArray = new Float32Array(256);
            const edgeWidth = params.edgeSmoothing;
            const minEdge = 0.5 - (edgeWidth / 2);
            const maxEdge = 0.5 + (edgeWidth / 2);

            for (let l = 0; l < 256; l++) {
                // Map luma (0-255) to a continuous coordinate space (0 to numLayers - 1)
                const x = (l / 255) * (numLayers - 1);
                const floorX = Math.floor(x);
                const f = x - floorX; // Fractional part
                
                let smoothedF = f;
                if (edgeWidth < 1.0) {
                     if (edgeWidth <= 0.001) {
                         smoothedF = f < 0.5 ? 0.0 : 1.0; // Snap to nearest layer (0 smoothing)
                     } else {
                         // Apply smoothstep within the specified edge width
                         if (f <= minEdge) smoothedF = 0.0;
                         else if (f >= maxEdge) smoothedF = 1.0;
                         else {
                             const t = (f - minEdge) / (maxEdge - minEdge);
                             smoothedF = t * t * (3 - 2 * t);
                         }
                     }
                }
                steppedXArray[l] = floorX + smoothedF;
            }

            for (let i = 0; i < numLayers; i++) {
                const lCanvas = document.createElement('canvas');
                lCanvas.width = w;
                lCanvas.height = h;
                const lCtx = lCanvas.getContext('2d');
                const lData = lCtx.createImageData(w, h); 
                
                for (let j = 0; j < totalPixels; j += 4) {
                    const r = baseData.data[j];
                    const g = baseData.data[j+1];
                    const b = baseData.data[j+2];
                    const a = baseData.data[j+3];
                    
                    const luma = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
                    const clampedLuma = Math.max(0, Math.min(255, luma));
                    
                    // Retrieve precalculated continuous position
                    const steppedX = steppedXArray[clampedLuma];
                    
                    // Calculate perfectly cross-faded alpha for current layer
                    // This mathematically guarantees no hard cutoffs or holes
                    const weight = Math.max(0, 1.0 - Math.abs(steppedX - i));
                    
                    if (weight > 0) {
                        lData.data[j] = r;
                        lData.data[j+1] = g;
                        lData.data[j+2] = b;
                        lData.data[j+3] = a * weight;
                    }
                }
                
                lCtx.putImageData(lData, 0, 0);
                const tex = new THREE.CanvasTexture(lCanvas);
                tex.colorSpace = THREE.SRGBColorSpace;
                tex.matrixAutoUpdate = false;
                
                currentTextures.push(tex);
            }

            startupFade = 0.0; // Reset fade effect on new image load
            buildScene();
        }

        function buildScene() {
            movingMeshes.forEach(mesh => scene.remove(mesh));
            movingMeshes = [];
            if (baseMesh) scene.remove(baseMesh);

            // Base unit plane, we will scale it mathematically in updateCoverUVs
            const geometry = new THREE.PlaneGeometry(1, 1);

            // 1. Create static full background image
            const baseMat = new THREE.MeshBasicMaterial({
                map: baseTexture,
                depthWrite: false,
                transparent: true, // Needed for the startup fade effect
                opacity: 0.0 // Start invisible to prevent initial frame flicker
            });
            baseMesh = new THREE.Mesh(geometry, baseMat);
            // Place it exactly at the furthest spawn point of the loop
            baseMesh.position.z = -params.groupDepth * 3;
            scene.add(baseMesh);

            // 2. Create partial layers (static and moving)
            currentTextures.forEach((tex, i) => {
                const isStatic = i < params.staticDarkLayers;
                // Static layers only need 1 instance. Moving ones need 3 to loop seamlessly.
                const instanceCount = isStatic ? 1 : 3;

                for(let g = 0; g < instanceCount; g++) {
                    const material = new THREE.MeshBasicMaterial({
                        map: tex,
                        transparent: true,
                        side: THREE.DoubleSide,
                        depthWrite: false,
                        opacity: 0.0 // Start invisible to prevent initial frame flicker
                    });
                    
                    const mesh = new THREE.Mesh(geometry, material);
                    
                    if (isStatic) {
                        // Place static layers in the background, slightly ahead of the full base image
                        mesh.position.z = -params.groupDepth * 2.5 + (i * 10);
                        mesh.userData = { isStatic: true };
                    } else {
                        // Reverse Z mapping: brighter layers are placed closer to the camera
                        const depthRatio = 1.0 - (i / currentTextures.length);
                        const localZ = -depthRatio * params.groupDepth;
                        const groupZ = -g * params.groupDepth;
                        mesh.position.z = localZ + groupZ;
                        mesh.userData = { isStatic: false };
                    }
                    
                    // Hide layers if particles are enabled
                    mesh.visible = !params.particlesEnabled;
                    
                    scene.add(mesh);
                    movingMeshes.push(mesh);
                }
            });

            updateCoverUVs();
        }

        function updateCoverUVs() {
            const screenAspect = window.innerWidth / window.innerHeight;
            
            // 1. Calculate exact physical size to fill camera frustum at background depth
            const backgroundDepth = Math.abs(-params.groupDepth * 3);
            const vFOV = camera.fov * Math.PI / 180;
            const visibleHeight = 2 * Math.tan(vFOV / 2) * backgroundDepth;
            const visibleWidth = visibleHeight * screenAspect;
            
            // Apply scale so planes match screen aspect ratio perfectly
            if (baseMesh) baseMesh.scale.set(visibleWidth, visibleHeight, 1);
            movingMeshes.forEach(mesh => mesh.scale.set(visibleWidth, visibleHeight, 1));
            
            // Scale particle bounds
            if (particleSystem) particleSystem.scale.set(visibleWidth, visibleHeight, 1);

            // 2. Adjust UVs for CSS-like cover behavior
            const texturesToUpdate = [...currentTextures];
            if (baseTexture) texturesToUpdate.push(baseTexture);

            texturesToUpdate.forEach(tex => {
                let scaleX = 1;
                let scaleY = 1;

                if (screenAspect > currentImageAspect) {
                    scaleY = currentImageAspect / screenAspect;
                } else {
                    scaleX = screenAspect / currentImageAspect;
                }
                
                tex.matrix.setUvTransform(
                    0.0, 0.0, 
                    scaleX, scaleY, 
                    0, 
                    0.5, 0.5
                );
            });
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
            updateCoverUVs();
        }

        function animate() {
            requestAnimationFrame(animate);

            // Handle global fade-in at startup
            if (startupFade < 1.0) {
                startupFade += 0.01; // Fades in over ~1-1.5 seconds
                if (startupFade > 1.0) startupFade = 1.0;
            }

            if (baseMesh) {
                baseMesh.material.opacity = startupFade * params.baseImageOpacity; // Included Base Image Opacity
            }

            const loopDepth = params.groupDepth * 3;
            const maxVisibleZ = 100; // Point slightly behind camera to wrap around
            
            // Calculate back of the tunnel to fade in newly spawned layers smoothly
            const spawnZ = maxVisibleZ - loopDepth;
            const fadeInDistance = params.groupDepth * 0.8; // Distance over which layers smoothly appear at the back

            movingMeshes.forEach(mesh => {
                if (mesh.userData.isStatic) {
                    // Static dark layers just fade in at start, but do not move forward
                    mesh.material.opacity = startupFade;
                    return; 
                }

                // Move layer towards camera
                mesh.position.z += params.speed;
                
                let targetOpacity = 1.0;
                
                // 1. Fade out logic when getting close to the camera (front of tunnel)
                if (mesh.position.z > params.fadeStartDistance) {
                    const fadeSpan = maxVisibleZ - params.fadeStartDistance;
                    targetOpacity = 1.0 - (mesh.position.z - params.fadeStartDistance) / fadeSpan;
                }

                // 2. Fade in logic when spawning at the very back of the tunnel
                if (mesh.position.z < spawnZ + fadeInDistance) {
                    const spawnOpacity = (mesh.position.z - spawnZ) / fadeInDistance;
                    targetOpacity = Math.min(targetOpacity, spawnOpacity);
                }

                // Combine distance fade logic with the global startup fade
                mesh.material.opacity = Math.max(0, Math.min(1, targetOpacity)) * startupFade;

                // Loop back to the end of the tunnel
                if (mesh.position.z > maxVisibleZ) {
                    mesh.position.z -= loopDepth;
                }
            });

            // Animate Particles
            if (particleSystem && params.particlesEnabled) {
                const positions = particleSystem.geometry.attributes.position.array;
                const colors = particleSystem.geometry.attributes.color.array; // Access color/alpha buffer
                const particleCount = params.particleCount;
                const fadeSpan = maxVisibleZ - params.fadeStartDistance;

                for (let i = 0; i < particleCount; i++) {
                    let z = positions[i * 3 + 2];
                    z += params.speed;

                    // Loop particles
                    if (z > maxVisibleZ) {
                        z -= loopDepth;
                    }
                    positions[i * 3 + 2] = z;
                    
                    // Individual particle opacity calculation based on Z distance
                    let targetOpacity = 1.0;
                    
                    // Front fade out
                    if (z > params.fadeStartDistance) {
                        targetOpacity = 1.0 - (z - params.fadeStartDistance) / fadeSpan;
                    }
                    
                    // Back fade in
                    if (z < spawnZ + fadeInDistance) {
                        const spawnOpacity = (z - spawnZ) / fadeInDistance;
                        targetOpacity = Math.min(targetOpacity, spawnOpacity);
                    }

                    // Apply transparency directly to the particle's alpha channel
                    colors[i * 4 + 3] = Math.max(0, Math.min(1, targetOpacity)) * startupFade;
                }
                particleSystem.geometry.attributes.position.needsUpdate = true;
                particleSystem.geometry.attributes.color.needsUpdate = true; // Tell GPU to update alphas
            }

            composer.render();
        }