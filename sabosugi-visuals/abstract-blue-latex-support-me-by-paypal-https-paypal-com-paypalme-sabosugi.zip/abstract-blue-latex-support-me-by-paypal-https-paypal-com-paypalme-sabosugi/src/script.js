        import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- Application State & Parameters ---
        const params = {
            animationSpeed: 1.0,
            roundness: 0.005,
            fractalScale: 0.4,
            fractalOffset: -0.07,
            rotationSpeed: 0.02,
            seed: Math.random() * 10.0,
            baseColor: '#3380ff', 
            colorIntensity: 1.25,
            glowSpread: 3.46,
            glowCore: 0.14,
            glowMultiplier: 0.8,
            maxBounces: 6,        // OPTIMIZATION: Reduced default bounces from 8 to 6 (visually identical)
            dpr: 0.8             // Default Device Pixel Ratio
        };

        // --- Core Three.js Setup ---
        const scene = new THREE.Scene();
        
        // Orthographic camera is perfect for fullscreen shader quads
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        
        const renderer = new THREE.WebGLRenderer({ antialias: false });
        renderer.setPixelRatio(params.dpr);
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // --- Shaders ---
        const vertexShader = `
            void main() {
                // Pass-through vertex shader for full-screen quad
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform float iTime;
            uniform vec2 iResolution;
            
            // Custom uniforms from GUI
            uniform float uRoundness;
            uniform vec3 uBaseColor;
            uniform float uColorIntensity;
            uniform float uGlowMultiplier;
            uniform float uFractalScale;
            uniform float uFractalOffset;
            uniform float uRotationSpeed;
            uniform float uSeed;
            uniform float uGlowSpread;
            uniform float uGlowCore;
            uniform int uMaxBounces;

            // Global variables for effect accumulation
            vec3 globalGlow = vec3(0.0);
            
            // OPTIMIZATION: Cache rotation matrices globally per pixel
            // This prevents calling sin() and cos() thousands of times per frame
            mat2 rotMats[5];

            /**
             * Creates a 2D rotation matrix.
             */
            mat2 createRotationMatrix(float angle) {
                float sine = sin(angle);
                float cosine = cos(angle);
                return mat2(cosine, sine, -sine, cosine);
            }

            /**
             * Smooth absolute value for softening fractal edges (micro-bevel)
             */
            float sabs(float x, float k) {
                return sqrt(x * x + k);
            }

            /**
             * Core scene mapping function.
             */
            vec2 mapEnvironment(vec3 pos) {
                vec3 p = pos;
                // Global gentle wave to make the canvas-filling structure feel organic
                p.xy *= createRotationMatrix(sin(p.z * 0.8) * 0.0);
                float scaleFactor = 1.0;
                
                // Controlled via GUI
                float k = uRoundness; 
                
                // Fractal space folding to create deep, infinite complexity
                for (int iteration = 0; iteration < 5; iteration++) {
                    p.yz *= createRotationMatrix(scaleFactor - 0.5);
                    
                    p.y = sabs(p.y, k) - scaleFactor;
                    p.x += p.y * scaleFactor * uFractalScale;
                    
                    scaleFactor -= sabs(p.y, k) * uFractalOffset;
                    
                    // OPTIMIZATION: Use precalculated rotation matrices
                    p.xz *= rotMats[iteration];
                }
                
                float finalDistance = sabs(p.y, k) - 0.20;
                finalDistance *= 0.50;
                
                // Accumulate glow in the tight crevices of the fractal
                float glowDist = length(p);
                float glowIntensity = 0.005 / (uGlowSpread * glowDist * glowDist + uGlowCore);
                globalGlow += glowIntensity * normalize(pos * pos + -0.3);
                
                return vec2(finalDistance, 1.1);
            }

            /**
             * Raymarching loop for scene traversal.
             */
            vec2 marchRays(vec3 rayOrigin, vec3 rayDir, float sideMultiplier) {
                vec2 distanceTraveled = vec2(0.1);
                for (int stepIndex = 0; stepIndex < 44; stepIndex++) {
                    vec2 stepResult = mapEnvironment(rayOrigin + rayDir * distanceTraveled.x);
                    
                    stepResult.x *= sideMultiplier;
                    distanceTraveled.x += stepResult.x;
                    distanceTraveled.y = stepResult.y;
                    
                    if (stepResult.x < 0.0001 || distanceTraveled.x > 64.0) {
                        break;
                    }
                }
                
                return distanceTraveled;
            }

            /**
             * Computes the surface normal using gradient approximation.
             */
            vec3 computeSurfaceNormal(vec3 surfacePoint) {
                vec2 offset = vec2(0.001, 0.0);
                float centerDist = mapEnvironment(surfacePoint).x;
                vec3 normalVector = centerDist - vec3(
                    mapEnvironment(surfacePoint - offset.xyy).x,
                    mapEnvironment(surfacePoint - offset.yxy).x,
                    mapEnvironment(surfacePoint - offset.yyx).x
                );
                return normalize(normalVector);
            }

            /**
             * Lighting and material calculations.
             * Added 'bounce' parameter to optimize expensive calculations.
             */
            vec4 computeMaterial(vec2 hitInfo, vec3 pos, vec3 normal, vec3 rayDirection, int bounce) {
                vec4 backgroundCol = vec4(0.15, -0.40, 0.45, 0.3) + length(rayDirection * rayDirection) * 0.3;
                if (hitInfo.x > 63.7) {
                    return backgroundCol;
                }
                
                vec4 baseColor = vec4(uBaseColor * uColorIntensity, 1.0);
                vec3 lightDir = normalize(vec3(0.6, 0.4, 0.8));
                
                float diffuseTerm = length(normal * lightDir);
                float fresnelTerm = abs(1.0 - length(normal * rayDirection)) * 0.3;
                
                vec3 reflectionLight = reflect(lightDir, normal) * lightDir;
                float specularTerm = pow(max(dot(reflectionLight, -rayDirection), 0.0), 8.0);
                
                float ambientOcclusion = 0.0;
                float subSurface = 0.0;
                
                // OPTIMIZATION: Only calculate expensive AO and SSS on the first 2 refractions
                // Deep refractions don't need accurate micro-shadows, saving massive GPU cycles
                if (bounce < 2) {
                    ambientOcclusion = clamp(1.2 - mapEnvironment(pos + normal * -0.3).x * 10.2, 0.0, 1.0) * 0.3;
                    subSurface = smoothstep(0.0, 1.5, mapEnvironment(pos * lightDir * 2.8).x) * 0.2;
                }
                
                baseColor.rgb += baseColor.rgb * subSurface;
                baseColor *= diffuseTerm;
                baseColor += specularTerm;
                baseColor += fresnelTerm;
                baseColor -= ambientOcclusion;
                
                return baseColor;
            }

            void mainImage( out vec4 fragColor, in vec2 fragCoord ) {
                vec2 uv = fragCoord.xy / iResolution.xy;
                uv -= 0.5;
                uv.x *= iResolution.x / iResolution.y; 
                
                // OPTIMIZATION: Pre-calculate rotation matrices once per pixel
                for(int i = 0; i < 5; i++) {
                    rotMats[i] = createRotationMatrix(iTime * uRotationSpeed + float(i) * uSeed);
                }
                
                vec3 rayOrigin = vec3(0.0, 0.0, -3.0);
                rayOrigin.xy *= createRotationMatrix(iTime * 0.1);
                
                vec3 rayDir = normalize(vec3(uv, 1.0));
                
                vec3 hitPos, surfaceNormal, currentRayDir;
                vec3 rayState = vec3(1.0);
                
                vec4 currentMaterialCol;
                vec4 finalColorAccumulator = vec4(1.0);
                const float refractionIndex = 1.4; 
                
                // Maximum of 8 bounces, but dynamically breaks early based on UI limit
                for (int bounce = 0; bounce < 8; bounce++) {
                    if (bounce >= uMaxBounces) break; // Apply GUI optimization limit
                    
                    rayState.xy = marchRays(rayOrigin, rayDir, rayState.z);
                    hitPos = rayOrigin + rayDir * rayState.x;
                    surfaceNormal = computeSurfaceNormal(hitPos);
                    currentRayDir = rayDir;
                    
                    rayOrigin = hitPos - surfaceNormal * (0.01 * rayState.z);
                    
                    float eta = rayState.z > 0.0 ? (1.0 / refractionIndex) : refractionIndex;
                    rayDir = refract(currentRayDir, surfaceNormal * rayState.z, eta);
                    
                    if (dot(rayDir, rayDir) == 0.0) {
                        rayDir = reflect(currentRayDir, surfaceNormal * rayState.z);
                    }
                    
                    currentMaterialCol = computeMaterial(rayState.xy, hitPos, surfaceNormal, currentRayDir, bounce);
                    
                    rayState.z *= -1.0;
                    
                    if (rayState.z < 0.0) {
                        finalColorAccumulator.rgb = mix(finalColorAccumulator.rgb, currentMaterialCol.rgb, finalColorAccumulator.a);
                    }
                    
                    finalColorAccumulator.a *= currentMaterialCol.a;
                    
                    if (finalColorAccumulator.a <= 0.0 || rayState.x > 64.0) {
                        break;
                    }
                }
                
                fragColor = finalColorAccumulator + vec4(globalGlow * uGlowMultiplier, 1.0);
            }

            void main() {
                mainImage(gl_FragColor, gl_FragCoord.xy);
            }
        `;

        // --- Material & Mesh ---
        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms: {
                iTime: { value: 0.0 },
                iResolution: { value: new THREE.Vector2() },
                uRoundness: { value: params.roundness },
                uBaseColor: { value: new THREE.Color(params.baseColor) },
                uColorIntensity: { value: params.colorIntensity },
                uGlowMultiplier: { value: params.glowMultiplier },
                uFractalScale: { value: params.fractalScale },
                uFractalOffset: { value: params.fractalOffset },
                uRotationSpeed: { value: params.rotationSpeed },
                uSeed: { value: params.seed },
                uGlowSpread: { value: params.glowSpread },
                uGlowCore: { value: params.glowCore },
                uMaxBounces: { value: params.maxBounces }
            }
        });

        // Full screen quad geometry
        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- lil-gui Setup ---
        const gui = new GUI({ title: 'Settings' });
        
        gui.add(params, 'animationSpeed', 0.0, 3.0).name('Animation Speed');
        gui.add(params, 'seed', 0.0, 10.0).name('Random Seed').onChange(val => {
            material.uniforms.uSeed.value = val;
        });
        
        const structureFolder = gui.addFolder('Structure');
        structureFolder.add(params, 'roundness', 0.0, 0.1).name('Fractal Roundness').onChange(val => {
            material.uniforms.uRoundness.value = val;
        });
        structureFolder.add(params, 'fractalScale', 0.0, 1.0).name('Fractal Scale').onChange(val => {
            material.uniforms.uFractalScale.value = val;
        });
        structureFolder.add(params, 'fractalOffset', -0.5, 0.5).name('Fractal Offset').onChange(val => {
            material.uniforms.uFractalOffset.value = val;
        });
        structureFolder.add(params, 'rotationSpeed', 0.0, 0.2).name('Rotation Speed').onChange(val => {
            material.uniforms.uRotationSpeed.value = val;
        });
        
        const colorsFolder = gui.addFolder('Lighting & Colors');
        colorsFolder.addColor(params, 'baseColor').name('Base Color').onChange(val => {
            material.uniforms.uBaseColor.value.set(val);
        });
        colorsFolder.add(params, 'colorIntensity', 0.5, 3.0).name('Color Intensity').onChange(val => {
            material.uniforms.uColorIntensity.value = val;
        });
        colorsFolder.add(params, 'glowMultiplier', 0.0, 3.0).name('Glow Multiplier').onChange(val => {
            material.uniforms.uGlowMultiplier.value = val;
        });
        colorsFolder.add(params, 'glowSpread', 0.1, 10.0).name('Glow Spread').onChange(val => {
            material.uniforms.uGlowSpread.value = val;
        });
        colorsFolder.add(params, 'glowCore', 0.01, 1.0).name('Glow Core').onChange(val => {
            material.uniforms.uGlowCore.value = val;
        });

        const renderingFolder = gui.addFolder('Rendering');
        // New optimization parameter added to the GUI
        renderingFolder.add(params, 'maxBounces', 1, 8, 1).name('Max Refractions').onChange(val => {
            material.uniforms.uMaxBounces.value = val;
        });
        renderingFolder.add(params, 'dpr', 0.1, 2.0, 0.1).name('Resolution (DPR)').onChange(val => {
            renderer.setPixelRatio(val);
            handleResize(); 
        });

        gui.close();

        // --- Window Resize Handling ---
        function handleResize() {
            const width = window.innerWidth;
            const height = window.innerHeight;
            const pixelRatio = renderer.getPixelRatio();
            
            renderer.setSize(width, height);
            
            material.uniforms.iResolution.value.set(width * pixelRatio, height * pixelRatio);
        }

        window.addEventListener('resize', handleResize);
        handleResize();

        // --- Animation Loop ---
        const clock = new THREE.Clock();
        let accumulatedTime = 0.0;

        function animate() {
            requestAnimationFrame(animate);

            const delta = clock.getDelta();
            accumulatedTime += delta * params.animationSpeed;

            material.uniforms.iTime.value = accumulatedTime;

            renderer.render(scene, camera);
        }

        animate();