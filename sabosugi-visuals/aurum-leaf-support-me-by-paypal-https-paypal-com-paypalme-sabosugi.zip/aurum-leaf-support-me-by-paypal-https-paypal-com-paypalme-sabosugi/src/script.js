       import * as THREE from 'three';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
        import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import GUI from 'lil-gui';

        // --- Configuration Object for GUI ---
        const config = {
            // Writhing Dynamics (Octopus tentacles)
            waveSpeed: 1.4, 
            curlFrequency: 0.2625,
            writhingAmplitude: 1.4,
            
            // Geometry & Layout Additions
            offsetX: 0.24, // Shifts entire capsule to the right
            offsetY: 0.0, // Changed to 0.0 to perfectly center the capsule vertically
            groupSpacing: 4.0, // Distance between tentacle roots
            taperSharpness: 4.248, // Controls pinch expansion at the bottom
            
            // Capsule Constraints
            capsuleRadius: 5.418, 
            capsuleLength: 10.0,
            capsuleOpacity: 0.0415, 
            autoRotate: false, // Added slow auto-rotation
            
            // Structure
            tentacleCount: 8,
            coreLinesPerTentacle: 5, 
            glowLinesPerTentacle: 45, 
            spread: 0.6223, 
            
            // Particles
            particleCount: 3100,
            particleSize: 0.04802,
            particleSpeed: 0.002, 
            particleGlobalSpeed: 0.735, 
            particleOrbitRadius: 0.33, 
            
            // Appearance
            coreColor: '#ffd500', // Updated to yellow from screenshot
            glowColor: '#ffbf52', // Updated to golden/orange from screenshot
            dpr: 1.0, 
            
            // Blur / Bloom
            blurStrength: 0.264, 
            blurRadius: 0.516, 
            blurThreshold: 0.2 
        };

        // --- Scene Setup ---
        const scene = new THREE.Scene();

        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100);
        camera.position.set(0, 0, 25); // Pulled back slightly to see the full capsule

        const renderer = new THREE.WebGLRenderer({ antialias: true }); // Enabled antialiasing
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(config.dpr); // Use config.dpr instead of window.devicePixelRatio
        document.body.appendChild(renderer.domElement);

        // --- Camera Controls ---
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true; // Adds smooth deceleration
        controls.dampingFactor = 0.05;
        controls.autoRotate = config.autoRotate; // Enable auto rotation
        controls.autoRotateSpeed = 0.8; // Slow horizontal rotation speed

        // Change cursor to grabbing during interaction
        controls.addEventListener('start', () => {
            renderer.domElement.style.cursor = 'grabbing';
        });
        
        controls.addEventListener('end', () => {
            renderer.domElement.style.cursor = 'grab';
        });

        // --- Lights for the Glass Capsule ---
        // We only use ambient light now. Directional lights are removed to get rid of the artificial bright dots on the clearcoat glass.
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.8); // Slightly increased to compensate for removed lights
        scene.add(ambientLight);

        // --- Post-Processing (Bloom & Anti-Aliasing) ---
        // Create a custom render target with MSAA (Multi-Sample Anti-Aliasing) enabled
        const renderTarget = new THREE.WebGLRenderTarget(
            window.innerWidth, 
            window.innerHeight, 
            {
                type: THREE.HalfFloatType,
                samples: 8 // 8x MSAA for perfectly smooth lines
            }
        );

        const renderScene = new RenderPass(scene, camera);
        
        const bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            config.blurStrength,
            config.blurRadius,
            config.blurThreshold
        );

        const outputPass = new OutputPass();

        const composer = new EffectComposer(renderer, renderTarget);
        composer.addPass(renderScene);
        composer.addPass(bloomPass);
        composer.addPass(outputPass);

        // --- Master Group (Holds Capsule + Energy) ---
        const masterGroup = new THREE.Group();
        scene.add(masterGroup);

        // --- Cube Camera for Internal Reflections ---
        // This captures the scene from the center to create real-time reflections on the glass
        const cubeRenderTarget = new THREE.WebGLCubeRenderTarget(2048, { 
            generateMipmaps: true,
            minFilter: THREE.LinearMipmapLinearFilter,
            magFilter: THREE.LinearFilter,
            type: THREE.HalfFloatType 
        });
        const cubeCamera = new THREE.CubeCamera(0.1, 100, cubeRenderTarget);
        masterGroup.add(cubeCamera);

        // --- Materials ---
        const coreLineMaterial = new THREE.LineBasicMaterial({
            color: new THREE.Color(config.coreColor),
            transparent: true,
            opacity: 0.4, 
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });

        const glowLineMaterial = new THREE.LineBasicMaterial({
            color: new THREE.Color(config.glowColor),
            transparent: true,
            opacity: 0.05,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });

        const particleMaterial = new THREE.PointsMaterial({
            color: new THREE.Color(config.coreColor),
            size: config.particleSize,
            transparent: true,
            opacity: 0.9,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });

        // --- Create Capsule ---
        let capsuleMesh;
        function createCapsule() {
            if (capsuleMesh) {
                capsuleMesh.geometry.dispose();
                capsuleMesh.material.dispose();
                masterGroup.remove(capsuleMesh);
            }
            
            const geometry = new THREE.CapsuleGeometry(config.capsuleRadius, config.capsuleLength, 16, 32);
            // Upgraded to Physical Material for realistic glass and internal reflections
            const material = new THREE.MeshPhysicalMaterial({
                color: new THREE.Color(config.glowColor),
                transparent: true,
                opacity: config.capsuleOpacity,
                roughness: 0.15, 
                metalness: 1.0, 
                clearcoat: 1.0, 
                clearcoatRoughness: 0.15,
                specularIntensity: 0.0, // Disable specular highlights from scene lights
                envMap: cubeRenderTarget.texture, 
                envMapIntensity: 2.0, 
                blending: THREE.AdditiveBlending,
                depthWrite: false, 
                side: THREE.DoubleSide 
            });
            
            capsuleMesh = new THREE.Mesh(geometry, material);
            masterGroup.add(capsuleMesh);
            
            // Re-generate inner elements to fit new dimensions
            createTentacles();
            createParticles();
        }

        // --- Create Tentacles ---
        const linesGroup = new THREE.Group();
        masterGroup.add(linesGroup);
        const linesData = [];
        const tentaclesBaseData = []; 
        const pointsPerLine = 150;

        function createTentacles() {
            while(linesGroup.children.length > 0) {
                const child = linesGroup.children[0];
                child.geometry.dispose();
                linesGroup.remove(child);
            }
            linesData.length = 0;
            tentaclesBaseData.length = 0;

            for (let r = 0; r < config.tentacleCount; r++) {
                // Base structure now defined on X and Z (horizontal plane), flowing along Y (vertical)
                const baseX = (Math.random() - 0.5) * config.groupSpacing;
                const baseZ = (Math.random() - 0.5) * config.groupSpacing;
                
                const phaseX = Math.random() * Math.PI * 2;
                const phaseY = Math.random() * Math.PI * 2;
                const phaseZ = Math.random() * Math.PI * 2;
                
                tentaclesBaseData.push({ baseX, baseZ, phaseX, phaseY, phaseZ });

                // Core Bundle
                for (let c = 0; c < config.coreLinesPerTentacle; c++) {
                    createStrand(r, 0.2, coreLineMaterial);
                }

                // Outer Glow Bundle
                for (let l = 0; l < config.glowLinesPerTentacle; l++) {
                    createStrand(r, config.spread, glowLineMaterial);
                }
            }
        }

        function createStrand(tentacleIndex, spread, material) {
            const geometry = new THREE.BufferGeometry();
            const positions = new Float32Array(pointsPerLine * 3);
            geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
            
            const line = new THREE.Line(geometry, material);
            linesGroup.add(line);

            linesData.push({
                line: line,
                tentacleIndex: tentacleIndex,
                localOffsetX: (Math.random() - 0.5) * spread,
                localOffsetZ: (Math.random() - 0.5) * spread,
                microPhase: Math.random() * 0.5 
            });
        }

        // --- Create Particles ---
        let particles;
        const particlesData = [];

        function createParticles() {
            if (particles) {
                particles.geometry.dispose();
                masterGroup.remove(particles);
            }
            particlesData.length = 0;

            const geometry = new THREE.BufferGeometry();
            const positions = new Float32Array(config.particleCount * 3);

            for (let i = 0; i < config.particleCount; i++) {
                particlesData.push({
                    tentacleIndex: Math.floor(Math.random() * config.tentacleCount),
                    t: Math.random(), 
                    speed: (Math.random() * 0.8 + 0.2) * config.particleSpeed, 
                    angle: Math.random() * Math.PI * 2, 
                    radiusBase: Math.random(), 
                    orbitSpeed: (Math.random() - 0.5) * 2.0
                });
            }

            geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
            particles = new THREE.Points(geometry, particleMaterial);
            masterGroup.add(particles);
        }

        // --- Initialize Scene Objects ---
        createCapsule();

        // --- GUI Setup ---
        const gui = new GUI({ title: 'Scene Settings' });
        gui.close(); // Collapse the GUI by default
        
        const dynamicsFolder = gui.addFolder('Tentacle Dynamics');
        dynamicsFolder.add(config, 'waveSpeed', 0, 3).name('Writhing Speed');
        dynamicsFolder.add(config, 'curlFrequency', 0.05, 0.4).name('Curl Frequency');
        dynamicsFolder.add(config, 'writhingAmplitude', 0, 10).name('Amplitude');
        
        const capFolder = gui.addFolder('Capsule Settings');
        capFolder.add(config, 'capsuleRadius', 1.0, 10.0).name('Radius').onChange(createCapsule);
        capFolder.add(config, 'capsuleLength', 5.0, 30.0).name('Length').onChange(createCapsule);
        capFolder.add(config, 'capsuleOpacity', 0.0, 0.5).name('Glass Opacity').onChange(v => {
            if(capsuleMesh) capsuleMesh.material.opacity = v;
        });
        capFolder.add(config, 'autoRotate').name('Auto Rotate').onChange(v => controls.autoRotate = v);

        const geoFolder = gui.addFolder('Geometry & Layout');
        geoFolder.add(config, 'offsetX', -15, 15).name('Shift X (Right)');
        geoFolder.add(config, 'offsetY', -15, 15).name('Shift Y (Up/Down)');
        geoFolder.add(config, 'groupSpacing', 0, 15).name('Group Spacing').onChange(createTentacles);
        geoFolder.add(config, 'taperSharpness', 1, 10).name('Pinch Sharpness');

        const structFolder = gui.addFolder('Structure');
        structFolder.add(config, 'spread', 0.1, 5.0).name('Line Spread').onChange(createTentacles);
        
        const blurFolder = gui.addFolder('Core Blur (Bloom)');
        blurFolder.add(config, 'blurStrength', 0, 3).onChange(v => bloomPass.strength = v);
        blurFolder.add(config, 'blurRadius', 0, 2).onChange(v => bloomPass.radius = v);
        
        const lookFolder = gui.addFolder('Appearance');
        lookFolder.addColor(config, 'coreColor').onChange(v => {
            coreLineMaterial.color.set(v);
            particleMaterial.color.set(v);
        });
        lookFolder.addColor(config, 'glowColor').onChange(v => {
            glowLineMaterial.color.set(v);
            if(capsuleMesh) capsuleMesh.material.color.set(v);
        });
        lookFolder.add(config, 'dpr', 0.1, 3.0, 0.1).name('DPR (Resolution)').onChange(v => {
            renderer.setPixelRatio(v);
            composer.setSize(window.innerWidth, window.innerHeight); // Updates composer targets to new resolution
        });

        const particleFolder = gui.addFolder('Particle Dynamics');
        particleFolder.add(config, 'particleCount', 100, 5000, 100).name('Count').onChange(createParticles);
        particleFolder.add(config, 'particleSize', 0.01, 0.5).name('Size').onChange(v => particleMaterial.size = v);
        particleFolder.add(config, 'particleGlobalSpeed', 0.0, 5.0).name('Global Speed');
        particleFolder.add(config, 'particleOrbitRadius', 0.0, 5.0).name('Orbit Spread');

        // --- Helper function to calculate tentacle center ---
        function getTentaclePosition(tentacleIndex, t, time, microPhase = 0) {
            const base = tentaclesBaseData[tentacleIndex];
            
            // Define limits based on capsule dimensions
            const totalHeight = config.capsuleLength + config.capsuleRadius * 2;
            const startY = -totalHeight / 2 + 0.5; // Leave small padding so it doesn't clip the cap
            const endY = totalHeight / 2 - 0.5;
            const lineLength = endY - startY;

            // Flow moves along Y axis now
            const y = startY + t * lineLength; 
            
            const activePhase = microPhase * Math.min(t * 5.0, 1.0);
            const timePhase = (time + activePhase) * config.waveSpeed;
            
            const curl = y * config.curlFrequency;
            
            // Confine amplitude to a capsule shape: taper to 0 at the extreme top and bottom ends
            const yEnvelope = Math.sin(t * Math.PI); 

            // Complex X and Z movement (writhing)
            const xOffset = Math.sin(curl + timePhase + base.phaseX) * config.writhingAmplitude + 
                            Math.sin(curl * 0.5 - timePhase * 0.7 + base.phaseY) * (config.writhingAmplitude * 0.5);
                            
            const zOffset = Math.cos(curl * 0.8 + timePhase * 1.1 + base.phaseZ) * config.writhingAmplitude +
                            Math.cos(curl * 0.4 - timePhase * 0.5 + base.phaseX) * (config.writhingAmplitude * 0.5);

            return {
                x: (base.baseX + xOffset) * yEnvelope,
                y: y,
                z: (base.baseZ + zOffset) * yEnvelope
            };
        }

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            const time = clock.getElapsedTime();

            // Update controls for smooth damping & auto-rotation
            controls.update(); 

            // Apply global offsets to the entire container
            masterGroup.position.set(config.offsetX, config.offsetY, 0);

            // 1. Update Lines 
            linesData.forEach(data => {
                const positions = data.line.geometry.attributes.position.array;
                
                for (let i = 0; i < pointsPerLine; i++) {
                    const t = i / (pointsPerLine - 1); 
                    
                    const centerPos = getTentaclePosition(data.tentacleIndex, t, time, data.microPhase);

                    // Smooth pinch at the root (t=0) AND the tip (t=1)
                    const bottomTaper = Math.min(Math.pow(t * config.taperSharpness, 2.0), 1.0);
                    const topTaper = Math.min(Math.pow((1.0 - t) * config.taperSharpness, 2.0), 1.0);
                    const groupTaper = bottomTaper * topTaper;

                    // Apply horizontal local offsets (X and Z) around the vertical Y flow
                    positions[i * 3] = centerPos.x + data.localOffsetX * groupTaper;
                    positions[i * 3 + 1] = centerPos.y; 
                    positions[i * 3 + 2] = centerPos.z + data.localOffsetZ * groupTaper;
                }
                
                data.line.geometry.attributes.position.needsUpdate = true;
            });

            // 2. Update Particles 
            if (particles && tentaclesBaseData.length > 0) {
                const pPositions = particles.geometry.attributes.position.array;
                
                for (let i = 0; i < config.particleCount; i++) {
                    const pData = particlesData[i];
                    
                    // Particles flow downwards towards the root (t=0) to match previous request
                    pData.t -= pData.speed * config.particleGlobalSpeed;
                    
                    if (pData.t < 0.0) {
                        pData.t = 1.0;
                        pData.tentacleIndex = Math.floor(Math.random() * config.tentacleCount);
                    }

                    const centerPos = getTentaclePosition(pData.tentacleIndex, pData.t, time, 0);

                    pData.angle += pData.orbitSpeed * 0.02;
                    
                    const bottomTaper = Math.min(Math.pow(pData.t * config.taperSharpness, 2.0), 1.0); 
                    const topTaper = Math.min(Math.pow((1.0 - pData.t) * config.taperSharpness, 2.0), 1.0);
                    const groupTaper = bottomTaper * topTaper;
                    
                    // Dynamic orbit radius based on the capsule's curved envelope shape
                    const yEnvelope = Math.sin(pData.t * Math.PI);
                    const currentRadius = pData.radiusBase * config.particleOrbitRadius * yEnvelope * groupTaper;

                    pPositions[i * 3] = centerPos.x + Math.sin(pData.angle) * currentRadius;
                    pPositions[i * 3 + 1] = centerPos.y;
                    pPositions[i * 3 + 2] = centerPos.z + Math.cos(pData.angle) * currentRadius;
                }
                
                particles.geometry.attributes.position.needsUpdate = true;
            }

            // 3. Update Real-Time Reflections
            if (capsuleMesh) {
                capsuleMesh.visible = false; // Hide glass temporarily so it doesn't reflect itself
                cubeCamera.update(renderer, scene);
                capsuleMesh.visible = true; // Show glass again
            }

            composer.render();
        }

        animate();

        // --- Resize Handler ---
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        });