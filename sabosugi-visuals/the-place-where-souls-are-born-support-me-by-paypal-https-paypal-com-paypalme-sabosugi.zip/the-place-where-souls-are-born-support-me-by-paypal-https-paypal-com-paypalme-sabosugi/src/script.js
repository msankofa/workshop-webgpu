        import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
        import GUI from 'https://unpkg.com/lil-gui@0.19.1/dist/lil-gui.esm.min.js';

        // --- Configuration & Parameters ---
        // We use arrays for colors to prevent Three.js from applying unwanted sRGB -> Linear conversions
        // This preserves the exact float values you tuned in the shader
        const params = {
            dpr: 0.7, // Device Pixel Ratio
            speed: 1.0, // Animation speed
            
            // Exact color values from the original shader
            fractalColor: [0.239, 0.404, 0.561], 
            bgColor: [0.000, 0.000, 0.000],
            
            holographicStrength: 1.8,
            noiseIntensity: 0.01,

            // Core Fractal Parameters
            seed: Math.random() * 100.0, // Random seed generated on load
            distortion: 0.28,
            foldOffset: 0.60,
            scaleMult: 0.81
        };

        // --- Scene Setup ---
        const container = document.body;
        const renderer = new THREE.WebGLRenderer({ antialias: false });
        container.appendChild(renderer.domElement);

        // Orthographic camera is perfect for full-screen shaders
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        const scene = new THREE.Scene();

        // --- Shader Material Setup ---
        const uniforms = {
            u_time: { value: 0.0 },
            u_speed: { value: params.speed },
            u_resolution: { value: new THREE.Vector2() },
            
            // Passing raw vectors instead of THREE.Color to preserve exact math
            u_fractalColor: { value: new THREE.Vector3(...params.fractalColor) },
            u_bgColor: { value: new THREE.Vector3(...params.bgColor) },
            
            u_holographicStrength: { value: params.holographicStrength },
            u_noiseIntensity: { value: params.noiseIntensity },
            
            // Dynamic Fractal settings
            u_seed: { value: params.seed },
            u_distortion: { value: params.distortion },
            u_foldOffset: { value: params.foldOffset },
            u_scaleMult: { value: params.scaleMult }
        };

        const vertexShader = `
            void main() {
                // Simple pass-through for full-screen quad
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            #ifdef GL_ES
            precision highp float;
            #endif

            // Uniforms passed from Three.js
            uniform float u_time;
            uniform float u_speed;
            uniform vec2 u_resolution;
            uniform vec3 u_fractalColor;
            uniform vec3 u_bgColor;
            uniform float u_holographicStrength;
            uniform float u_noiseIntensity;
            
            uniform float u_seed;
            uniform float u_distortion;
            uniform float u_foldOffset;
            uniform float u_scaleMult;

            // Rotation matrix
            mat2 rot(float a) {
                float s = sin(a), c = cos(a);
                return mat2(c, -s, s, c);
            }

            // Hash function for cinematic noise
            float hash12(vec2 p) {
                vec3 p3  = fract(vec3(p.xyx) * 0.1031);
                p3 += dot(p3, p3.yzx + 33.33);
                return fract((p3.x + p3.y) * p3.z);
            }

            // Distance estimator / Scene mapping
            float map(vec3 p) {
                float t = (u_time * u_speed) * 0.015;

                // Initial rotation for dynamic view + seed variation
                p.xy *= rot(t * 0.3 + u_seed * 0.7);
                p.xz *= rot(t * 0.3 + u_seed * 1.1);

                float d = -0.18;
                float scale = 0.7;

                for (int i = 0; i < 5; i++) {
                    // Smooth chaotic distortion using sine waves + seed phase offset
                    p += u_distortion * sin(p.zxy * 3.1 + t + u_seed * 0.5 + float(i) * 0.2);

                    // Fold and scale 
                    p = abs(p) / dot(p, p) - u_foldOffset;

                    float len = length(p);
                    
                    // Accumulate density with softer edges
                    d += exp(-1.5 * abs(len - 0.8)) * scale;

                    scale *= u_scaleMult;
                }

                return d;
            }

            // Raymarching and volumetric accumulation
            vec3 render(vec3 ro, vec3 rd) {
                float t = 0.6;
                
                // Initialize with background color
                vec3 col = u_bgColor;

                for (int i = -8; i < 104; i++) {
                    vec3 pos = ro + rd * t;
                    float d = map(pos);

                    // Distance falloff for depth
                    float atten = exp(0.287 * t * t);

                    // 1. Core fractal color accumulation
                    vec3 stepColor = u_fractalColor * d;

                    // 2. Holographic aura on the edges
                    float edgeGlow = smoothstep(0.0, 0.4, d) * smoothstep(1.2, 0.1, d);
                    
                    // Generate holographic color shifting
                    vec3 holoColor = 0.5 + 0.5 * cos(vec3(0.0, 1.5, 2.5) + pos.z * 2.0 - (u_time * u_speed) * 0.8);
                    
                    // Additive blending for the glowing edges
                    stepColor += holoColor * edgeGlow * 2.0 * u_holographicStrength;

                    // Accumulate total volumetric color
                    col += stepColor * 0.008 * atten;

                    // Variable step size based on density
                    t += -0.01 + d * 0.02;
                }

                // Tonemapping to prevent white clipping
                col = 1.0 - exp(-col * 1.5);

                return col;
            }

            void main() {
                // Map fragCoord to uv coordinates using uniform resolution
                vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;

                vec3 ro = vec3(0.0, 0.0, -1.8);
                vec3 rd = normalize(vec3(uv, 1.0));

                // Camera movement
                float t = (u_time * u_speed) * 0.2;
                ro.xz *= rot(t);
                rd.xz *= rot(t);
                ro.xy *= rot(t * 0.4);
                rd.xy *= rot(t * 0.4);

                // Get scene color
                vec3 col = render(ro, rd);

                // Subtle vignette for better composition
                col *= 1.0 - 0.3 * length(uv);

                // Apply cinematic noise (dithering)
                float noise = hash12(gl_FragCoord.xy + fract(u_time * u_speed) * 100.0);
                col += (noise - 0.5) * u_noiseIntensity;

                gl_FragColor = vec4(col, 1.0);
            }
        `;

        const material = new THREE.ShaderMaterial({
            vertexShader: vertexShader,
            fragmentShader: fragmentShader,
            uniforms: uniforms
        });

        // Create a plane covering the entire orthographic camera view
        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- Handling Window Resize and DPR ---
        function resize() {
            const width = window.innerWidth;
            const height = window.innerHeight;
            
            renderer.setSize(width, height);
            
            // Apply DPR setting to renderer and update shader resolution
            renderer.setPixelRatio(params.dpr);
            uniforms.u_resolution.value.set(width * params.dpr, height * params.dpr);
        }

        window.addEventListener('resize', resize);

        // --- GUI Setup (lil-gui) ---
        const gui = new GUI({ title: 'Fractal Settings' });
        
        gui.add(params, 'dpr', 0.1, 2.0, 0.1).name('Resolution (DPR)').onChange(resize);
        gui.add(params, 'speed', 0.0, 3.0, 0.1).name('Anim Speed').onChange(v => uniforms.u_speed.value = v);
        
        const colorsFolder = gui.addFolder('Colors');
        colorsFolder.addColor(params, 'fractalColor').name('Fractal Color').onChange(v => uniforms.u_fractalColor.value.set(v[0], v[1], v[2]));
        colorsFolder.addColor(params, 'bgColor').name('Background Color').onChange(v => uniforms.u_bgColor.value.set(v[0], v[1], v[2]));
        
        const effectsFolder = gui.addFolder('Effects');
        effectsFolder.add(params, 'holographicStrength', 0.0, 5.0, 0.1).name('Hologram Power').onChange(v => uniforms.u_holographicStrength.value = v);
        effectsFolder.add(params, 'noiseIntensity', 0.0, 0.2, 0.001).name('Film Grain').onChange(v => uniforms.u_noiseIntensity.value = v);

        const fractalFolder = gui.addFolder('Fractal Core');
        fractalFolder.add(params, 'seed', 0.0, 100.0, 0.01).name('Random Seed').onChange(v => uniforms.u_seed.value = v);
        fractalFolder.add(params, 'distortion', 0.0, 1.0, 0.01).name('Distortion').onChange(v => uniforms.u_distortion.value = v);
        fractalFolder.add(params, 'foldOffset', 0.0, 1.5, 0.01).name('Fold Offset').onChange(v => uniforms.u_foldOffset.value = v);
        fractalFolder.add(params, 'scaleMult', 0.5, 1.5, 0.01).name('Scale Multiplier').onChange(v => uniforms.u_scaleMult.value = v);

        // Close the GUI panel by default
        gui.close();

        // Initial setup call
        resize();

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            // Update time uniform for the shader
            uniforms.u_time.value = clock.getElapsedTime();
            
            renderer.render(scene, camera);
        }

        animate();