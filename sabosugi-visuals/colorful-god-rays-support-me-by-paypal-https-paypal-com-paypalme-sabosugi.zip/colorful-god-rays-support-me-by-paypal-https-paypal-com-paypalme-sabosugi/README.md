# Colorful God Rays – Support me by PayPal: https://paypal.com/paypalme/sabosugi

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/OPbrMKz](https://codepen.io/sabosugi/pen/OPbrMKz).

