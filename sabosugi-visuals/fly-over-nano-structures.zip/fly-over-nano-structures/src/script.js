        // --- SCENE SETUP ---
        const scene = new THREE.Scene();
        
        // Fullscreen Quad Camera
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
        camera.position.z = 1;

        const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(1.0); 
        document.body.appendChild(renderer.domElement);

        // --- SHADER MATERIAL ---
        const uniforms = {
            uTime: { value: 0.0 },
            uResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            uZoomSpeed: { value: 0.174 },
            uCamDist: { value: 11.232 },
            uCamHeight: { value: 3.024 },
            uFOV: { value: 6.0 }, 
            
            uPatternScale: { value: 0.4843 },
            uExtrusion: { value: 0.0568 },
            
            uBaseColor: { value: new THREE.Color(0x404854) },   // Silicon Dark
            uTraceColor: { value: new THREE.Color(0x3a4048) },  // Silicon Bright
            uGlowColor: { value: new THREE.Color(0x00d0ff) },   // Neon Core
            
            // Data Trails Uniforms (Long fading tails)
            uTrailColor: { value: new THREE.Color(0xffffff) },
            uTrailSpeed: { value: 0.5 },
            uTrailLength: { value: 12.0 },
            
            // Neon Particles Uniforms (Small 2px dots)
            uParticleColor: { value: new THREE.Color(0xffffff) },
            uParticleSpeed: { value: 1.5 },
            uParticleDensity: { value: 15.0 },
            uParticleSize: { value: 0.008 }, // Base threshold for ~2px size
            
            // Silicon Texture (White Dots)
            uDotDensity: { value: 38.0 }, 
            uDotOpacity: { value: 0.2 }, 
            
            uIterations: { value: 2 },
            uGlowIntensity: { value: 1.14 },
            uFogDensity: { value: 0.005 },
            
            uAA: { value: true } 
        };

        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            #define MAX_STEPS 120
            #define MAX_DIST 40.0
            #define SURF_DIST 0.002

            uniform float uTime;
            uniform vec2 uResolution;
            uniform float uZoomSpeed;
            uniform float uCamDist;
            uniform float uCamHeight;
            uniform float uFOV;
            
            uniform float uPatternScale;
            uniform float uExtrusion;
            
            uniform vec3 uBaseColor;
            uniform vec3 uTraceColor;
            uniform vec3 uGlowColor;
            
            uniform vec3 uTrailColor;
            uniform float uTrailSpeed;
            uniform float uTrailLength;
            
            uniform vec3 uParticleColor;
            uniform float uParticleSpeed;
            uniform float uParticleDensity;
            uniform float uParticleSize;
            
            uniform float uDotDensity;
            uniform float uDotOpacity;
            
            uniform int uIterations;
            uniform float uGlowIntensity;
            uniform float uFogDensity;
            
            uniform bool uAA;

            varying vec2 vUv;

            // --- MATH UTILS ---
            float rand2(vec2 co){
                return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
            }

            vec2 rot(vec2 p, float a) {
                float s = sin(a), c = cos(a);
                return p * mat2(c, -s, s, c);
            }

            // --- SOLID PATTERN ALGORITHM ---
            float getPatternClean(vec2 p) {
                vec2 g = floor(p);
                vec2 lp = fract(p);
                vec2 e = g;
                float lines = 0.0;
                
                for(int i = 0; i < 10; i++) {
                    if (i >= uIterations) break; 
                    
                    float w = exp2(float(i));
                    float fX, fY;
                    
                    float thick = 0.02 + 0.01 * float(i); 
                    float bevel = 0.025; 

                    // X split line
                    fX = rand2(e + vec2(0.0, float(i)));
                    if(lp.x < fX) e.x += w; else e.x -= w;
                    float lineX = smoothstep(thick + bevel, thick, abs(lp.x - fX));

                    // Z split line
                    fY = rand2(e + vec2(1.0, float(i)));
                    if(lp.y < fY) e.y += w; else e.y -= w;
                    float lineY = smoothstep(thick + bevel, thick, abs(lp.y - fY));
                    
                    lines = max(lines, max(lineX, lineY));
                }
                
                return 1.0 - lines; 
            }

            // --- DISTANCE FIELD ---
            float getDist(vec3 p) {
                float chip = getPatternClean(p.xz * uPatternScale);
                float h = chip * uExtrusion; 
                return (p.y - h) * 0.45; 
            }

            // --- NORMALS ---
            vec3 getNormal(vec3 p) {
                vec2 e = vec2(0.003, -0.003); 
                return normalize(
                    e.xyy * getDist(p + e.xyy) +
                    e.yyx * getDist(p + e.yyx) +
                    e.yxy * getDist(p + e.yxy) +
                    e.xxx * getDist(p + e.xxx)
                );
            }

            // --- SHADOWS ---
            float getShadow(vec3 ro, vec3 rd) {
                float res = 1.0;
                float t = 0.05;
                for(int i = 0; i < 12; i++) {
                    float h = getDist(ro + rd * t);
                    if(h < 0.001) return 0.1;
                    res = min(res, 8.0 * h / t);
                    t += h * 1.2;
                }
                return res;
            }

            // --- RENDER PASS ---
            vec3 renderScene(vec2 uv) {
                float flightProgress = uTime * uZoomSpeed * 2.5; 
                
                // Isometric Camera Setup
                vec3 ro = vec3(uCamDist - flightProgress, uCamHeight, uCamDist - flightProgress); 
                vec3 ta = vec3(-flightProgress, 0.0, -flightProgress); 
                
                vec3 forward = normalize(ta - ro);
                vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
                vec3 up = cross(forward, right);
                
                vec3 rd = normalize(uv.x * right + uv.y * up + forward * uFOV);
                
                float distTotal = 0.0;
                vec3 p;
                
                for(int i = 0; i < MAX_STEPS; i++) {
                    p = ro + rd * distTotal;
                    float distStep = getDist(p);
                    distTotal += distStep;
                    if(distTotal > MAX_DIST || abs(distStep) < SURF_DIST) break;
                }

                vec3 col = uBaseColor * 0.1; 

                if(distTotal < MAX_DIST) {
                    vec3 n = getNormal(p);
                    vec3 ref = reflect(rd, n);
                    
                    float chip = getPatternClean(p.xz * uPatternScale);
                    float gap = 1.0 - chip; 
                    
                    float isTop = smoothstep(0.95, 1.0, chip);

                    vec3 matColor = mix(uBaseColor, uTraceColor, isTop);
                    
                    // Lighting
                    vec3 lightDir = normalize(vec3(0.8, 1.0, 0.5));
                    float dif = max(dot(n, lightDir), 0.0);
                    float shadow = getShadow(p + n * 0.01, lightDir);
                    
                    float spec = pow(max(dot(ref, lightDir), 0.0), 32.0) * isTop;

                    col = matColor * (dif * shadow + 0.15); 
                    col += spec * shadow * vec3(1.0);       
                    
                    // Neon Trenches
                    float deepGap = smoothstep(0.3, 0.0, p.y / uExtrusion);
                    col += uGlowColor * gap * deepGap * uGlowIntensity * (shadow + 0.5);

                    // --- 1. MOVING DATA TRAILS (LONG TAILS) ---
                    float tFreq = uPatternScale * 2.0;
                    float idX = floor(p.z * tFreq * 8.0);
                    float idZ = floor(p.x * tFreq * 8.0);
                    float rX = rand2(vec2(idX, 12.3));
                    float rZ = rand2(vec2(idZ, 45.6));
                    
                    float dirX = sign(rX - 0.5);
                    float dirZ = sign(rZ - 0.5);
                    float speedX = uTime * uTrailSpeed * (rX * 0.5 + 0.5);
                    float speedZ = uTime * uTrailSpeed * (rZ * 0.5 + 0.5);
                    
                    float pulseX = fract(p.x * tFreq * dirX - speedX + rX * 10.0);
                    float pulseZ = fract(p.z * tFreq * dirZ - speedZ + rZ * 10.0);
                    
                    float trailX = pow(pulseX, uTrailLength) * step(0.6, rX);
                    float trailZ = pow(pulseZ, uTrailLength) * step(0.6, rZ);
                    
                    float trailMask = max(trailX, trailZ);
                    col += uTrailColor * trailMask * gap * deepGap * 3.0;

                    // --- 2. NEON PARTICLES (2PX DOTS WITH RANDOM DISTANCES) ---
                    float pFreq = uPatternScale * 2.0;
                    float pidX = floor(p.z * pFreq * 8.0);
                    float pidZ = floor(p.x * pFreq * 8.0);
                    float prX = rand2(vec2(pidX, 77.7));
                    float prZ = rand2(vec2(pidZ, 88.8));
                    
                    float pdirX = sign(prX - 0.5);
                    float pdirZ = sign(prZ - 0.5);
                    float pspeedX = uTime * uParticleSpeed * (prX * 0.5 + 0.5);
                    float pspeedZ = uTime * uParticleSpeed * (prZ * 0.5 + 0.5);
                    
                    float pDens = uPatternScale * uParticleDensity;
                    
                    // 1D Cellular noise approach to create random gaps between dots
                    float lineCoordX = p.x * pDens * pdirX - pspeedX + prX * 10.0;
                    float cellIdX = floor(lineCoordX);
                    float cellFractX = fract(lineCoordX);
                    // Random position within the cell
                    float dotPosX = rand2(vec2(cellIdX, prX)) * 0.6 + 0.2; 
                    float pdistX = abs(cellFractX - dotPosX);
                    // Randomly skip some cells entirely to create larger gaps
                    float showDotX = step(0.4, rand2(vec2(cellIdX, prX * 1.337))); 
                    
                    float lineCoordZ = p.z * pDens * pdirZ - pspeedZ + prZ * 10.0;
                    float cellIdZ = floor(lineCoordZ);
                    float cellFractZ = fract(lineCoordZ);
                    float dotPosZ = rand2(vec2(cellIdZ, prZ)) * 0.6 + 0.2;
                    float pdistZ = abs(cellFractZ - dotPosZ);
                    float showDotZ = step(0.4, rand2(vec2(cellIdZ, prZ * 1.337)));

                    // Dynamic threshold based on distance 'distTotal' maintains a constant ~2px screen size
                    float dotScale = uParticleSize * max(0.5, distTotal * 0.5);
                    float dotSmooth = dotScale * 0.3; 
                    
                    float partX = smoothstep(dotScale + dotSmooth, dotScale, pdistX) * step(0.4, prX) * showDotX;
                    float partZ = smoothstep(dotScale + dotSmooth, dotScale, pdistZ) * step(0.4, prZ) * showDotZ;
                    
                    float partMask = max(partX, partZ);
                    col += uParticleColor * partMask * gap * deepGap * 4.0;

                    // --- 3. SILICON TEXTURE (TWINKLING WHITE DOT GRID) ---
                    if (isTop > 0.5) {
                        float dotScaleUv = uPatternScale * uDotDensity;
                        vec2 dotUv = fract(p.xz * dotScaleUv);
                        vec2 dotId = floor(p.xz * dotScaleUv);

                        float dotMaskX = 1.0 - smoothstep(0.15, 0.25, abs(dotUv.x - 0.5));
                        float dotMaskY = 1.0 - smoothstep(0.15, 0.25, abs(dotUv.y - 0.5));
                        float dotGridMask = dotMaskX * dotMaskY;

                        float dotRnd = rand2(dotId * 1.337);
                        float twinkle = sin(uTime * 2.5 + dotRnd * 6.2831) * 0.5 + 0.5;

                        float distanceFade = smoothstep(MAX_DIST * 0.6, MAX_DIST * 0.2, distTotal);
                        float finalDotAlpha = uDotOpacity * (0.2 + 0.8 * twinkle) * distanceFade;

                        col += vec3(1.0) * dotGridMask * finalDotAlpha * isTop;
                    }
                }

                // Smooth distance fog 
                float fog = 1.0 - exp(-distTotal * distTotal * uFogDensity);
                vec3 fogColor = mix(uBaseColor, vec3(0.0), 0.5); 
                col = mix(col, fogColor, fog);

                // Vignette
                float vig = length(uv) * 0.4;
                col -= vig * vig * 0.5;
                col = smoothstep(0.0, 1.1, col); 

                return col;
            }

            void main() {
                vec3 totalCol = vec3(0.0);
                
                if (uAA) {
                    vec2 offsets[2];
                    offsets[0] = vec2(-0.25, -0.25);
                    offsets[1] = vec2( 0.25,  0.25);
                    
                    for(int i = 0; i < 2; i++) {
                        vec2 uv = (vUv - 0.5 + offsets[i] / uResolution.xy) * 2.0;
                        uv.x *= uResolution.x / uResolution.y;
                        totalCol += renderScene(uv);
                    }
                    totalCol *= 0.5;
                } else {
                    vec2 uv = (vUv - 0.5) * 2.0;
                    uv.x *= uResolution.x / uResolution.y;
                    totalCol = renderScene(uv);
                }

                gl_FragColor = vec4(totalCol, 1.0);
            }
        `;

        const geometry = new THREE.PlaneGeometry(2, 2);
        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms
        });

        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- GUI SETUP (lil-gui) ---
        const gui = new lil.GUI({ title: 'Scene Settings' });
        
        const camFolder = gui.addFolder('Camera & Zoom');
        camFolder.add(uniforms.uZoomSpeed, 'value', 0.0, 2.0).name('Flight / Zoom Speed');
        camFolder.add(uniforms.uCamDist, 'value', 2.0, 15.0).name('Camera Distance');
        camFolder.add(uniforms.uCamHeight, 'value', 1.0, 15.0).name('Camera Height');
        camFolder.add(uniforms.uFOV, 'value', 1.0, 6.0).name('Lens (FOV / Isometric)');
        
        const renderFolder = gui.addFolder('Architecture');
        renderFolder.add(uniforms.uIterations, 'value', 2, 10).step(1).name('Detail Level');
        renderFolder.add(uniforms.uPatternScale, 'value', 0.1, 3.0).name('Grid Scale');
        renderFolder.add(uniforms.uExtrusion, 'value', 0.0, 0.8).name('Chip Height');
        renderFolder.add(uniforms.uGlowIntensity, 'value', 0.0, 5.0).name('Neon Trenches Glow');
 
        const texFolder = gui.addFolder('Silicon Texture');
        texFolder.add(uniforms.uDotDensity, 'value', 20.0, 120.0).name('Dot Grid Density');
        texFolder.add(uniforms.uDotOpacity, 'value', 0.0, 1.0).name('Dot Maximum Opacity');
        
        const trailFolder = gui.addFolder('Data Trails (Long)');
        trailFolder.add(uniforms.uTrailSpeed, 'value', 0.0, 10.0).name('Trail Speed');
        trailFolder.add(uniforms.uTrailLength, 'value', 2.0, 30.0).name('Trail Fade (Higher = Shorter)');
        
        const particleFolder = gui.addFolder('Neon Particles (Dots)');
        particleFolder.add(uniforms.uParticleSpeed, 'value', 0.0, 5.0).name('Particle Speed');
        particleFolder.add(uniforms.uParticleDensity, 'value', 1.0, 30.0).name('Particle Density');
        particleFolder.add(uniforms.uParticleSize, 'value', 0.001, 0.02).name('Particle Size');

        const colorFolder = gui.addFolder('Colors');
        const params = {
            baseColor: uniforms.uBaseColor.value.getHex(),
            traceColor: uniforms.uTraceColor.value.getHex(),
            glowColor: uniforms.uGlowColor.value.getHex(),
            trailColor: uniforms.uTrailColor.value.getHex(),
            particleColor: uniforms.uParticleColor.value.getHex()
        };

        colorFolder.addColor(params, 'baseColor').name('Silicon Dark').onChange(c => uniforms.uBaseColor.value.setHex(c));
        colorFolder.addColor(params, 'traceColor').name('Silicon Bright').onChange(c => uniforms.uTraceColor.value.setHex(c));
        colorFolder.addColor(params, 'glowColor').name('Neon Core').onChange(c => uniforms.uGlowColor.value.setHex(c));
        colorFolder.addColor(params, 'trailColor').name('Data Trails').onChange(c => uniforms.uTrailColor.value.setHex(c));
        colorFolder.addColor(params, 'particleColor').name('Neon Particles').onChange(c => uniforms.uParticleColor.value.setHex(c));

        const perfFolder = gui.addFolder('Quality & Performance');
        perfFolder.add(uniforms.uAA, 'value').name('Enable Anti-Aliasing (SSAA)');
        
        const settings = { renderScale: 1.0 };
        perfFolder.add(settings, 'renderScale', 0.5, 2.0).step(0.1).name('Render Scale').onChange(v => {
            renderer.setPixelRatio(v);
        });

        // Close the GUI panel by default
        gui.close();

        // --- RESIZE HANDLER ---
        window.addEventListener('resize', () => {
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(settings.renderScale);
            uniforms.uResolution.value.set(window.innerWidth, window.innerHeight);
        });

        // --- ANIMATION LOOP ---
        const clock = new THREE.Clock();
        function animate() {
            requestAnimationFrame(animate);
            uniforms.uTime.value = clock.getElapsedTime();
            renderer.render(scene, camera);
        }
        animate();