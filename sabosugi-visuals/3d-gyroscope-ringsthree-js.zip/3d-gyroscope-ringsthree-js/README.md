#  3D Gyroscope Rings - Three.js

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/OPXzbze](https://codepen.io/sabosugi/pen/OPXzbze).

