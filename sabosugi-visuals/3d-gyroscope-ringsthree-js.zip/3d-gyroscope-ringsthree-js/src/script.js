import * as THREE from 'three';
    import { GUI } from 'lil-gui';

    // --- 1. CONFIGURATION ---
    const params = {
        // Scene
        backgroundColor: '#ffffff',
        
        // Geometry (Defaults)
        ringCount: 5,
        startRadius: 0,
        bandWidth: 15,
        gap: 0,
        thickness: 0.1,
        
        // Appearance
        innerColor: '#e5f5ff', 
        outerColor: '#b8d6e5', 
        opacity: 0.05,
        transparent: true,
        
        // Animation
        rotationSpeed: 0.5,
        chaosLevel: 1,
        
        // Cycle Settings
        cycleDuration: 30,       // Total time for one loop (Spin + Reset)
        resetDuration: 3,        // Time spent returning to center at the end
        accelerationTime: 5.0,   // Time to ramp up speed after reset
        resetSmoothness: 0.03    // How "stiff" the pull to center is (lower = smoother/looser)
    };

    // --- 2. SCENE SETUP ---
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(params.backgroundColor);

    const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 1000);
    camera.position.set(0, 0, 120);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    
    // High quality color space
    renderer.outputColorSpace = THREE.SRGBColorSpace; 
    document.body.appendChild(renderer.domElement);

    // --- LIGHTING (Hemisphere + Directional) ---
    // Hemisphere light gives a natural gradient from sky to ground
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x9EADB8, 1.8);
    hemiLight.position.set(0, 20, 0);
    scene.add(hemiLight);

    // Key light for definition
    const dirLight = new THREE.DirectionalLight(0xffffff, 1.0);
    dirLight.position.set(10, 20, 50);
    scene.add(dirLight);

    // --- 3. RING MANAGEMENT ---
    let rings = []; 
    const lineMaterial = new THREE.LineBasicMaterial({ 
        color: 0x000000, 
        transparent: true,
        opacity: 0.3 
    });

    function getGradientColor(index, total) {
        const c1 = new THREE.Color(params.innerColor);
        const c2 = new THREE.Color(params.outerColor);
        const alpha = total > 1 ? index / (total - 1) : 0;
        return c1.clone().lerp(c2, alpha);
    }

    function rebuildRings() {
        rings.forEach(ring => {
            scene.remove(ring);
            ring.geometry.dispose();
            ring.material.dispose();
            ring.children.forEach(c => c.geometry && c.geometry.dispose());
        });
        rings = [];

        let innerR = (params.startRadius > 0) ? params.startRadius : 0; 

        for (let i = 0; i < params.ringCount; i++) {
            const outerR = innerR + params.bandWidth;
            
            const shape = new THREE.Shape();
            shape.absarc(0, 0, outerR, 0, Math.PI * 2, false);
            if (innerR > 0) {
                const hole = new THREE.Path();
                hole.absarc(0, 0, innerR, 0, Math.PI * 2, true);
                shape.holes.push(hole);
            }

            const geometry = new THREE.ExtrudeGeometry(shape, {
                depth: params.thickness,
                bevelEnabled: false,
                curveSegments: 96
            });
            geometry.center();

            const color = getGradientColor(i, params.ringCount);
            
            // MeshStandardMaterial with Dithering enabled
            const material = new THREE.MeshStandardMaterial({
                color: color,
                roughness: 0.4,
                metalness: 0.1,
                transparent: params.transparent,
                opacity: params.opacity,
                side: THREE.DoubleSide,
                dithering: true // Prevents color banding
            });

            const mesh = new THREE.Mesh(geometry, material);

            const edges = new THREE.EdgesGeometry(geometry);
            const line = new THREE.LineSegments(edges, lineMaterial);
            mesh.add(line);

            // Start flat
            mesh.rotation.set(0, 0, 0);

            // Calculate random speeds
            updateRingSpeed(mesh);

            scene.add(mesh);
            rings.push(mesh);

            innerR = outerR + params.gap;
        }
    }

    function updateRingSpeed(mesh) {
        const baseSpeed = 0.02;
        mesh.userData.speedX = (Math.random() - 0.5) * baseSpeed * params.chaosLevel;
        mesh.userData.speedY = (Math.random() - 0.5) * baseSpeed * params.chaosLevel;
        mesh.userData.speedZ = (Math.random() - 0.5) * baseSpeed * params.chaosLevel;
        
        if (Math.abs(mesh.userData.speedX) < 0.002) mesh.userData.speedX += 0.005;
    }

    function updateMaterials() {
        rings.forEach((ring, i) => {
            ring.material.color.set(getGradientColor(i, rings.length));
            ring.material.opacity = params.opacity;
            ring.material.transparent = params.transparent;
            ring.material.needsUpdate = true;
        });
        scene.background.set(params.backgroundColor);
    }

    function updateSpeeds() {
        rings.forEach(ring => updateRingSpeed(ring));
    }

    // --- 4. ANIMATION LOOP ---
    const clock = new THREE.Clock();
    const targetQuaternion = new THREE.Quaternion(); // Identity (0,0,0,1)

    function animate() {
        requestAnimationFrame(animate);

        // Logic for smooth cycles
        const time = clock.getElapsedTime();
        const cycleTime = time % params.cycleDuration; 
        const timeRemaining = params.cycleDuration - cycleTime;

        let rotationMultiplier = 1.0;
        let isResetting = false;

        // Phase 1: Resetting (End of cycle)
        if (timeRemaining < params.resetDuration) {
            isResetting = true;
            rotationMultiplier = 0; // Stop adding new chaos, just align
        } 
        // Phase 2: Acceleration (Start of new cycle)
        else if (cycleTime < params.accelerationTime) {
            // Smoothstep from 0 to 1
            // t goes from 0 to 1 over the duration of accelerationTime
            const t = cycleTime / params.accelerationTime;
            // Easing function (Quadratic ease-in-out)
            rotationMultiplier = t * (2 - t); 
        }

        const globalMult = params.rotationSpeed;

        rings.forEach(ring => {
            if (isResetting) {
                // Smoothly pull towards flat position
                // The factor (resetSmoothness) determines how fast it snaps. 
                // Smaller = slower/smoother.
                ring.quaternion.slerp(targetQuaternion, params.resetSmoothness);
            } else {
                // Apply rotation
                // We use rotateX/Y/Z which modifies the quaternion internally
                const currentSpeedMult = globalMult * rotationMultiplier;
                
                ring.rotateX(ring.userData.speedX * currentSpeedMult);
                ring.rotateY(ring.userData.speedY * currentSpeedMult);
                ring.rotateZ(ring.userData.speedZ * currentSpeedMult);
            }
        });

        renderer.render(scene, camera);
    }

    // --- 5. GUI SETUP ---
    function setupGUI() {
        const gui = new GUI({ title: 'Settings' });

        const folderScene = gui.addFolder('Scene');
        folderScene.addColor(params, 'backgroundColor').name('Background').onChange(updateMaterials);
        
        const folderGeo = gui.addFolder('Geometry');
        folderGeo.add(params, 'ringCount', 1, 15, 1).name('Ring Count').onChange(rebuildRings);
        folderGeo.add(params, 'startRadius', 0, 20).name('Center Radius').onChange(rebuildRings);
        folderGeo.add(params, 'bandWidth', 0.2, 15).name('Ring Width').onChange(rebuildRings);
        folderGeo.add(params, 'gap', 0, 5).name('Gap').onChange(rebuildRings);
        folderGeo.add(params, 'thickness', 0.1, 5).name('Thickness').onChange(rebuildRings);

        const folderLook = gui.addFolder('Appearance');
        folderLook.addColor(params, 'innerColor').name('Inner Color').onChange(updateMaterials);
        folderLook.addColor(params, 'outerColor').name('Outer Color').onChange(updateMaterials);
        folderLook.add(params, 'opacity', 0.05, 1.0).name('Opacity').onChange(updateMaterials);
        
        const folderAnim = gui.addFolder('Animation');
        folderAnim.add(params, 'rotationSpeed', 0, 5).name('Max Speed');
        folderAnim.add(params, 'chaosLevel', 0.1, 5).name('Chaos Factor').onFinishChange(updateSpeeds);
        
        const folderCycle = gui.addFolder('Cycle & Smoothing');
        folderCycle.add(params, 'cycleDuration', 5, 60).name('Total Cycle (s)');
        folderCycle.add(params, 'resetDuration', 1, 10).name('Reset Time (s)');
        folderCycle.add(params, 'accelerationTime', 0, 10).name('Ramp Up Time (s)');
        folderCycle.add(params, 'resetSmoothness', 0.01, 0.2).name('Reset Force');

        folderGeo.open();
        folderAnim.open();
    }

    // --- EVENTS ---
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // --- START ---
    setupGUI();
    rebuildRings();
    animate();