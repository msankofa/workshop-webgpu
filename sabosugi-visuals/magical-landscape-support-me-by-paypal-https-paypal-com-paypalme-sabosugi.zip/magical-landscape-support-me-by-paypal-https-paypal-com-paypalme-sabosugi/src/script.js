    import * as THREE from 'three';
    import { GUI } from 'lil-gui';

    // 1. Setup basic Three.js scene
    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
    camera.position.z = 1;

    const renderer = new THREE.WebGLRenderer({ antialias: false });
    document.body.appendChild(renderer.domElement);

    // 2. Uniforms for the shader
    const uniforms = {
        iResolution: { value: new THREE.Vector2() },
        iTime: { value: 0 },
        uSpeed: { value: 2.0 },
        uFractalStep: { value: 0.020531 },
        uFractalAmp: { value: 0.06688 },
        uTerrainScale: { value: 0.64 },
        uTerrainBaseHeight: { value: 0.8 },
        uTerrainAmp: { value: 0.9 },
        uGroundOffset: { value: 2.3 },
        uColor1: { value: new THREE.Color('#0a9fbd') },
        uColor2: { value: new THREE.Color('#00d2ff') },
        uColor3: { value: new THREE.Color('#001adb') },
        uColor4: { value: new THREE.Color('#ff0055') },
        uSeed: { value: Math.random() * 1000.0 }
    };

    // 3. Shader Material setup
    const vertexShader = `
        void main() {
            gl_Position = vec4(position, 1.0);
        }
    `;

    const fragmentShader = `
        uniform vec2 iResolution;
        uniform float iTime;
        uniform float uSpeed;
        uniform float uFractalStep;
        uniform float uFractalAmp;
        uniform float uTerrainScale;
        uniform float uTerrainBaseHeight;
        uniform float uTerrainAmp;
        uniform float uGroundOffset;
        uniform vec3 uColor1;
        uniform vec3 uColor2;
        uniform vec3 uColor3;
        uniform vec3 uColor4;
        uniform float uSeed;

        // Cyclical color gradient helper
        vec3 getGradient(float t, vec3 c1, vec3 c2, vec3 c3, vec3 c4) {
            t = fract(t);
            if (t < 0.25) return mix(c1, c2, smoothstep(0.0, 0.25, t));
            if (t < 0.50) return mix(c2, c3, smoothstep(0.25, 0.50, t));
            if (t < 0.75) return mix(c3, c4, smoothstep(0.50, 0.75, t));
            return mix(c4, c1, smoothstep(0.75, 1.0, t));
        }

        // 2D Rotation matrix helper
        mat2 getRotationMatrix(float theta) {
            float s = sin(theta);
            float c = cos(theta);
            return mat2(c, s, -s, c);
        }

        // Pseudo-random hash for noise
        float hash(vec2 p) {
            p = fract(p * vec2(125.86, 458.36));
            p += dot(p, p + 44.21);
            return fract(p.x * p.y);
        }

        // Interleaved Gradient Noise for advanced dithering
        float getIGN(vec2 p) {
            vec3 magic = vec3(0.02711056, 0.00583715, 52.9829189);
            return fract(magic.z * fract(dot(p, magic.xy)));
        }

        // 2D Value Noise for the landscape
        float noise2d(vec2 x) {
            vec2 p = floor(x);
            vec2 f = fract(x);
            f = f * f * (3.0 - 2.0 * f);
            float a = hash(p + vec2(0.0, 0.0));
            float b = hash(p + vec2(1.0, 0.0));
            float c = hash(p + vec2(0.0, 1.0));
            float d = hash(p + vec2(1.0, 1.0));
            return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }

        // Pre-computed rotation matrix
        const mat2 rot55 = mat2(-0.163296, 8.20684, 2.54316, 5.356704);

        // Landscape SDF with Dynamic LOD
        float getTerrain(vec3 p, float d) {
            // OPTIMIZATION 1: Tighter Bounding Volume
            if (p.y > 6.0) return p.y - 0.0;

            // Scale down UVs to make mountains appear larger, offset by seed for randomness
            vec2 uv = p.xz * uTerrainScale + uSeed;
            float h = uTerrainBaseHeight;
            float a = uTerrainAmp; // Amplitude for rocky peaks
            
            // OPTIMIZATION 2: Distance-based LOD
            int octaves = 2;
            if (d > 21.6) octaves = 3;
            if (d > 33.1) octaves = 2;

            // Multiple octaves for rugged rock terrain
            for(int j = 0; j < 4; j++) {
                if (j >= octaves) break; // Early exit
                h += noise2d(uv) * a;
                uv *= rot55;
                uv += vec2(-4.8, 11.5);
                a *= 0.3;
            }
            
            // SDF height function (ground level offset)
            return p.y + h - uGroundOffset;
        }

        void mainImage(out vec4 fragColor, in vec2 fragCoord) {
            // 1. Screen coordinates
            vec2 resolution = iResolution.xy;
            vec2 uv = (fragCoord * 2.0 - resolution) / resolution.y;
            
            float time = iTime * 0.3;

            // 2. Camera Setup (Flying over the terrain)
            vec3 ro = vec3(0.0, 2.7, time * uSpeed);
            vec3 rd = normalize(vec3(uv, 1.0));
            
            // Pitch down slightly to look at the ground
            mat2 pitch = getRotationMatrix(0.17);
            rd.yz *= pitch;
            
            // 3. Volumetric Raymarching & Accumulation State
            vec3 accumulatedColor = vec3(3.0);
            
            // ANTI-BANDING 1: Ray Jittering
            float d = hash(fragCoord) * 0.03; 
            float s = 0.0;
            
            // 4. Main Volumetric Loop
            for(float i = 1.0; i <= 100.0; i++) {
                // Early Ray Termination
                if (d > 60.0) break;

                vec3 p = ro + rd * d;
                
                // Terrain Masking
                float terrainDist = getTerrain(p, d);
                float shape;
                
                // OPTIMIZATION 3: SDF Math Bypassing
                if (terrainDist > 4.0) {
                    shape = terrainDist; // Fast path
                } else {
                    // --- SMOOTH FRACTAL LOGIC (No cubes) ---
                    vec3 p3 = p * 2.5 + uSeed;
                    vec3 sinP = sin(p3);
                    vec3 cosP = cos(vec3(p3.y, p3.z, p3.x));
                    
                    // Using a smooth Gyroid structure instead of the blocky floor()
                    float structuralNoise = dot(sinP, cosP) * 0.5;
                    // ------------------------------------
                    shape = max(structuralNoise, terrainDist);
                }
                
                // Step size / SDF evaluation
                s = uFractalStep + uFractalAmp * abs(shape - i * 0.02);
                d += s;
                
                // Color Accumulation (Cycling through 4 colors based on depth/iteration)
                float colorT = i * 0.04;
                vec3 baseColor = getGradient(colorT, uColor1, uColor2, uColor3, uColor4) * 1.4;

                // Distance dampening to fade into darkness/fog
                float dampening = -d * d * 0.42;

                accumulatedColor += max(baseColor / s, dampening);
            }
            
            // 5. Final Tone Mapping 
            vec3 finalOutputColor = (accumulatedColor * accumulatedColor) * 0.00000125;
            vec3 toneMappedColor = tanh(finalOutputColor);
            
            // 6. ANTI-BANDING 2: Enhanced Interleaved Gradient Dithering
            float ditherNoise = getIGN(fragCoord);
            toneMappedColor += (ditherNoise - 0.5) * 0.004;

            fragColor = vec4(toneMappedColor, 1.0);
        }

        void main() {
            mainImage(gl_FragColor, gl_FragCoord.xy);
        }
    `;

    const material = new THREE.ShaderMaterial({
        vertexShader,
        fragmentShader,
        uniforms
    });

    const plane = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material);
    scene.add(plane);

    // 4. GUI Setup (lil-gui)
    const gui = new GUI();
    gui.close(); // Closed by default

    const params = {
        dpr: 0.5,
        speed: 2.0,
        fractalStep: 0.020531,
        fractalAmp: 0.06688,
        terrainScale: 0.64,
        terrainBaseHeight: 0.8,
        terrainAmp: 0.9,
        groundOffset: 2.3,
        color1: '#0a9fbd',
        color2: '#00d2ff',
        color3: '#001adb',
        color4: '#ff0055'
    };

    // Helper function to update DPR and sync iResolution
    function updateDPR() {
        // Set the internal resolution scale
        renderer.setPixelRatio(params.dpr);
        // Force an update to the uniforms so the shader knows the new physical pixel count
        onWindowResize();
    }

    const renderFolder = gui.addFolder('Render Settings');
    renderFolder.add(params, 'dpr', 0.1, 2.0, 0.1).name('Resolution (DPR)').onChange(updateDPR);
    
    const flightFolder = gui.addFolder('Flight Settings');
    flightFolder.add(params, 'speed', 0.0, 10.0, 0.1).name('Flight Speed').onChange(v => uniforms.uSpeed.value = v);

    const fractalFolder = gui.addFolder('Fractal Light');
    fractalFolder.add(params, 'fractalStep', 0.001, 0.05).name('Step Base').onChange(v => uniforms.uFractalStep.value = v);
    fractalFolder.add(params, 'fractalAmp', 0.01, 0.2).name('Step Amplitude').onChange(v => uniforms.uFractalAmp.value = v);

    const terrainFolder = gui.addFolder('Terrain Settings');
    terrainFolder.add(params, 'terrainScale', 0.1, 2.0, 0.01).name('Scale').onChange(v => uniforms.uTerrainScale.value = v);
    terrainFolder.add(params, 'terrainBaseHeight', 0.0, 3.0, 0.1).name('Base Height').onChange(v => uniforms.uTerrainBaseHeight.value = v);
    terrainFolder.add(params, 'terrainAmp', 0.1, 3.0, 0.1).name('Amplitude').onChange(v => uniforms.uTerrainAmp.value = v);
    terrainFolder.add(params, 'groundOffset', 0.0, 5.0, 0.1).name('Ground Offset').onChange(v => uniforms.uGroundOffset.value = v);

    const colorFolder = gui.addFolder('Colors');
    colorFolder.addColor(params, 'color1').name('Color 1').onChange(v => uniforms.uColor1.value.set(v));
    colorFolder.addColor(params, 'color2').name('Color 2').onChange(v => uniforms.uColor2.value.set(v));
    colorFolder.addColor(params, 'color3').name('Color 3').onChange(v => uniforms.uColor3.value.set(v));
    colorFolder.addColor(params, 'color4').name('Color 4').onChange(v => uniforms.uColor4.value.set(v));

    // 5. Resize Handler
    function onWindowResize() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        // Ensure the CSS size stays exactly the size of the window
        renderer.setSize(width, height);
        
        // Calculate the actual physical pixels being rendered
        const pixelRatio = renderer.getPixelRatio();
        uniforms.iResolution.value.set(width * pixelRatio, height * pixelRatio);
    }
    
    window.addEventListener('resize', onWindowResize);
    
    // Initial setup
    updateDPR();

    // 6. Animation Loop
    const clock = new THREE.Clock();

    function animate() {
        requestAnimationFrame(animate);
        uniforms.iTime.value = clock.getElapsedTime();
        renderer.render(scene, camera);
    }

    animate();