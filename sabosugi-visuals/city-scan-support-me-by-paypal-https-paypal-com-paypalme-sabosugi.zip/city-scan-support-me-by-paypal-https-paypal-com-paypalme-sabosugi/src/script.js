        import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- SCENE SETUP ---
        const scene = new THREE.Scene();
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
        camera.position.z = 1;

        const renderer = new THREE.WebGLRenderer({ antialias: false });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // --- GUI PARAMETERS ---
        const params = {
            dpr: 0.8,
            flightSpeed: 0.5,
            camPosY: 10.0,
            camPitch: 0.6,
            dotColor: '#436e84',    
            scanColor: '#00ccff',   
            buildingColor: '#1b202d', 
            dotDensity: 12.0,
            fogDensity: 0.03,
            scanSpeed: 0.7
        };

        renderer.setPixelRatio(params.dpr);

        // --- SHADER UNIFORMS ---
        const uniforms = {
            u_time: { value: 0.0 },
            u_resolution: { value: new THREE.Vector2(window.innerWidth * params.dpr, window.innerHeight * params.dpr) },
            u_flightSpeed: { value: params.flightSpeed },
            u_camPosY: { value: params.camPosY },
            u_camPitch: { value: params.camPitch },
            u_dotColor: { value: new THREE.Color(params.dotColor) },
            u_scanColor: { value: new THREE.Color(params.scanColor) },
            u_buildingColor: { value: new THREE.Color(params.buildingColor) },
            u_dotDensity: { value: params.dotDensity },
            u_fogDensity: { value: params.fogDensity },
            u_scanSpeed: { value: params.scanSpeed }
        };

        // --- SHADER MATERIAL ---
        const vertexShader = `
            void main() {
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform float u_time;
            uniform vec2 u_resolution;
            uniform float u_flightSpeed;
            uniform float u_camPosY;
            uniform float u_camPitch;
            uniform vec3 u_dotColor;
            uniform vec3 u_scanColor;
            uniform vec3 u_buildingColor;
            uniform float u_dotDensity;
            uniform float u_fogDensity;
            uniform float u_scanSpeed;

            // Pseudo-random hash function for generating random heights
            float hash(vec2 p) {
                p = fract(p * vec2(123.34, 456.21));
                p += dot(p, p + 45.32);
                return fract(p.x * p.y);
            }

            // 3D Procedural SDF for City Skyscrapers
            float map(vec3 p) {
                vec2 id = floor(p.xz);
                vec2 f = fract(p.xz) - 0.5;
                
                float d = p.y; 
                
                for(int j = -1; j <= 1; j++) {
                    for(int i = -1; i <= 1; i++) {
                        vec2 offset = vec2(float(i), float(j));
                        vec2 nId = id + offset;
                        vec2 nF = f - offset;
                        
                        float height = hash(nId) * 4.0 + 1.0;
                        
                        vec3 q = vec3(nF.x, p.y - height * 0.5, nF.y);
                        vec3 boxSize = vec3(0.35, height * 0.5, 0.35); 
                        
                        vec3 distVec = abs(q) - boxSize;
                        float boxDist = length(max(distVec, 0.0)) + min(max(distVec.x, max(distVec.y, distVec.z)), 0.0);
                        
                        d = min(d, boxDist);
                    }
                }
                
                return d;
            }

            // Normal calculation
            vec3 getNormal(vec3 p) {
                // Increased epsilon slightly to prevent micro-flickering on perfect mathematical edges
                vec2 e = vec2(0.005, 0.0); 
                return normalize(vec3(
                    map(p + e.xyy) - map(p - e.xyy),
                    map(p + e.yxy) - map(p - e.yxy),
                    map(p + e.yyx) - map(p - e.yyx)
                ));
            }

            void main() {
                vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
                
                // Camera setup
                vec3 rayOrigin = vec3(0.0, u_camPosY, u_time * u_flightSpeed); 
                vec3 rayDir = normalize(vec3(uv.x, uv.y - u_camPitch, 1.0)); 
                
                float distance = 0.0;
                vec3 p;
                
                // Main Raymarching loop
                for (int i = 0; i < 150; i++) {
                    p = rayOrigin + rayDir * distance;
                    float d = map(p);
                    
                    if (abs(d) < 0.001 || distance > 100.0) break;
                    distance += d * 0.75; 
                }
                
                vec3 fogColor = u_dotColor * 0.7;      
                vec3 color = fogColor - uv.y * 0.2;
                
                // Scanner logic
                float cycle = mod(u_time * u_scanSpeed, 6.0);
                float scanY = (cycle < 4.0) ? (6.0 - cycle * 1.75) : -100.0;
                float scanEnvelope = smoothstep(0.0, 0.5, cycle) * smoothstep(4.0, 3.5, cycle);
                
                if (distance < 100.0) {
                    
                    // Surface Refinement
                    for(int j = 0; j < 3; j++) {
                        distance += map(rayOrigin + rayDir * distance);
                    }
                    p = rayOrigin + rayDir * distance;
                    
                    vec3 normal = getNormal(p);
                    vec3 absN = abs(normal);
                    
                    vec2 surfaceUV;
                    // Strict > 0.5 check to ensure absolutely stable planar projection on cubes
                    if (absN.y > 0.5) {
                        surfaceUV = p.xz; // Roof
                    } else if (absN.z > 0.5) {
                        surfaceUV = p.xy; // Front/Back walls
                    } else {
                        surfaceUV = p.zy; // Side walls
                    }
                    
                    float dotDensity = u_dotDensity; 
                    vec2 scaledUV = surfaceUV * dotDensity;
                    vec2 gridUV = fract(scaledUV) - 0.5;
                    
                    // --- ULTIMATE FLICKER-FREE ANTI-ALIASING ---
                    
                    // 1. Calculate the exact physical size of a pixel in world space at this distance
                    float pixelSizeWorld = distance / u_resolution.y; 
                    
                    // 2. Project the pixel onto the surface based on the viewing angle
                    float viewAngle = max(abs(dot(normal, rayDir)), 0.05);
                    float pixelSizeUV = pixelSizeWorld / viewAngle;
                    
                    // 3. Scale pixel size to texture space
                    float pixelSizeTex = pixelSizeUV * dotDensity;
                    
                    // 4. Draw anti-aliased circle based on exact pixel footprint
                    float radius = 0.2;
                    float distFromCenter = length(gridUV);
                    float blur = max(pixelSizeTex * 0.8, 0.01); // Keep a crisp minimum blur
                    
                    float dotPattern = smoothstep(radius + blur, radius - blur, distFromCenter);
                    
                    // 5. THE MAGIC FIX: If the pixel covers too much of the cell, 
                    // it physically cannot render the dot without flickering.
                    // We smoothly blend it into the mathematical average density of the dots (0.125).
                    float fadeToAverage = smoothstep(0.15, 0.6, pixelSizeTex);
                    dotPattern = mix(dotPattern, 0.125, fadeToAverage);
                    
                    // 6. Secondary deep-distance fade (safety measure)
                    float moireFade = smoothstep(25.0, 50.0, distance);
                    dotPattern = mix(dotPattern, 0.125, moireFade);
                    
                    // ---------------------------------------------
                    
                    // Scanner glow and core
                    float distToScanner = abs(p.y - scanY);
                    float scanCore = smoothstep(0.1, 0.0, distToScanner); 
                    float scanGlow = smoothstep(1.5, 0.0, distToScanner); 
                    
                    vec3 dotBaseColor = u_dotColor * dotPattern;
                    vec3 materialColor = u_buildingColor + dotBaseColor;
                    
                    materialColor += u_scanColor * scanCore * 4.0 * scanEnvelope;
                    materialColor += u_scanColor * scanGlow * dotPattern * 2.5 * scanEnvelope; 
                    
                    vec3 lightDir = normalize(vec3(0.8, 0.6, -0.4));
                    float diff = max(dot(normal, lightDir), 0.0);
                    
                    color = materialColor * diff + (materialColor * 0.3);
                    color = mix(color, fogColor, 1.0 - exp(-u_fogDensity * distance));
                }
                
                // Holographic Scanner Plane
                float tPlane = (scanY - rayOrigin.y) / rayDir.y;
                
                if (tPlane > 0.0 && tPlane < min(distance, 100.0)) {
                    vec3 planeHit = rayOrigin + rayDir * tPlane;
                    
                    // Softened the scanner grid lines to prevent aliasing on the plane itself
                    float gridX = smoothstep(0.8, 1.0, fract(planeHit.x * 2.0));
                    float gridZ = smoothstep(0.8, 1.0, fract(planeHit.z * 2.0));
                    float planeGrid = max(gridX, gridZ);
                    
                    vec3 planeLayerColor = u_scanColor * (0.1 + planeGrid * 0.9);
                    float planeAlpha = smoothstep(100.0, 0.0, tPlane) * 0.5 * scanEnvelope;
                    
                    color += planeLayerColor * planeAlpha;
                }
                
                // Vignette
                color *= 1.0 - dot(uv, uv) * 0.5;
                
                gl_FragColor = vec4(color, 1.0);
            }
        `;

        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms
        });

        const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material);
        scene.add(quad);

        // --- LIL-GUI SETUP ---
        const gui = new GUI({ title: 'Scene Configuration' });
        
        const fSystem = gui.addFolder('System & Speed');
        fSystem.add(params, 'dpr', 0.5, 2.0, 0.1).name('Pixel Ratio (DPR)').onChange(v => {
            renderer.setPixelRatio(v);
            uniforms.u_resolution.value.set(window.innerWidth * v, window.innerHeight * v);
        });
        fSystem.add(params, 'flightSpeed', 0.0, 2.0, 0.1).name('Camera Speed').onChange(v => uniforms.u_flightSpeed.value = v);

        const fCamera = gui.addFolder('Camera Settings');
        fCamera.add(params, 'camPosY', 1.0, 20.0, 0.5).name('Altitude').onChange(v => uniforms.u_camPosY.value = v);
        fCamera.add(params, 'camPitch', 0.0, 1.5, 0.05).name('Pitch Angle').onChange(v => uniforms.u_camPitch.value = v);

        const fColors = gui.addFolder('Theme Colors');
        fColors.addColor(params, 'dotColor').name('Dots Color').onChange(v => uniforms.u_dotColor.value.set(v));
        fColors.addColor(params, 'scanColor').name('Scanner Color').onChange(v => uniforms.u_scanColor.value.set(v));
        fColors.addColor(params, 'buildingColor').name('Building Base').onChange(v => uniforms.u_buildingColor.value.set(v));

        const fCity = gui.addFolder('City & Atmosphere');
        fCity.add(params, 'dotDensity', 2.0, 24.0, 1.0).name('Texture Density').onChange(v => uniforms.u_dotDensity.value = v);
        fCity.add(params, 'fogDensity', 0.0, 0.1, 0.001).name('Fog Density').onChange(v => uniforms.u_fogDensity.value = v);

        const fScanner = gui.addFolder('Scanner Effect');
        fScanner.add(params, 'scanSpeed', 0.1, 3.0, 0.1).name('Cycle Speed').onChange(v => uniforms.u_scanSpeed.value = v);

        gui.close();

        // --- WINDOW RESIZE HANDLING ---
        window.addEventListener('resize', () => {
            const width = window.innerWidth;
            const height = window.innerHeight;
            
            renderer.setSize(width, height);
            
            const currentDPR = renderer.getPixelRatio();
            uniforms.u_resolution.value.set(width * currentDPR, height * currentDPR);
        });

        // --- ANIMATION LOOP ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            uniforms.u_time.value += clock.getDelta();
            
            renderer.render(scene, camera);
        }

        animate();