    // Support me by PayPal: https://paypal.com/paypalme/sabosugi 
    // --- SCENE SETUP ---
    const scene = new THREE.Scene();

    // Use an Orthographic camera for a 2D full-screen shader
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    document.body.appendChild(renderer.domElement);

    // --- SHADER MATERIAL ---
    
    // Vertex Shader: Simply passes the UV coordinates to the fragment shader
    const vertexShader = `
        varying vec2 vUv;
        void main() {
            vUv = uv;
            gl_Position = vec4(position, 1.0);
        }
    `;

    // Fragment Shader: Generates the glowing waves
    const fragmentShader = `
        uniform float uTime;
        uniform vec2 uResolution;
        uniform vec3 uColor1; // Primary color (Blue)
        uniform vec3 uColor2; // Secondary color (Pink)
        uniform vec3 uBgColor; // Background color
        uniform float uSpeed;
        uniform float uComplexity; // Drives the number of mathematical iterations
        uniform float uDensity;
        uniform float uIntensity;
        
        // Mouse interaction uniforms
        uniform vec2 uMouse;
        uniform float uHoverEffect;

        varying vec2 vUv;

        // 2D Rotation matrix
        mat2 rot(float a) {
            float s = sin(a), c = cos(a);
            return mat2(c, -s, s, c);
        }

        void main() {
            // Normalize pixel coordinates
            vec2 p = (gl_FragCoord.xy * 2.0 - uResolution.xy) / min(uResolution.x, uResolution.y);
            vec2 original_p = p; // Store original coordinates for the vignette
            
            vec3 finalColor = vec3(0.0);
            float time = uTime * uSpeed * 0.5;
            
            // Add initial cinematic tilt
            p *= rot(0.2);
            
            // --- MOUSE HOVER EFFECT ---
            if (uHoverEffect > 0.0) {
                // Normalize mouse coordinates to match the screen space
                vec2 m = uMouse;
                m.x *= uResolution.x / min(uResolution.x, uResolution.y);
                m.y *= uResolution.y / min(uResolution.x, uResolution.y);
                
                // Apply the same tilt to the mouse coordinates
                m *= rot(0.2);
                
                // Calculate distance between pixel and mouse
                float mouseDist = length(p - m);
                
                // Use smoothstep for a very soft, bounded area of effect
                float force = smoothstep(1.5, 0.0, mouseDist) * uHoverEffect;
                
                // Increased the displacement and twist multipliers to make the effect more visible
                // while keeping (p - m) to prevent the "black hole" singularity in the center
                p += (p - m) * force * 0.15; // Increased from 0.03 for a stronger push
                p *= rot(force * 0.12);      // Increased from 0.02 for a stronger visible twist
            }
            
            // --- ITERATIVE FUNCTION SYSTEM (Complex Formula) ---
            // This loop folds space over itself recursively to create high-detail abstract structures.
            float iterations = floor(uComplexity);
            
            for (float i = 1.0; i <= 20.0; i++) {
                if (i > iterations) break; // Allow dynamic complexity via GUI
                
                // Scale and rotate space organically, but more uniformly to keep lines parallel
                p *= rot(sin(time * 0.05) * 0.1 + 0.08);
                
                // --- HARMONIC VORTEX FLUID ---
                vec2 q = p;
                
                // 1. Smooth Vortex twist: wider, gentler rotation
                float dist = length(p);
                q *= rot(dist * uDensity * 0.25 - time * 0.3);
                
                // 2. Harmonic Folds: Frequencies are mathematically related (1.0x, 2.0x, 0.5x)
                float freq = uDensity * 0.8;
                
                // Layer 1 folds (Base frequency, uniform phase shift per iteration)
                q.x += sin(q.y * freq + time * 0.5 + i * 0.15) * 0.5;
                q.y += cos(q.x * freq - time * 0.5 - i * 0.15) * 0.5;
                
                vec2 r = q;
                // Layer 2 ripples (Double frequency, half amplitude for harmony)
                r.x += sin(q.y * freq * 2.0 - time * 0.8) * 0.25;
                r.y += cos(q.x * freq * 2.0 + time * 0.8) * 0.25;
                
                // Combine into a synchronized, rhythmic ribbon
                float wave = sin(r.x * freq * 1.5 + time) * 0.6 
                           + cos(r.y * freq * 0.5 - time * 0.7) * 0.4;
                
                // Calculate distance to the warped geometric boundary
                float d = abs(r.y - wave);
                
                // Complex rendering layer: Hard core + dual soft ambient glows
                float core = 0.005 / max(d, 0.002);
                float soft1 = exp(-d * 8.0) * 0.6; 
                float soft2 = exp(-d * 2.0) * 0.2; 
                
                // Dynamic Chromatic Dispersion (Color mapping)
                float mixFactor = sin(r.x * 3.0 + r.y * 2.0 + time + i * 1.6) * 0.5 + 0.5;
                vec3 layerColor = mix(uColor1, uColor2, mixFactor);
                
                // Accumulate lighting using additive blending
                float attenuation = 1.0 / (i * 0.6 + 1.0);
                finalColor += layerColor * (core + soft1 + soft2) * uIntensity * attenuation * 30.0;
                
                // Fractal zoom for the next iteration (scales the space)
                p = r * 1.05; 
            }
            
            // --- POST-PROCESSING ---
            
            // 1. Blend with deep background 
            finalColor += uBgColor * 0.5;
            
            // 2. Cinematic Vignette (darken edges)
            float vignette = 1.0 - smoothstep(0.5, 2.5, length(original_p));
            finalColor *= vignette;
            
            // 3. ACES Filmic HDR Tone Mapping (Approximation)
            // This prevents the intense glowing colors from washing out into flat white
            finalColor = finalColor * (2.51 * finalColor + 0.03) / (finalColor * (2.43 * finalColor + 0.59) + 0.14);

            gl_FragColor = vec4(finalColor, 1.0);
        }
    `;

    // Define the uniform variables passed to the shader
    const uniforms = {
        uTime: { value: 0.0 },
        uResolution: { value: new THREE.Vector2(window.innerWidth * window.devicePixelRatio, window.innerHeight * window.devicePixelRatio) },
        uColor1: { value: new THREE.Color('#0055ff') }, // Electric Blue
        uColor2: { value: new THREE.Color('#ff00aa') }, // Hot Pink
        uBgColor: { value: new THREE.Color('#05030a') }, // Very dark violet/black
        uSpeed: { value: 0.3 },
        uComplexity: { value: 8.0 },
        uDensity: { value: 3.2535 },
        uIntensity: { value: 0.03758 },
        uMouse: { value: new THREE.Vector2(0, 0) },
        uHoverEffect: { value: 0.0 } // Disabled by default
    };

    const material = new THREE.ShaderMaterial({
        vertexShader: vertexShader,
        fragmentShader: fragmentShader,
        uniforms: uniforms,
        depthWrite: false,
        depthTest: false
    });

    // Create a full-screen plane to render the shader on
    const geometry = new THREE.PlaneGeometry(2, 2);
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    // --- MOUSE TRACKING LOGIC ---
    
    // Use a target vector to smoothly interpolate the actual mouse position
    const targetMouse = new THREE.Vector2(0, 0);

    function updateMousePosition(clientX, clientY) {
        // Convert mouse position to normalized device coordinates (-1 to +1)
        targetMouse.x = (clientX / window.innerWidth) * 2 - 1;
        targetMouse.y = -(clientY / window.innerHeight) * 2 + 1;
    }

    window.addEventListener('mousemove', (e) => {
        updateMousePosition(e.clientX, e.clientY);
    });

    // Support for touch devices
    window.addEventListener('touchmove', (e) => {
        if (e.touches.length > 0) {
            updateMousePosition(e.touches[0].clientX, e.touches[0].clientY);
        }
    }, { passive: true });

    // --- LIL-GUI SETTINGS PANEL ---
    
    // State object to hold our GUI values
    const settings = {
        speed: 0.3,
        complexity: 8,
        density: 3.2535,
        intensity: 0.03758,
        hoverEffect: false, // Checkbox state
        color1: '#0055ff',
        color2: '#ff00aa',
        bgColor: '#05030a'
    };

    const gui = new lil.GUI({ title: 'Shader Settings' });

    // Animation controls
    const animFolder = gui.addFolder('Complex Formula Settings');
    animFolder.add(settings, 'speed', 0.0, 3.0).name('Speed').onChange(v => uniforms.uSpeed.value = v);
    animFolder.add(settings, 'complexity', 1, 20, 1).name('Math Iterations').onChange(v => uniforms.uComplexity.value = v);
    animFolder.add(settings, 'density', 0.5, 5.0).name('Space Folding').onChange(v => uniforms.uDensity.value = v);
    animFolder.add(settings, 'intensity', 0.001, 0.05).name('Neon Exposure').onChange(v => uniforms.uIntensity.value = v);
    
    // Interactive controls
    const interactiveFolder = gui.addFolder('Interaction');
    interactiveFolder.add(settings, 'hoverEffect').name('Hover Effect').onChange(v => {
        // Smoothly toggle the uniform value between 0.0 and 1.0
        uniforms.uHoverEffect.value = v ? 1.0 : 0.0;
    });

    // Color controls
    const colorFolder = gui.addFolder('Colors');
    colorFolder.addColor(settings, 'color1').name('Primary Color').onChange(v => uniforms.uColor1.value.set(v));
    colorFolder.addColor(settings, 'color2').name('Secondary Color').onChange(v => uniforms.uColor2.value.set(v));
    colorFolder.addColor(settings, 'bgColor').name('Background Color').onChange(v => uniforms.uBgColor.value.set(v));

    // Collapse the main GUI panel by default
    gui.close();

    // --- ANIMATION LOOP ---
    
    const clock = new THREE.Clock();

    function animate() {
        requestAnimationFrame(animate);
        
        // Smoothly interpolate the mouse position (Lerp) for a fluid, dragged effect
        uniforms.uMouse.value.x += (targetMouse.x - uniforms.uMouse.value.x) * 0.05;
        uniforms.uMouse.value.y += (targetMouse.y - uniforms.uMouse.value.y) * 0.05;
        
        // Update time uniform for fluid motion
        uniforms.uTime.value = clock.getElapsedTime();
        
        renderer.render(scene, camera);
    }
    
    // --- RESIZE HANDLER ---
    
    window.addEventListener('resize', () => {
        // Update renderer size
        renderer.setSize(window.innerWidth, window.innerHeight);
        
        // Update resolution uniform for the shader
        uniforms.uResolution.value.set(
            window.innerWidth * window.devicePixelRatio,
            window.innerHeight * window.devicePixelRatio
        );
    });

    // Start the animation loop
    animate();