        import * as THREE from 'three';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
        import GUI from 'lil-gui';

        // --- Configuration Object ---
        const config = {
            // Tunnel & Flight
            flightSpeed: 8.7,
            tunnelRadius: 20.9,
            tunnelLength: 50.0,
            chunkCount: 6,
            strandsPerChunk: 38,
            
            // Lightning Geometry & Digits
            displacement: 0.4802,
            radialNoise: 1.5,
            twistAmount: 0.0,
            detailLevel: 6,
            branchProbability: 0.25,
            numberSize: 5.0,      // Size of the digit particles
            numbersDensity: 0.5439,   // How many digits per unit of distance
            
            // Colors & Effects
            baseColor: '#5099dc', 
            flashColor: '#88ccff', // Bright cyan/blue for active lightning flash
            flashIntensity: 4.0,   
            
            // Timing
            minFlashInterval: 0.6,
            maxFlashInterval: 2.0,
            flashDuration: 0.36955,
            doubleFlashProbability: 0.4, // Chance of a quick double blink
            
            // Bloom parameters
            bloomStrength: 0.97,
            bloomRadius: 0.6,
            bloomThreshold: 0.3,
            
            triggerFlash: () => forceFlash()
        };

        // --- Core Variables ---
        let scene, camera, renderer, composer, bloomPass;
        const chunks = []; 
        let allStrands = []; 
        const scheduledFlashes = []; // Array to handle double blink delays
        
        let timeSinceLastFlash = 0;
        let nextFlashTime = 0;

        const clock = new THREE.Clock();

        // Cached colors
        const colorBase = new THREE.Color(config.baseColor);
        const colorFlash = new THREE.Color(config.flashColor);
        let colorGlow = colorFlash.clone().multiplyScalar(config.flashIntensity);

        // Texture Atlas for Digits
        let digitTexture = null;

        init();
        animate();

        function init() {
            // 1. Scene Setup
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x000000);
            
            // Setup fog perfectly matched with generation boundaries to hide pop-ins
            const fogNear = config.tunnelLength * 2.0;
            const fogFar = config.tunnelLength * (config.chunkCount - 1.0);
            scene.fog = new THREE.Fog(0x000000, fogNear, fogFar);

            // 2. Camera Setup
            camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 0, 0);

            // 3. Renderer Setup
            renderer = new THREE.WebGLRenderer({ antialias: false });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.toneMapping = THREE.ReinhardToneMapping;
            document.body.appendChild(renderer.domElement);

            // 4. Post-processing (Bloom)
            const renderScene = new RenderPass(scene, camera);
            bloomPass = new UnrealBloomPass(
                new THREE.Vector2(window.innerWidth, window.innerHeight),
                config.bloomStrength,
                config.bloomRadius,
                config.bloomThreshold
            );

            const outputPass = new OutputPass();

            composer = new EffectComposer(renderer);
            composer.addPass(renderScene);
            composer.addPass(bloomPass);
            composer.addPass(outputPass);

            // 5. Build Initial Tunnel
            buildTunnel();

            // 6. Event Listeners
            window.addEventListener('resize', onWindowResize);

            // 7. GUI Setup
            setupGUI();

            setNextFlashTime();
        }

        function setupGUI() {
            const gui = new GUI({ title: 'Tunnel Settings' });

            const moveFolder = gui.addFolder('Movement & Shape');
            moveFolder.add(config, 'flightSpeed', 0, 150).name('Flight Speed');
            moveFolder.add(config, 'tunnelRadius', 5, 30).name('Tunnel Radius').onChange(rebuildTunnel);
            moveFolder.add(config, 'twistAmount', 0, Math.PI * 2).name('Twist Amount').onChange(rebuildTunnel);

            const appearanceFolder = gui.addFolder('Lightning Structure');
            appearanceFolder.add(config, 'strandsPerChunk', 2, 50).step(1).name('Strands Density').onChange(rebuildTunnel);
            appearanceFolder.add(config, 'displacement', 0.1, 5.0).name('Jaggedness').onChange(rebuildTunnel);
            appearanceFolder.add(config, 'detailLevel', 3, 8).step(1).name('Detail Level').onChange(rebuildTunnel);
            appearanceFolder.add(config, 'numberSize', 1.0, 50.0).name('Number Size').onChange(v => {
                allStrands.forEach(strand => strand.userData.pointMesh.material.uniforms.uSize.value = v);
            });
            appearanceFolder.add(config, 'numbersDensity', 0.1, 5.0).name('Numbers Density').onChange(rebuildTunnel);
            appearanceFolder.addColor(config, 'baseColor').name('Base Color').onChange(updateColors);
            
            const flashFolder = gui.addFolder('Flash Effects');
            flashFolder.add(config, 'minFlashInterval', 0.05, 2.0).name('Min Interval (s)');
            flashFolder.add(config, 'maxFlashInterval', 0.1, 5.0).name('Max Interval (s)');
            flashFolder.add(config, 'flashDuration', 0.05, 1.0).name('Flash Duration (s)');
            flashFolder.add(config, 'doubleFlashProbability', 0.0, 1.0).name('Double Blink Prob');
            flashFolder.addColor(config, 'flashColor').name('Flash Color').onChange(updateColors);
            flashFolder.add(config, 'triggerFlash').name('Trigger Flash Now');

            const postProcessingFolder = gui.addFolder('Bloom');
            postProcessingFolder.add(config, 'bloomStrength', 0.0, 5.0).name('Strength').onChange(v => bloomPass.strength = v);
            postProcessingFolder.add(config, 'bloomRadius', 0.0, 2.0).name('Radius').onChange(v => bloomPass.radius = v);
            postProcessingFolder.add(config, 'bloomThreshold', 0.0, 1.0).name('Threshold').onChange(v => bloomPass.threshold = v);
            
            gui.close(); // Collapse the GUI by default
        }

        function updateColors() {
            colorBase.set(config.baseColor);
            colorFlash.set(config.flashColor);
            colorGlow.copy(colorFlash).multiplyScalar(config.flashIntensity);
            
            allStrands.forEach(strand => {
                strand.userData.pointMesh.material.uniforms.uColor.value.copy(colorBase);
                strand.userData.lineMesh.material.uniforms.uColor.value.copy(colorGlow);
            });
        }

        // --- Custom Text Generation Logic & Materials ---
        
        function getDigitTexture() {
            if (digitTexture) return digitTexture;
            
            const canvas = document.createElement('canvas');
            canvas.width = 512;
            canvas.height = 64; 
            const ctx = canvas.getContext('2d');
            
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 48px monospace';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            
            for(let i=0; i<10; i++) {
                ctx.fillText(i.toString(), i * 51.2 + 25.6, 32);
            }
            
            digitTexture = new THREE.CanvasTexture(canvas);
            return digitTexture;
        }

        function createDigitMaterial(colorHex) {
            return new THREE.ShaderMaterial({
                uniforms: THREE.UniformsUtils.merge([
                    THREE.UniformsLib['fog'],
                    {
                        digitMap: { value: getDigitTexture() },
                        uColor: { value: new THREE.Color(colorHex) },
                        uOpacity: { value: 1.0 },
                        uSize: { value: config.numberSize }
                    }
                ]),
                fog: true,
                vertexShader: `
                    attribute float digitIndex;
                    attribute float aProgress;
                    varying float vDigitIndex;
                    varying float vProgress;
                    uniform float uSize;
                    
                    #include <fog_pars_vertex>
                    
                    void main() {
                        vDigitIndex = digitIndex;
                        vProgress = aProgress;
                        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
                        
                        // Taper size at start and ends of the lightning branch
                        float taper = smoothstep(0.0, 0.05, aProgress) * smoothstep(1.0, 0.95, aProgress);
                        
                        gl_PointSize = uSize * (100.0 / -mvPosition.z) * max(taper, 0.01);
                        gl_Position = projectionMatrix * mvPosition;
                        
                        #include <fog_vertex>
                    }
                `,
                fragmentShader: `
                    uniform sampler2D digitMap;
                    uniform vec3 uColor;
                    uniform float uOpacity;
                    varying float vDigitIndex;
                    varying float vProgress;
                    
                    #include <fog_pars_fragment>
                    
                    void main() {
                        vec2 uv = vec2(
                            (gl_PointCoord.x + vDigitIndex) / 10.0,
                            1.0 - gl_PointCoord.y 
                        );
                        
                        vec4 texColor = texture2D(digitMap, uv);
                        if (texColor.a < 0.1) discard;
                        
                        // Taper opacity at ends to make branches look thinner
                        float taper = smoothstep(0.0, 0.05, vProgress) * smoothstep(1.0, 0.95, vProgress);
                        gl_FragColor = vec4(uColor, uOpacity * texColor.a * taper);
                        
                        #include <fog_fragment>
                    }
                `,
                transparent: true,
                depthWrite: false,
                blending: THREE.NormalBlending
            });
        }

        function createLineMaterial(baseColorObj) {
            return new THREE.ShaderMaterial({
                uniforms: THREE.UniformsUtils.merge([
                    THREE.UniformsLib['fog'],
                    {
                        uColor: { value: baseColorObj.clone() },
                        uOpacity: { value: 0.0 }
                    }
                ]),
                fog: true,
                vertexShader: `
                    attribute float aProgress;
                    varying float vProgress;
                    
                    #include <fog_pars_vertex>
                    
                    void main() {
                        vProgress = aProgress;
                        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
                        gl_Position = projectionMatrix * mvPosition;
                        
                        #include <fog_vertex>
                    }
                `,
                fragmentShader: `
                    uniform vec3 uColor;
                    uniform float uOpacity;
                    varying float vProgress;
                    
                    #include <fog_pars_fragment>
                    
                    void main() {
                        // Taper flash glow at the ends
                        float taper = smoothstep(0.0, 0.05, vProgress) * smoothstep(1.0, 0.95, vProgress);
                        gl_FragColor = vec4(uColor, uOpacity * taper);
                        
                        #include <fog_fragment>
                    }
                `,
                transparent: true,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            });
        }

        function createPointsGeometry(lineGeometry) {
            const posArray = lineGeometry.attributes.position.array;
            const progressArray = lineGeometry.attributes.aProgress.array;
            const ptPositions = [];
            const ptDigits = [];
            const ptProgresses = [];

            for (let j = 0; j < posArray.length; j += 6) {
                const p1 = new THREE.Vector3(posArray[j], posArray[j+1], posArray[j+2]);
                const p2 = new THREE.Vector3(posArray[j+3], posArray[j+4], posArray[j+5]);
                
                // Fetch progress values for this segment's start and end
                const t1 = progressArray[j/3];
                const t2 = progressArray[j/3 + 1];
                
                const dist = p1.distanceTo(p2);
                const numPoints = Math.max(1, Math.floor(dist * config.numbersDensity));

                for(let k = 0; k < numPoints; k++) {
                    const lerpFactor = k / numPoints;
                    const pt = p1.clone().lerp(p2, lerpFactor);
                    const ptT = t1 + (t2 - t1) * lerpFactor; // Interpolate structural progress
                    
                    ptPositions.push(pt.x, pt.y, pt.z);
                    ptDigits.push(Math.floor(Math.random() * 10));
                    ptProgresses.push(ptT);
                }
            }

            const pointGeo = new THREE.BufferGeometry();
            pointGeo.setAttribute('position', new THREE.Float32BufferAttribute(ptPositions, 3));
            pointGeo.setAttribute('digitIndex', new THREE.Float32BufferAttribute(ptDigits, 1));
            pointGeo.setAttribute('aProgress', new THREE.Float32BufferAttribute(ptProgresses, 1));
            return pointGeo;
        }

        // --- Tunnel Generation Logic ---

        function buildTunnel() {
            scheduledFlashes.length = 0; // Clear pending double blinks
            chunks.forEach(chunk => {
                scene.remove(chunk.group);
                chunk.group.children.forEach(strandGroup => {
                    strandGroup.userData.lineMesh.geometry.dispose();
                    strandGroup.userData.lineMesh.material.dispose();
                    strandGroup.userData.pointMesh.geometry.dispose();
                    strandGroup.userData.pointMesh.material.dispose();
                });
            });
            chunks.length = 0;
            allStrands.length = 0;

            for (let i = 0; i < config.chunkCount; i++) {
                const zOffset = -i * config.tunnelLength;
                createChunk(zOffset);
            }
        }

        function rebuildTunnel() {
            camera.position.set(0, 0, 0); 
            buildTunnel();
        }

        function createChunk(zPos) {
            const group = new THREE.Group();
            group.position.z = zPos;

            for (let i = 0; i < config.strandsPerChunk; i++) {
                const geometry = generateCylindricalLightning(config);
                
                // Light Flash Lines (Hidden by default via uniform uOpacity = 0.0)
                const lineMat = createLineMaterial(colorGlow);
                const lineMesh = new THREE.LineSegments(geometry, lineMat);

                // Digit Particles
                const pointGeo = createPointsGeometry(geometry);
                const pointMat = createDigitMaterial(config.baseColor);
                const pointMesh = new THREE.Points(pointGeo, pointMat);

                const strandGroup = new THREE.Group();
                strandGroup.add(lineMesh);
                strandGroup.add(pointMesh);
                
                strandGroup.userData = {
                    flashValue: 0.0,
                    lineMesh: lineMesh,
                    pointMesh: pointMesh
                };

                group.add(strandGroup);
                allStrands.push(strandGroup);
            }

            scene.add(group);
            chunks.push({ group: group });
        }

        function regenerateChunkGeometry(chunk) {
            chunk.group.children.forEach(strandGroup => {
                const lineMesh = strandGroup.userData.lineMesh;
                const pointMesh = strandGroup.userData.pointMesh;

                lineMesh.geometry.dispose();
                pointMesh.geometry.dispose();

                const newGeometry = generateCylindricalLightning(config);
                lineMesh.geometry = newGeometry;
                pointMesh.geometry = createPointsGeometry(newGeometry);
                
                strandGroup.userData.flashValue = 0;
                lineMesh.material.uniforms.uOpacity.value = 0.0;
                pointMesh.material.uniforms.uOpacity.value = 1.0;
            });
        }

        function generateCylindricalLightning(cfg) {
            const startAngle = Math.random() * Math.PI * 2;
            const endAngle = startAngle + (Math.random() - 0.5) * cfg.twistAmount;

            const start = new THREE.Vector3(
                Math.cos(startAngle) * cfg.tunnelRadius, 
                Math.sin(startAngle) * cfg.tunnelRadius, 
                0
            );
            const end = new THREE.Vector3(
                Math.cos(endAngle) * cfg.tunnelRadius, 
                Math.sin(endAngle) * cfg.tunnelRadius, 
                -cfg.tunnelLength
            );

            // Added structural progress trackers (tStart, tEnd)
            let segments = [{ start: start, end: end, generation: 0, tStart: 0.0, tEnd: 1.0 }];
            
            for (let i = 0; i < cfg.detailLevel; i++) {
                let nextSegments = [];
                for (let seg of segments) {
                    const p1 = seg.start;
                    const p2 = seg.end;

                    const mid = p1.clone().lerp(p2, 0.5);
                    const direction = p2.clone().sub(p1).normalize();
                    const length = p1.distanceTo(p2);
                    
                    const tMid = seg.tStart + (seg.tEnd - seg.tStart) * 0.5;

                    const randomVec = new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5);
                    const perpendicular = randomVec.cross(direction).normalize();
                    const offset = perpendicular.multiplyScalar((Math.random() - 0.5) * length * cfg.displacement);
                    mid.add(offset);

                    const currentRad = Math.sqrt(mid.x * mid.x + mid.y * mid.y);
                    const targetRad = cfg.tunnelRadius + (Math.random() - 0.5) * cfg.radialNoise; 
                    const scale = targetRad / currentRad;
                    mid.x *= scale;
                    mid.y *= scale;

                    nextSegments.push({ start: p1, end: mid, generation: seg.generation + 1, tStart: seg.tStart, tEnd: tMid });
                    nextSegments.push({ start: mid, end: p2, generation: seg.generation + 1, tStart: tMid, tEnd: seg.tEnd });

                    if (Math.random() < cfg.branchProbability && seg.generation < cfg.detailLevel - 2) {
                        const branchDir = direction.clone();
                        branchDir.applyAxisAngle(new THREE.Vector3(0, 0, 1), (Math.random() - 0.5) * 1.5);
                        branchDir.applyAxisAngle(direction, Math.random() * Math.PI * 2);

                        const branchLength = length * (0.6 + Math.random() * 0.4);
                        const branchEnd = mid.clone().add(branchDir.multiplyScalar(branchLength));
                        
                        const brCurrentRad = Math.sqrt(branchEnd.x * branchEnd.x + branchEnd.y * branchEnd.y);
                        const brTargetRad = cfg.tunnelRadius + (Math.random() - 0.5) * cfg.radialNoise;
                        const brScale = brTargetRad / brCurrentRad;
                        branchEnd.x *= brScale;
                        branchEnd.y *= brScale;

                        // Branch gets its own path to 1.0 (to taper correctly at the tip)
                        nextSegments.push({ start: mid, end: branchEnd, generation: seg.generation + 1, tStart: tMid, tEnd: 1.0 });
                    }
                }
                segments = nextSegments;
            }

            const positions = [];
            const progresses = [];
            for (let seg of segments) {
                positions.push(seg.start.x, seg.start.y, seg.start.z);
                progresses.push(seg.tStart);
                
                positions.push(seg.end.x, seg.end.y, seg.end.z);
                progresses.push(seg.tEnd);
            }

            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
            geometry.setAttribute('aProgress', new THREE.Float32BufferAttribute(progresses, 1));
            return geometry;
        }

        // --- Animation & Effects Logic ---

        function setNextFlashTime() {
            nextFlashTime = config.minFlashInterval + Math.random() * (config.maxFlashInterval - config.minFlashInterval);
            timeSinceLastFlash = 0;
        }

        function forceFlash() {
            if (allStrands.length === 0) return;
            
            const randomIndex = Math.floor(Math.random() * allStrands.length);
            const targetStrand = allStrands[randomIndex];
            
            targetStrand.userData.flashValue = 1.0;

            // Handle realistic double blink effect
            if (Math.random() < config.doubleFlashProbability) {
                // Trigger the second flash just before the first one finishes fading
                const delay = config.flashDuration * 0.45; 
                scheduledFlashes.push({
                    triggerTime: clock.getElapsedTime() + delay,
                    strand: targetStrand
                });
            }

            setNextFlashTime();
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        }

        function animate() {
            requestAnimationFrame(animate);

            const delta = clock.getDelta();
            const time = clock.getElapsedTime();

            // Move Camera Forward
            camera.position.z -= config.flightSpeed * delta;

            camera.position.x = Math.sin(time * 0.5) * 2.0;
            camera.position.y = Math.cos(time * 0.4) * 2.0;

            chunks.forEach(chunk => {
                if (chunk.group.position.z > camera.position.z + config.tunnelLength) {
                    chunk.group.position.z -= config.tunnelLength * config.chunkCount;
                    regenerateChunkGeometry(chunk);
                }
            });

            timeSinceLastFlash += delta;
            if (timeSinceLastFlash >= nextFlashTime) {
                forceFlash();
            }

            // Handle Scheduled Flashes (Double Blinks)
            for (let i = scheduledFlashes.length - 1; i >= 0; i--) {
                if (time >= scheduledFlashes[i].triggerTime) {
                    scheduledFlashes[i].strand.userData.flashValue = 1.0; // Flash again!
                    scheduledFlashes.splice(i, 1);
                }
            }

            // Update Flashes
            allStrands.forEach(strandGroup => {
                const lineMesh = strandGroup.userData.lineMesh;
                const pointMesh = strandGroup.userData.pointMesh;

                if (strandGroup.userData.flashValue > 0) {
                    strandGroup.userData.flashValue -= delta / config.flashDuration;
                    
                    if (strandGroup.userData.flashValue <= 0) {
                        strandGroup.userData.flashValue = 0;
                        lineMesh.material.uniforms.uOpacity.value = 0.0;
                        pointMesh.material.uniforms.uOpacity.value = 1.0;
                    } else {
                        lineMesh.material.uniforms.uOpacity.value = strandGroup.userData.flashValue;
                        pointMesh.material.uniforms.uOpacity.value = 1.0 - (strandGroup.userData.flashValue * 0.5);
                    }
                }
            });

            composer.render();
        }