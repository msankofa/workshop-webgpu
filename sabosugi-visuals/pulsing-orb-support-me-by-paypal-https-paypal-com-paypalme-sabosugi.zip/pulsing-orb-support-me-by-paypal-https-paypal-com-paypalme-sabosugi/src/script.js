        import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- Core Application State & Config ---
        const config = {
            dpr: 1.0,
            timeScale: 1.0,
            autoRotate: false,
            rotationSpeed: 1.0,
            iterations: 20,
            distortion: 2.2,
            pulseIntensity: 2.5,
            // Negative colors are mathematically valid in this specific shader formula
            colorR: 1.6,
            colorG: -0.8,
            colorB: -2.0,
            reset: function() {
                this.dpr = 1.0;
                this.timeScale = 1.0;
                this.autoRotate = false;
                this.rotationSpeed = 1.0;
                this.iterations = 15;
                this.distortion = 2.0;
                this.pulseIntensity = 2.5;
                this.colorR = 1.6;
                this.colorG = -0.8;
            this.colorB = -2.0;
            targetZoom = 4.5;
            orbRotation.identity();
            pointerState.velocityX = 0;
            pointerState.velocityY = 0;
            renderer.setPixelRatio(this.dpr);
            gui.controllersRecursive().forEach(c => c.updateDisplay());
        }
    };

    // --- Custom Drag & Rotation State ---
    let targetZoom = 4.5;
    const pointerState = {
        isDragging: false,
        previousX: 0,
        previousY: 0,
        velocityX: 0,
        velocityY: 0,
        pinchDistance: 0
    };
    const orbRotation = new THREE.Quaternion();
    const inverseRotationMatrix = new THREE.Matrix3();

    // --- Three.js Setup ---
    const container = document.getElementById('canvas-container');
    
    // We use an Orthographic camera to render the fullscreen quad
    const renderCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const scene = new THREE.Scene();

    const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: false });
    renderer.setPixelRatio(config.dpr);
    renderer.setSize(window.innerWidth, window.innerHeight);
    container.appendChild(renderer.domElement);

    // --- Custom Interaction Logic (Replaces OrbitControls) ---
    const domElement = renderer.domElement;
    
    domElement.addEventListener('pointerdown', (e) => {
        if (e.pointerType === 'touch') return; // Ignore touch here to prevent double-firing
        pointerState.isDragging = true;
        pointerState.previousX = e.clientX;
        pointerState.previousY = e.clientY;
        pointerState.velocityX = 0;
        pointerState.velocityY = 0;
    });
    
    domElement.addEventListener('pointermove', (e) => {
        if (e.pointerType === 'touch') return;
        if (!pointerState.isDragging) return;
        const deltaX = e.clientX - pointerState.previousX;
        const deltaY = e.clientY - pointerState.previousY;
        pointerState.velocityX = deltaX * 0.005;
        pointerState.velocityY = deltaY * 0.005;
        pointerState.previousX = e.clientX;
        pointerState.previousY = e.clientY;
    });
    
    domElement.addEventListener('pointerup', (e) => {
        if (e.pointerType === 'touch') return;
        pointerState.isDragging = false;
    });
    domElement.addEventListener('pointerleave', (e) => {
        if (e.pointerType === 'touch') return;
        pointerState.isDragging = false;
    });
    
    domElement.addEventListener('wheel', (e) => {
        targetZoom += e.deltaY * 0.005;
        targetZoom = Math.max(2.0, Math.min(8.0, targetZoom));
    });
    
    domElement.addEventListener('touchstart', (e) => {
        e.preventDefault();
        if (e.touches.length === 1) {
            pointerState.isDragging = true;
            pointerState.previousX = e.touches[0].clientX;
            pointerState.previousY = e.touches[0].clientY;
            pointerState.velocityX = 0;
            pointerState.velocityY = 0;
        } else if (e.touches.length === 2) {
            pointerState.isDragging = false;
            pointerState.pinchDistance = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );
        }
    }, { passive: false });
    
    domElement.addEventListener('touchmove', (e) => {
        e.preventDefault();
        if (e.touches.length === 2) {
            const currentDist = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );
            const delta = pointerState.pinchDistance - currentDist;
            targetZoom += delta * 0.02;
            targetZoom = Math.max(2.0, Math.min(8.0, targetZoom));
            pointerState.pinchDistance = currentDist;
        } else if (e.touches.length === 1 && pointerState.isDragging) {
            const deltaX = e.touches[0].clientX - pointerState.previousX;
            const deltaY = e.touches[0].clientY - pointerState.previousY;
            pointerState.velocityX = deltaX * 0.008; // Increased sensitivity for mobile screens
            pointerState.velocityY = deltaY * 0.008;
            pointerState.previousX = e.touches[0].clientX;
            pointerState.previousY = e.touches[0].clientY;
        }
    }, { passive: false });

    // Handle touch end logic to correctly maintain inertia and reset dragging state
    domElement.addEventListener('touchend', (e) => {
        e.preventDefault();
        if (e.touches.length === 0) {
            pointerState.isDragging = false;
        } else if (e.touches.length === 1) {
            pointerState.isDragging = true;
            pointerState.previousX = e.touches[0].clientX;
            pointerState.previousY = e.touches[0].clientY;
        }
    }, { passive: false });

    domElement.addEventListener('touchcancel', () => {
        pointerState.isDragging = false;
    });

    // --- Shader Material ---
    const vertexShader = `
            void main() {
                // Fullscreen NDC quad
                gl_Position = vec4(position.xy, 0.0, 1.0);
            }
        `;

        const fragmentShader = `
        uniform vec2 iResolution;
        uniform float iTime;
        uniform vec3 uCameraPos;
        uniform mat3 uInverseRot;
        
        uniform int uIterations;
            uniform float uDistortion;
            uniform vec3 uColorBase;
            uniform float uPulseIntensity;

            // Global phase tracker for the fractal iterations used in material shading
            float g_materialPhase = 1.0;

            // Global alignment offset to center the fractal inside the glass sphere.
            const vec3 ALIGNMENT_OFFSET = vec3(0.0, 0.0, 0.0);

            // Generates a standard 2D rotation matrix
            mat2 createRotationMatrix(float angle) {
                float sineValue = sin(angle);
                float cosineValue = cos(angle);
                return mat2(cosineValue, sineValue, -sineValue, cosineValue);
            }

            // Pseudo-random noise generator to apply dithering and prevent banding
            float generateDitherValue(vec2 seedPos) {
                vec3 hashVector = fract(vec3(seedPos.xyx) * 0.8431);
                hashVector += dot(hashVector, hashVector.yzx + 48.55);
                return fract((hashVector.x + hashVector.y) * hashVector.z);
            }

            // Mathematical Ray-Sphere Intersection
            vec2 intersectSphere(vec3 ro, vec3 rd, vec3 center, float radius) {
                vec3 oc = ro - center;
                float b = dot(oc, rd);
                float c = dot(oc, oc) - radius * radius;
                float h = b * b - c;
                
                if (h < 0.0) return vec2(-1.0); 
                
                h = sqrt(h);
                return vec2(-b - h, -b + h);
            }

            // Evaluates the signed distance field (SDF) of the fractal scene
            float evaluateSceneSDF(vec3 samplePoint) {
                samplePoint.yz *= createRotationMatrix(0.4);
                samplePoint.xz *= createRotationMatrix(iTime * 0.4);
                
                float minSurfaceDist = 125.4;
                samplePoint *= 0.2;
                
                for (int iteration = 0; iteration < 30; ++iteration) {
                    if (iteration >= uIterations) break; // Controlled via GUI
                    
                    float fIteration = float(iteration) + 55.0;
                    
                    samplePoint.xy = abs(samplePoint.xy) - 0.00;
                    samplePoint.xy = sin(samplePoint.xy * uDistortion);
                    
                    samplePoint.xy *= createRotationMatrix(0.5);
                    samplePoint.xz *= createRotationMatrix(0.7);
                    
                    float boxDist = max(abs(samplePoint.x), abs(samplePoint.y));
                    float currentDist = mix(length(samplePoint.xy), boxDist, 0.0) + 0.07;
                    
                    if (iteration > 0) {
                        minSurfaceDist = min(minSurfaceDist, currentDist);
                    }
                    
                    if (minSurfaceDist == currentDist) {
                        g_materialPhase = fIteration;
                    }
                }
                
                return minSurfaceDist * 0.3;
            }

            // Performs volumetric raymarching strictly bounded within a spherical volume
            vec3 renderVolumetricGlow(vec3 rayOrigin, vec3 rayDir) {
                vec3 sphereCenter = vec3(0.0, 0.0, 0.0);
                float sphereRadius = 1.3;
                
                vec2 hit = intersectSphere(rayOrigin, rayDir, sphereCenter, sphereRadius);
                if (hit.x < 0.0 && hit.y < 0.0) return vec3(0.0);
                
                float tEnter = max(0.0, hit.x);
                float tExit = hit.y;
                float surfaceDistance = 1.8;
                float rayLength = tEnter + generateDitherValue(gl_FragCoord.xy + iTime) * 0.1;
                
                vec3 accumulatedColor = vec3(0.0);
                vec3 currentPos = vec3(0.8);
                
                const int MAX_STEPS = 75;
                
                for (int stepIndex = 0; stepIndex < MAX_STEPS; stepIndex++) {
                    currentPos = rayOrigin + rayDir * rayLength;
                    vec3 centeredPos = currentPos + ALIGNMENT_OFFSET;
                    
                    surfaceDistance = abs(evaluateSceneSDF(centeredPos));
                    
                    float stepDist = max(0.015, surfaceDistance);
                    rayLength += stepDist;
                    
                    if (rayLength > tExit) break;
                    
                    // Dynamic color base from GUI
                    vec3 emissionTint = uColorBase;
                    
                    float colorAngle = (g_materialPhase * 0.02) + (iTime * 0.3);
                    vec2 rotatedChannels = createRotationMatrix(colorAngle) * emissionTint.rb;
                    emissionTint.r = rotatedChannels.x;
                    emissionTint.b = rotatedChannels.y;
                    
                    emissionTint = normalize(1.0 + emissionTint);
                    
                    emissionTint *= exp(0.14 * rayLength);
                    emissionTint *= exp(1.0 * length(centeredPos));
                    emissionTint /= (80.0 + surfaceDistance * 1500.0);
                    
                    float wavePhase = (length(centeredPos) * 0.05) - (iTime * 0.03) + (g_materialPhase * 0.56);
                    float pulseIntensity = abs(pow(abs(fract(wavePhase) - 0.50) * 2.0, 68.4));
                    
                    float dataStripe = step(0.0, fract(centeredPos.z * 20.0 - iTime * 2.1));
                    pulseIntensity += dataStripe * 0.0; 
                    
                    emissionTint *= (0.2 + pulseIntensity * uPulseIntensity);
                    
                    accumulatedColor += emissionTint;
                    accumulatedColor += exp(-4.9 * length(centeredPos)) * 0.07;
                }
                
                vec3 exitNormal = normalize((rayOrigin + rayDir * tExit) - sphereCenter);
                float rimLight = pow(1.0 - max(dot(-rayDir, exitNormal), 0.0), 4.6);
                
                // Preserved specific user requested logic
                accumulatedColor += vec3(0.000, 0.000, 0.000) * rimLight;
                
                return accumulatedColor;
            }

            void main() {
                // Map fragCoord to NDC for aspect-correct ray projection
                vec2 screenUV = (gl_FragCoord.xy - iResolution.xy * 0.5) / iResolution.y;
                
                // Locked camera geometry, dynamically rotated space
                vec3 rayOrigin = vec3(0.0, 0.0, uCameraPos.z);
                vec3 rayDir = normalize(vec3(screenUV, -1.2));
                
                // Apply user interaction rotation directly to the rays
                rayOrigin = uInverseRot * rayOrigin;
                rayDir = uInverseRot * rayDir;
                
                vec3 finalOutput = renderVolumetricGlow(rayOrigin, rayDir);
                
                gl_FragColor = vec4(finalOutput, 1.0);
            }
        `;

        const material = new THREE.ShaderMaterial({
            vertexShader: vertexShader,
            fragmentShader: fragmentShader,
            uniforms: {
                iResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
                iTime: { value: 0.0 },
                uCameraPos: { value: new THREE.Vector3(0, 0, 4.5) },
                uInverseRot: { value: new THREE.Matrix3() },
                uIterations: { value: config.iterations },
                uDistortion: { value: config.distortion },
                uColorBase: { value: new THREE.Vector3(config.colorR, config.colorG, config.colorB) },
                uPulseIntensity: { value: config.pulseIntensity }
            },
            depthWrite: false,
            depthTest: false
        });

        const mesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material);
        scene.add(mesh);

        // --- Settings Panel Integration (lil-gui) ---
        const gui = new GUI({ title: 'Quantum Orb Settings' });
        
        const sysFolder = gui.addFolder('System & Camera');
        sysFolder.add(config, 'dpr', 0.5, 2.0, 0.1).name('Pixel Ratio (DPR)').onChange(v => renderer.setPixelRatio(v));
        sysFolder.add(config, 'timeScale', 0.0, 3.0, 0.1).name('Time Scale');
        sysFolder.add(config, 'autoRotate').name('Auto Orbit');
        sysFolder.add(config, 'rotationSpeed', 0.1, 5.0, 0.1).name('Orbit Speed');
        
        const fracFolder = gui.addFolder('Fractal Architecture');
        fracFolder.add(config, 'iterations', 1, 30, 1).name('Complexity Steps').onChange(v => material.uniforms.uIterations.value = v);
        fracFolder.add(config, 'distortion', 0.5, 5.0, 0.1).name('Fluid Distortion').onChange(v => material.uniforms.uDistortion.value = v);
        
        const colorFolder = gui.addFolder('Color Math & Glow');
        colorFolder.add(config, 'pulseIntensity', 0.0, 10.0, 0.1).name('Pulse Power').onChange(v => material.uniforms.uPulseIntensity.value = v);
        colorFolder.add(config, 'colorR', -5.0, 5.0, 0.1).name('Red Offset').onChange(v => material.uniforms.uColorBase.value.x = v);
        colorFolder.add(config, 'colorG', -5.0, 5.0, 0.1).name('Green Offset').onChange(v => material.uniforms.uColorBase.value.y = v);
        colorFolder.add(config, 'colorB', -5.0, 5.0, 0.1).name('Blue Offset').onChange(v => material.uniforms.uColorBase.value.z = v);
        
        gui.add(config, 'reset').name('Reset Default');
        
        // Hide UI by default per user request
        gui.close();

        // --- Resize Handler ---
        window.addEventListener('resize', () => {
            renderer.setSize(window.innerWidth, window.innerHeight);
            material.uniforms.iResolution.value.set(window.innerWidth, window.innerHeight);
        }, false);

        // --- Main Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            const delta = clock.getDelta();
            
            // Handle Custom Inertia and Auto-Rotation
            if (!pointerState.isDragging) {
                pointerState.velocityX *= 0.94; // Inertia damping
                pointerState.velocityY *= 0.94;
            }
            if (config.autoRotate) {
                pointerState.velocityX -= 0.001 * config.rotationSpeed;
            }
            
            // Apply continuous rotation to quaternion
            if (Math.abs(pointerState.velocityX) > 0.0001 || Math.abs(pointerState.velocityY) > 0.0001) {
                const rotationLength = Math.hypot(pointerState.velocityX, pointerState.velocityY);
                const q = new THREE.Quaternion().setFromAxisAngle(
                    new THREE.Vector3(pointerState.velocityY, pointerState.velocityX, 0).normalize(),
                    rotationLength
                );
                orbRotation.premultiply(q);
                orbRotation.normalize();
            }
            
            // Pass inverse rotation matrix to the shader
            const invRot = orbRotation.clone().invert();
            inverseRotationMatrix.setFromMatrix4(new THREE.Matrix4().makeRotationFromQuaternion(invRot));
            
            // Update Shader Uniforms
            material.uniforms.iTime.value += delta * config.timeScale;
            material.uniforms.uInverseRot.value.copy(inverseRotationMatrix);
            material.uniforms.uCameraPos.value.z = targetZoom;

            // Render fullscreen quad
            renderer.render(scene, renderCamera);
        }

        animate();