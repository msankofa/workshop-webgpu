        import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- Scene Setup ---
        const canvas = document.createElement('canvas');
        document.body.appendChild(canvas);

        const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: false });
        renderer.setSize(window.innerWidth, window.innerHeight);

        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        const scene = new THREE.Scene();

        // --- Shader Uniforms ---
        const uniforms = {
            iTime: { value: 0 },
            iResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            uMouseRot: { value: new THREE.Vector2(0, 0) },
            uFractalSpeed: { value: 1.0 },
            uRotationSpeed: { value: 0.5 },
            uPlasmaDensity: { value: 0.05 },
            uShapeStretch: { value: 0.65 },
            uShapeSize: { value: 2.7 },
            uColorPlasma: { value: new THREE.Color(0xffffff) }, 
            uColorFrame: { value: new THREE.Color(0xeef1ff) }
        };

        // --- GLSL Shader Material ---
        const material = new THREE.ShaderMaterial({
            vertexShader: `
                void main() {
                    gl_Position = vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform float iTime;
                uniform vec2 iResolution;
                uniform vec2 uMouseRot;
                uniform float uFractalSpeed;
                uniform float uRotationSpeed;
                uniform float uPlasmaDensity;
                uniform float uShapeStretch;
                uniform float uShapeSize;
                uniform vec3 uColorPlasma;
                uniform vec3 uColorFrame;

                const mat3 NOISE_TRANSFORM = mat3(
                    -0.21,  1.33,  0.52,
                     0.72, 0.52,  1.67,
                     0.77,  0.49,  0.18
                );

                float calculateNoise(vec3 pos) {
                    vec3 a = cos(NOISE_TRANSFORM * pos);
                    vec3 b = sin(17.1 * pos * NOISE_TRANSFORM);
                    return dot(a, b);
                }

                mat2 getRotationMatrix(float theta) {
                    float c = cos(theta);
                    float s = sin(theta);
                    return mat2(c, -s, s, c);
                }

                vec2 normalizeCoordinates(vec2 fragCoord, vec2 resolution) {
                    return (fragCoord * 2.0 - resolution.xy) / resolution.y;
                }

                void main() {
                    vec2 fragCoord = gl_FragCoord.xy;
                    vec2 uv = normalizeCoordinates(fragCoord, iResolution.xy);
                    uv *= 0.8; 

                    vec4 colorAccumulator = vec4(0.0);
                    float totalDistance = 0.0;
                    float globalTime = iTime;

                    for (int i = 0; i < 130; i++) {
                        float iterationFloat = float(i);
                        vec3 p = vec3(uv * totalDistance, totalDistance);
                        vec3 localPos = p;
                        
                        localPos.z -= 6.0; 
                        localPos.y -= sin(globalTime * 1.0) * 0.1; 
                        
                        localPos.xz *= getRotationMatrix(globalTime * 0.5 * uRotationSpeed + uMouseRot.x);
                        localPos.yz *= getRotationMatrix(sin(globalTime * 0.3) * 0.1 + uMouseRot.y);

                        vec3 shapePos = localPos;
                        shapePos.y *= uShapeStretch; 

                        // Use uShapeSize uniform for dynamic scaling
                        float bounds = ((abs(shapePos.x) + abs(shapePos.y) + abs(shapePos.z)) - uShapeSize) * 0.45;

                        if (bounds > 0.005) {
                            totalDistance += bounds;
                        } else {
                            vec3 noisePos = localPos; 
                            float timeOffset = globalTime * 0.1 * uFractalSpeed;
                            float wavePerturbation = sin(noisePos.z * 3.1 + noisePos.x * 1.7 + timeOffset) * -0.076 + -0.011;
                            
                            float noiseHighFreq = calculateNoise(noisePos / 1.0 + globalTime * 0.2 * uFractalSpeed);
                            float noiseLowFreq = calculateNoise(noisePos / 4.5 + globalTime * 0.13 * uFractalSpeed) * 0.8;
                            
                            float noiseVal = wavePerturbation + abs(noiseHighFreq - noiseLowFreq);
                            float surfaceDist = abs(bounds);
                            float edgeDist = min(abs(shapePos.x), min(abs(shapePos.y), abs(shapePos.z)));

                            float edgeProximity = smoothstep(0.15, 0.0, edgeDist) * smoothstep(0.25, 0.0, surfaceDist);
                            float stepWithNoise = 0.02 + noiseVal * uPlasmaDensity;
                            float currentStep = mix(stepWithNoise, 0.015, edgeProximity);

                            float lineThickness = 0.04;
                            float lineIntensity = smoothstep(lineThickness, 0.01, edgeDist) * smoothstep(0.02, -0.1, surfaceDist);
                            
                            vec4 frameColor = vec4(uColorFrame, 1.0) * lineIntensity * 12.1;
                            vec4 baseColor = vec4(-3.0, 0.80, 2.8, 1.1);
                            vec4 glowColor = baseColor * cos(iterationFloat * 0.034) + iterationFloat * 0.017;
                            glowColor.rgb *= uColorPlasma; 

                            colorAccumulator += (glowColor + frameColor) / (currentStep * currentStep * 150000.0);
                            totalDistance += currentStep;
                        }
                        if (totalDistance > 12.0) break;
                    }
                    gl_FragColor = colorAccumulator;
                }
            `,
            uniforms: uniforms
        });

        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- Mouse Interaction ---
        let isDragging = false;
        let previousMousePosition = { x: 0, y: 0 };
        let targetRotation = { x: 0, y: 0 };
        const rotationSensitivity = 0.006;

        window.addEventListener('mousedown', (e) => {
            isDragging = true;
            previousMousePosition = { x: e.clientX, y: e.clientY };
        });

        window.addEventListener('mousemove', (e) => {
            if (isDragging) {
                const deltaMove = {
                    x: e.clientX - previousMousePosition.x,
                    y: e.clientY - previousMousePosition.y
                };
                
                targetRotation.x -= deltaMove.x * rotationSensitivity;
                // Inverted vertical rotation logic (deltaMove.y is added instead of subtracted)
                targetRotation.y += deltaMove.y * rotationSensitivity;
                
                previousMousePosition = { x: e.clientX, y: e.clientY };
            }
        });

        window.addEventListener('mouseup', () => { isDragging = false; });
        window.addEventListener('mouseleave', () => { isDragging = false; });

        window.addEventListener('resize', () => {
            renderer.setSize(window.innerWidth, window.innerHeight);
            uniforms.iResolution.value.set(window.innerWidth, window.innerHeight);
        });

        // --- lil-gui Setup ---
        const gui = new GUI({ title: 'Scene Settings' });
        const params = {
            dpr: 1.0,
            shapeSize: 2.7,
            fractalSpeed: 1.0,
            rotationSpeed: 0.5,
            plasmaDensity: 0.05,
            shapeStretch: 0.65,
            colorPlasma: '#ffffff',
            colorFrame: '#eef1ff'
        };

        renderer.setPixelRatio(params.dpr);

        gui.add(params, 'dpr', 0.5, 2.0, 0.1).name('Device Pixel Ratio').onChange(v => renderer.setPixelRatio(v));
        gui.add(params, 'shapeSize', 1.0, 5.0).name('Shape Size').onChange(v => uniforms.uShapeSize.value = v);
        gui.add(params, 'fractalSpeed', 0.0, 3.0).name('Fractal Speed').onChange(v => uniforms.uFractalSpeed.value = v);
        gui.add(params, 'rotationSpeed', 0.0, 5.0).name('Auto Rotation').onChange(v => uniforms.uRotationSpeed.value = v);
        gui.add(params, 'plasmaDensity', 0.01, 0.1).name('Plasma Density').onChange(v => uniforms.uPlasmaDensity.value = v);
        gui.add(params, 'shapeStretch', 0.3, 1.5).name('Vertical Stretch').onChange(v => uniforms.uShapeStretch.value = v);
        gui.addColor(params, 'colorPlasma').name('Plasma Tint').onChange(v => uniforms.uColorPlasma.value.set(v));
        gui.addColor(params, 'colorFrame').name('Frame Color').onChange(v => uniforms.uColorFrame.value.set(v));
        
        gui.close();

        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            uniforms.uMouseRot.value.x += (targetRotation.x - uniforms.uMouseRot.value.x) * 0.08;
            uniforms.uMouseRot.value.y += (targetRotation.y - uniforms.uMouseRot.value.y) * 0.08;
            uniforms.iTime.value = clock.getElapsedTime();
            renderer.render(scene, camera);
        }

        animate();