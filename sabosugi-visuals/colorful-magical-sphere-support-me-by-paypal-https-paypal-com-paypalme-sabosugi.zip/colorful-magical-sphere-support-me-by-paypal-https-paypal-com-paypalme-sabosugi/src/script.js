import * as THREE from 'three';
import GUI from 'lil-gui';

// --- 1. SET UP THREE.JS ENVIRONMENT ---
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();
// Using an Orthographic camera because we are rendering a full-screen quad raymarcher
const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

// --- 2. GUI PARAMETERS & STATE ---
const params = {
    dpr: 0.7,
    speed: 1.61,
    autoRotate: true,
    autoRotateSpeed: 0.3,
    fractalScale: 1.0,
    fadeOuter: 2.56,
    fadeInner: 2.55,
    smoothing: 1.55,
    colorPhaseR: 5.8,
    colorPhaseG: 4.1,
    colorPhaseB: 2.8,
    colorPhaseA: 0.2
};

// Initialize pixel ratio and size
const updateSize = () => {
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio * params.dpr);
    if (material) {
        material.uniforms.uResolution.value.set(window.innerWidth, window.innerHeight);
    }
};

// --- 3. SHADER DEFINITIONS ---
// Vertex shader: basic full-screen quad setup
const vertexShader = `
    varying vec2 vUv;
    void main() {
        vUv = uv;
        gl_Position = vec4(position, 1.0);
    }
`;

// Fragment shader: The optimized organic volumetric fractal
const fragmentShader = `
    uniform float uTime;
    uniform vec2 uResolution;
    uniform mat3 uRotation;
    
    uniform float uFractalScale;
    uniform float uFadeOuter;
    uniform float uFadeInner;
    uniform float uSmoothing;
    uniform vec4 uColorPhases;

    varying vec2 vUv;

    // Calculates the color palette based on ray depth and dynamic uniforms
    vec4 calculatePalette(float depth) {
        return 1.0 + cos(depth + uColorPhases);
    }

    // Polynomial smooth minimum for organic blending between SDFs
    float smin(float a, float b, float k) {
        float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
        return mix(b, a, h) - k * h * (1.0 - h);
    }

    // Evaluates the volumetric scene distance and applies spatial turbulence
    float evaluateScene(vec3 rayPosition, float currentTime, out vec3 secondaryPosition) {
        // Scale the coordinate space to shrink the fractal structure
        vec3 primaryPos = rayPosition * uFractalScale;
        vec3 secondaryPos = rayPosition * uFractalScale;
        
        // Apply nested turbulence to distort the coordinate space
        for (float iteration = 2.3; iteration <= 6.0; iteration += 1.1) {
            float secondaryScale = iteration * 0.3;
            // Mutate positions using swizzled sine waves over time
            secondaryPos += sin(0.6 * currentTime + primaryPos.zxy * secondaryScale) * 0.4;
            primaryPos += sin(currentTime + primaryPos.yzx * iteration) * 0.25;
        }
        
        secondaryPosition = secondaryPos;
        
        // Calculate Signed Distance Fields (SDF) for the base shapes
        float sphereA = length(primaryPos + 1.0) - 2.0;
        float sphereB = length(secondaryPos - 1.3) - 2.9;
        
        // Smoothly blend the two spheres instead of a hard mathematical union
        float blendedSpheres = smin(sphereA, sphereB, uSmoothing);
        
        // Calculate fractal volume and divide by scale to maintain correct SDF distance
        float fractalVolume = abs(blendedSpheres) * 0.1;
        return fractalVolume / uFractalScale;
    }

    // Pseudo-random number generator
    float randomNoise(vec2 p) {
        return fract(sin(dot(p, vec2(12.8998, 78.233))) * 43758.5453);
    }

    // Safe cross-platform implementation of tanh
    vec4 customTanh(vec4 x) {
        // Clamp to prevent overflow in exp() on mobile GPUs
        vec4 e2x = exp(2.0 * clamp(x, -20.0, 20.0));
        return (e2x - 1.0) / (e2x + 1.0);
    }

    void main() {
        // Normalize fragment coordinates and adjust for aspect ratio
        vec2 fragCoord = vUv * uResolution;
        vec2 uv = (fragCoord * 2.0 - uResolution.xy) / uResolution.y;
        
        // Initialize ray distance with math noise to prevent banding artifacts
        float totalDistance = -0.015 * randomNoise(fragCoord);
        vec4 colorAccumulator = vec4(0.0);
        
        // Set up the camera ray
        vec3 rayOrigin = vec3(0.0, 0.0, -4.5);
        vec3 rayDir = normalize(vec3(uv, 1.0));
        
        // Main raymarching loop
        for (int step = 0; step < 90; step++) {
            // Calculate unrotated position
            vec3 currentPos = rayOrigin + rayDir * totalDistance;
            
            // OPTIMIZATION 1: Early exit if ray has passed the scene
            if (totalDistance > 10.0) break;
            
            // Distance to the center (rotation doesn't change magnitude)
            float distFromCenter = length(currentPos);
            
            // OPTIMIZATION 2: Bounding volume fast-forward
            // Skip all expensive fractal math if outside the visible sphere boundaries
            if (distFromCenter > uFadeOuter + 0.01) {
                totalDistance += distFromCenter - uFadeOuter;
                continue;
            }
            
            // Apply interactive 3D rotation from the mouse ONLY inside the volume
            vec3 rotatedPos = uRotation * currentPos;
            vec3 secondaryPos;
            
            // Evaluate scene at the rotated position
            float sceneDistance = evaluateScene(rotatedPos, uTime, secondaryPos);
            
            // Define ray step size with a minimal progression threshold
            float stepSize = 0.012 + sceneDistance;
            totalDistance += stepSize;
            
            // --- SOFT CONTAINMENT LOGIC ---
            float radialFade = smoothstep(uFadeOuter, uFadeInner, distFromCenter);
            
            // Accumulate glowing density based on the palette and step size
            vec4 baseColor = calculatePalette(rotatedPos.z);
            
            // Multiply accumulated color by the soft fade factor
            colorAccumulator += (baseColor / stepSize) * radialFade;
            
            // OPTIMIZATION 3: Early exit if pixel is already fully saturated
            if (colorAccumulator.x > 25000.0 && colorAccumulator.y > 25000.0 && colorAccumulator.z > 25000.0) break;
        }
        
        // Post-processing: Apply vignetting based on screen coordinates
        float vignetteEffect = max(length(uv), 0.2);
        
        // Tonemap the accumulated color to keep it within visible ranges
        colorAccumulator = colorAccumulator / (8000.0 * vignetteEffect);
        
        gl_FragColor = customTanh(colorAccumulator);
        gl_FragColor.a = 1.0;
    }
`;

// Create the fullscreen plane
const geometry = new THREE.PlaneGeometry(2, 2);
const material = new THREE.ShaderMaterial({
    vertexShader,
    fragmentShader,
    uniforms: {
        uTime: { value: 0 },
        uResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
        uRotation: { value: new THREE.Matrix3() },
        uFractalScale: { value: params.fractalScale },
        uFadeOuter: { value: params.fadeOuter },
        uFadeInner: { value: params.fadeInner },
        uSmoothing: { value: params.smoothing },
        uColorPhases: { value: new THREE.Vector4(params.colorPhaseR, params.colorPhaseG, params.colorPhaseB, params.colorPhaseA) }
    }
});

const mesh = new THREE.Mesh(geometry, material);
scene.add(mesh);

// Setup resize event
window.addEventListener('resize', updateSize);
updateSize();

// --- 4. MOUSE ROTATION LOGIC ---
let isDragging = false;
let previousMousePosition = { x: 0, y: 0 };

// Target rotation for smooth interpolation
let targetRotationX = 0;
let targetRotationY = 0;

// Current actual rotation
let currentRotationX = 0;
let currentRotationY = 0;

const updateRotationMatrix = () => {
    // Apply XYZ rotation logic to a standard Matrix4, then convert to Matrix3 for the shader
    const euler = new THREE.Euler(currentRotationX, currentRotationY, 0, 'YXZ');
    const rotationMatrix4 = new THREE.Matrix4().makeRotationFromEuler(euler);
    material.uniforms.uRotation.value.setFromMatrix4(rotationMatrix4);
};

// Initial setup for rotation
updateRotationMatrix();

window.addEventListener('pointerdown', (e) => {
    isDragging = true;
    previousMousePosition = { x: e.clientX, y: e.clientY };
    document.body.classList.add('dragging');
});

window.addEventListener('pointermove', (e) => {
    if (isDragging) {
        const deltaMove = {
            x: e.clientX - previousMousePosition.x,
            y: e.clientY - previousMousePosition.y
        };

        // Update target rotation instead of direct rotation
        targetRotationX += deltaMove.y * 0.008;
        targetRotationY += deltaMove.x * 0.008;

        previousMousePosition = { x: e.clientX, y: e.clientY };
    }
});

window.addEventListener('pointerup', () => {
    isDragging = false;
    document.body.classList.remove('dragging');
});

// --- 5. LIL-GUI SETUP ---
const gui = new GUI({ title: 'Sphere Settings' });

// Render Settings
const folderRender = gui.addFolder('Render Settings');
folderRender.add(params, 'dpr', 0.1, 2.0, 0.1).name('Pixel Ratio (DPR)').onChange(updateSize);

// Animation
const folderAnim = gui.addFolder('Animation');
folderAnim.add(params, 'speed', 0.0, 3.0, 0.01).name('Speed');
folderAnim.add(params, 'autoRotate').name('Auto Rotate');
folderAnim.add(params, 'autoRotateSpeed', -2.0, 2.0, 0.01).name('Auto Rotate Speed');

// Fractal Structure
const folderStruct = gui.addFolder('Fractal Structure');
folderStruct.add(params, 'fractalScale', 0.1, 3.0, 0.01).name('Scale').onChange(v => material.uniforms.uFractalScale.value = v);
folderStruct.add(params, 'smoothing', 0.1, 4.0, 0.01).name('Smoothing Factor').onChange(v => material.uniforms.uSmoothing.value = v);

// Sphere Boundary
const folderBound = gui.addFolder('Sphere Boundary');
folderBound.add(params, 'fadeOuter', 1.0, 5.0, 0.01).name('Fade Outer Radius').onChange(v => material.uniforms.uFadeOuter.value = v);
folderBound.add(params, 'fadeInner', 0.5, 4.0, 0.01).name('Fade Inner Radius').onChange(v => material.uniforms.uFadeInner.value = v);

// Color Palette
const folderColors = gui.addFolder('Color Palette (Phases)');
const updateColors = () => {
    material.uniforms.uColorPhases.value.set(params.colorPhaseR, params.colorPhaseG, params.colorPhaseB, params.colorPhaseA);
};
folderColors.add(params, 'colorPhaseR', 0.0, 10.0, 0.1).name('Phase R').onChange(updateColors);
folderColors.add(params, 'colorPhaseG', 0.0, 10.0, 0.1).name('Phase G').onChange(updateColors);
folderColors.add(params, 'colorPhaseB', 0.0, 10.0, 0.1).name('Phase B').onChange(updateColors);
folderColors.add(params, 'colorPhaseA', 0.0, 10.0, 0.1).name('Phase A').onChange(updateColors);

// Collapse the GUI by default
gui.close();

// --- 6. RENDER LOOP ---
const clock = new THREE.Clock();
let currentTime = 0;

const animate = () => {
    requestAnimationFrame(animate);
    
    let delta = clock.getDelta();
    
    // FIX: Clamp delta to prevent huge jumps when returning from an inactive tab
    delta = Math.min(delta, 0.1);

    currentTime += delta * params.speed;
    
    // Auto-rotation logic (only applies when not holding the sphere)
    if (params.autoRotate && !isDragging) {
        targetRotationY += delta * params.autoRotateSpeed;
    }
    
    // Limit vertical rotation to prevent flipping upside down (-90 to 90 degrees)
    targetRotationX = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, targetRotationX));

    // Smooth interpolation (Lerp) from current rotation to target rotation
    // The 0.08 factor determines how "heavy" and smooth the movement feels
    currentRotationX += (targetRotationX - currentRotationX) * 0.08;
    currentRotationY += (targetRotationY - currentRotationY) * 0.08;
    
    updateRotationMatrix();
    
    material.uniforms.uTime.value = currentTime;
    renderer.render(scene, camera);
};

animate();