# Mascot 3D - Three.js

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/YPWPoRJ](https://codepen.io/sabosugi/pen/YPWPoRJ).

