import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js';
import GUI from 'https://cdn.jsdelivr.net/npm/lil-gui@0.20.0/+esm';

const params = {
    startTimeOffset: 60.0,
    flowSpeed: 1.05,
    colorSpeed: 0.045,
    paused: false,

    smokeDensity: 57.1,
    smokeScale: 2.56,
    detailScale: 38.9,
    swirlAmount: 4.13,
    contrast: 1.79,
    mixingStrength: -1.22,

    groupSpacing: 1.04,
    verticalPosition: 0.00,
    plumeWidth: 1.00,
    plumeHeight: 1.00,

    colorSaturation: 2.25,
    colorBoost: 1.12,

    backgroundColor: '#ffffff',
    groupColor1: '#38bcff',
    groupColor2: '#fd61cb',
    groupColor3: '#ffad45',
    groupColor4: '#59e29e',

    dpr: 1.0
};

const renderer = new THREE.WebGLRenderer({
    antialias: false,
    alpha: false,
    powerPreference: 'high-performance'
});

renderer.setPixelRatio(params.dpr);
renderer.setSize(window.innerWidth, window.innerHeight, false);
renderer.toneMapping = THREE.NoToneMapping;

document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();
const camera = new THREE.Camera();

const uniforms = {
    uTime: {
        value: params.startTimeOffset
    },

    uResolution: {
        value: new THREE.Vector2(1, 1)
    },

    uFlowSpeed: {
        value: params.flowSpeed
    },

    uColorSpeed: {
        value: params.colorSpeed
    },

    uSmokeDensity: {
        value: params.smokeDensity
    },

    uSmokeScale: {
        value: params.smokeScale
    },

    uDetailScale: {
        value: params.detailScale
    },

    uSwirlAmount: {
        value: params.swirlAmount
    },

    uContrast: {
        value: params.contrast
    },

    uMixingStrength: {
        value: params.mixingStrength
    },

    uGroupSpacing: {
        value: params.groupSpacing
    },

    uVerticalPosition: {
        value: params.verticalPosition
    },

    uPlumeWidth: {
        value: params.plumeWidth
    },

    uPlumeHeight: {
        value: params.plumeHeight
    },

    uColorSaturation: {
        value: params.colorSaturation
    },

    uColorBoost: {
        value: params.colorBoost
    },

    uBackgroundColor: {
        value: new THREE.Color(params.backgroundColor)
    },

    uGroupColor0: {
        value: new THREE.Color(params.groupColor1)
    },

    uGroupColor1: {
        value: new THREE.Color(params.groupColor2)
    },

    uGroupColor2: {
        value: new THREE.Color(params.groupColor3)
    },

    uGroupColor3: {
        value: new THREE.Color(params.groupColor4)
    }
};

const vertexShader = /* glsl */ `
    precision highp float;

    attribute vec3 position;

    void main()
    {
        gl_Position = vec4(position, 1.0);
    }
`;

const fragmentShader = /* glsl */ `
    precision highp float;

    uniform float uTime;
    uniform vec2 uResolution;

    uniform float uFlowSpeed;
    uniform float uColorSpeed;
    uniform float uSmokeDensity;
    uniform float uSmokeScale;
    uniform float uDetailScale;
    uniform float uSwirlAmount;
    uniform float uContrast;
    uniform float uMixingStrength;

    uniform float uGroupSpacing;
    uniform float uVerticalPosition;
    uniform float uPlumeWidth;
    uniform float uPlumeHeight;

    uniform float uColorSaturation;
    uniform float uColorBoost;

    uniform vec3 uBackgroundColor;
    uniform vec3 uGroupColor0;
    uniform vec3 uGroupColor1;
    uniform vec3 uGroupColor2;
    uniform vec3 uGroupColor3;

    const int LAYER_COUNT = 11;
    const float TAU = 6.28318530718;

    float saturate(float value)
    {
        return clamp(value, 0.0, 1.0);
    }

    float hash21(vec2 p)
    {
        p = fract(p * vec2(122.80, 345.45));
        p += dot(p, p + 34.345);

        return fract(p.x * p.y);
    }

    float noise2(vec2 p)
    {
        vec2 cell = floor(p);
        vec2 local = fract(p);

        local = local * local * (3.0 - 2.0 * local);

        float a = hash21(cell + vec2(0.0, 0.0));
        float b = hash21(cell + vec2(1.0, 0.0));
        float c = hash21(cell + vec2(0.0, 1.0));
        float d = hash21(cell + vec2(1.0, 1.0));

        float x1 = mix(a, b, local.x);
        float x2 = mix(c, d, local.x);

        return mix(x1, x2, local.y);
    }

    float fbm3(vec2 p)
    {
        mat2 m = mat2(
             1.6, 1.2,
            -1.2, 1.6
        );

        float value = 0.0;
        float amplitude = 0.5;

        for (int i = 0; i < 3; i++)
        {
            value += amplitude * noise2(p);
            p = m * p * 1.03 + vec2(0.17, -0.11);
            amplitude *= 0.5;
        }

        return value;
    }

    vec3 palette(float t)
    {
        return 0.54 + 0.46 * cos(
            TAU * (
                vec3(0.00, 0.33, 0.67) +
                t
            )
        );
    }

    vec3 applySaturation(vec3 color, float amount)
    {
        float luminance = dot(
            color,
            vec3(0.299, 0.587, 0.114)
        );

        return mix(
            vec3(luminance),
            color,
            amount
        );
    }

    vec4 sampleSmokeGroup(
        vec2 uv,
        float depth,
        float time,
        vec2 groupPos,
        vec3 groupColor,
        float phase,
        float widthMul,
        float heightMul
    )
    {
        vec2 local = uv - groupPos;

        float y01 = saturate(
            (
                local.y +
                0.92 * heightMul
            ) /
            (
                2.00 * heightMul
            )
        );

        float bottomFade = smoothstep(
            -0.92 * heightMul,
            -0.56 * heightMul,
            local.y
        );

        float topFade =
            1.0 -
            smoothstep(
                0.68 * heightMul,
                1.22 * heightMul,
                local.y
            );

        float width =
            mix(
                0.15,
                0.48,
                pow(y01, 0.80)
            ) *
            widthMul;

        float swayLarge =
            sin(
                local.y * 1.55 +
                phase +
                time * 0.50
            ) *
            0.18 +
            sin(
                local.y * 3.10 -
                phase -
                time * 0.23
            ) *
            0.06;

        float swaySmall =
            sin(
                local.y * 5.60 +
                phase * 1.37 +
                time * 0.17
            ) *
            0.024;

        float dx =
            local.x -
            swayLarge -
            swaySmall;

        float bodyMask =
            1.0 -
            smoothstep(
                width * 0.70,
                width,
                abs(dx)
            );

        float haloMask =
            1.0 -
            smoothstep(
                width * 0.95,
                width * 1.95,
                abs(dx)
            );

        float roundMask =
            1.0 -
            smoothstep(
                0.70,
                1.0,
                length(
                    vec2(
                        dx /
                        max(
                            width * 1.35,
                            0.001
                        ),

                        local.y /
                        (
                            1.18 *
                            heightMul
                        )
                    )
                )
            );

        float plumeMask =
            bottomFade *
            topFade *
            max(
                bodyMask * 0.84 +
                haloMask * 0.16,

                roundMask * 0.34
            );

        if (plumeMask < 0.001)
        {
            return vec4(0.0);
        }

        vec2 p = vec2(
            dx * 1.12,
            local.y * 0.90
        );

        p *= uSmokeScale;

        p.y -=
            time *
            mix(
                0.82,
                1.16,
                depth
            ) *
            0.35;

        p.y += depth * 1.28;

        vec2 flowPos =
            p * 0.44 +
            vec2(
                phase * 0.7,
                -time * 0.07
            );

        vec2 flow =
            vec2(
                noise2(
                    flowPos +
                    vec2(1.3, 6.1)
                ),

                noise2(
                    flowPos +
                    vec2(7.2, 2.4)
                )
            ) -
            0.5;

        p +=
            flow *
            mix(
                0.82,
                1.10,
                depth
            );

        float curlPhase =
            p.y * 0.78 +
            phase * 1.21 +
            time * 0.045;

        vec2 curlOffset = vec2(
            sin(
                curlPhase +
                flow.y * 3.0
            ),

            cos(
                curlPhase * 0.83 -
                flow.x * 3.4
            )
        );

        p +=
            curlOffset *
            uSwirlAmount *
            mix(
                0.035,
                0.055,
                depth
            );

        p.x +=
            sin(
                p.y * 1.02 +
                phase +
                flow.y * 4.3 +
                time * 0.06
            ) *
            uSwirlAmount *
            0.11;

        float coarse =
            fbm3(
                p * 0.82
            );

        float medium =
            noise2(
                p * 1.45 +
                vec2(
                    0.0,
                    -time * 0.08
                )
            );

        float fine =
            noise2(
                p *
                max(
                    uDetailScale * 0.20,
                    0.001
                ) +
                vec2(
                    phase * 2.3,
                    time * 0.05
                )
            );

        float billowCoarse =
            1.0 -
            abs(
                coarse * 2.0 -
                1.0
            );

        float billowMedium =
            1.0 -
            abs(
                medium * 2.0 -
                1.0
            );

        float billowFine =
            1.0 -
            abs(
                fine * 2.0 -
                1.0
            );

        billowCoarse *= billowCoarse;
        billowMedium *= billowMedium;
        billowFine *= billowFine;

        float billowField =
            billowCoarse * 0.54 +
            billowMedium * 0.30 +
            billowFine * 0.16;

        float smokeField =
            coarse * 0.42 +
            billowField * 0.58;

        float erosion =
            (1.0 - fine) *
            0.10;

        smokeField -= erosion;

        smokeField = pow(
            saturate(smokeField),
            uContrast
        );

        float softBody =
            smoothstep(
                0.20,
                0.56,
                coarse
            );

        float foldedBody =
            smoothstep(
                0.34,
                0.60,
                smokeField
            );

        float density =
            mix(
                softBody * 0.28,
                1.0,
                foldedBody
            );

        density *= plumeMask;

        float cavity =
            smoothstep(
                0.18,
                0.82,
                fine
            );

        density *= mix(
            0.72,
            1.10,
            cavity
        );

        float depthWeight =
            mix(
                1.08,
                0.60,
                depth
            );

        density *= depthWeight;
        density = saturate(density);

        float colorTime =
            uTime *
            uColorSpeed;

        float hue =
            phase * 0.07 +
            colorTime +
            coarse * 0.06 +
            flow.x * 0.04 +
            depth * 0.03;

        vec3 driftColor =
            palette(hue);

        float driftAmount =
            0.12 +
            0.08 *
            (
                0.5 +
                0.5 *
                sin(
                    colorTime * 2.1 +
                    phase +
                    local.y * 0.8
                )
            );

        vec3 smokeColor =
            mix(
                groupColor,
                driftColor,
                driftAmount
            );

        float lighting =
            0.78 +
            billowCoarse * 0.24 -
            billowFine * 0.08 +
            flow.y * 0.10;

        lighting = clamp(
            lighting,
            0.64,
            1.12
        );

        float denseCore =
            smoothstep(
                0.35,
                0.92,
                density
            );

        smokeColor *= lighting;

        smokeColor = mix(
            smokeColor,
            smokeColor * 0.82,
            denseCore * 0.28
        );

        smokeColor = applySaturation(
            smokeColor,
            uColorSaturation
        );

        smokeColor *= uColorBoost;

        smokeColor = clamp(
            smokeColor,
            0.0,
            1.0
        );

        return vec4(
            smokeColor,
            density
        );
    }

    vec4 sampleSmokeScene(
        vec2 uv,
        float depth,
        float time
    )
    {
        vec2 groupPos0 = vec2(
            -0.42 * uGroupSpacing,
            -0.10 + uVerticalPosition
        );

        vec2 groupPos1 = vec2(
            -0.14 * uGroupSpacing,
            -0.03 + uVerticalPosition
        );

        vec2 groupPos2 = vec2(
             0.14 * uGroupSpacing,
            -0.07 + uVerticalPosition
        );

        vec2 groupPos3 = vec2(
             0.42 * uGroupSpacing,
            -0.01 + uVerticalPosition
        );

        vec4 group0 = sampleSmokeGroup(
            uv,
            depth,
            time,
            groupPos0,
            uGroupColor0,
            0.35,
            1.12 * uPlumeWidth,
            1.06 * uPlumeHeight
        );

        vec4 group1 = sampleSmokeGroup(
            uv,
            depth,
            time,
            groupPos1,
            uGroupColor1,
            1.85,
            1.18 * uPlumeWidth,
            1.12 * uPlumeHeight
        );

        vec4 group2 = sampleSmokeGroup(
            uv,
            depth,
            time,
            groupPos2,
            uGroupColor2,
            3.50,
            1.14 * uPlumeWidth,
            1.08 * uPlumeHeight
        );

        vec4 group3 = sampleSmokeGroup(
            uv,
            depth,
            time,
            groupPos3,
            uGroupColor3,
            5.10,
            1.20 * uPlumeWidth,
            1.14 * uPlumeHeight
        );

        float baseDensity =
            group0.a +
            group1.a +
            group2.a +
            group3.a;

        vec3 baseColorSum =
            group0.rgb * group0.a +
            group1.rgb * group1.a +
            group2.rgb * group2.a +
            group3.rgb * group3.a;

        float bridge01 =
            sqrt(
                max(
                    group0.a * group1.a,
                    0.0
                )
            );

        float bridge12 =
            sqrt(
                max(
                    group1.a * group2.a,
                    0.0
                )
            );

        float bridge23 =
            sqrt(
                max(
                    group2.a * group3.a,
                    0.0
                )
            );

        bridge01 *= uMixingStrength;
        bridge12 *= uMixingStrength;
        bridge23 *= uMixingStrength;

        float mixPhase =
            time * 0.55 +
            depth * 2.4;

        vec3 bridgeColor01 =
            mix(
                group0.rgb,
                group1.rgb,
                0.5 +
                0.18 *
                sin(
                    mixPhase +
                    0.4
                )
            );

        vec3 bridgeColor12 =
            mix(
                group1.rgb,
                group2.rgb,
                0.5 +
                0.18 *
                sin(
                    mixPhase +
                    1.7
                )
            );

        vec3 bridgeColor23 =
            mix(
                group2.rgb,
                group3.rgb,
                0.5 +
                0.18 *
                sin(
                    mixPhase +
                    2.9
                )
            );

        float sharedMist =
            smoothstep(
                0.10,
                0.85,
                baseDensity
            ) *
            0.16;

        vec3 sharedColor =
            baseColorSum /
            max(
                baseDensity,
                0.0001
            );

        float densitySum =
            baseDensity +
            bridge01 +
            bridge12 +
            bridge23 +
            sharedMist;

        vec3 colorSum =
            baseColorSum +
            bridgeColor01 * bridge01 +
            bridgeColor12 * bridge12 +
            bridgeColor23 * bridge23 +
            sharedColor * sharedMist;

        if (densitySum < 0.001)
        {
            return vec4(0.0);
        }

        vec3 color =
            colorSum /
            max(
                densitySum,
                0.0001
            );

        float density =
            clamp(
                densitySum,
                0.0,
                1.0
            );

        return vec4(
            color,
            density
        );
    }

    void main()
    {
        vec2 uv =
            (
                gl_FragCoord.xy -
                0.5 * uResolution.xy
            ) /
            max(
                uResolution.y,
                1.0
            );

        float time =
            uTime *
            uFlowSpeed;

        vec3 accumulatedColor =
            vec3(0.0);

        float transmittance = 1.0;

        for (int i = 0; i < LAYER_COUNT; i++)
        {
            float depth =
                float(i) /
                float(LAYER_COUNT - 1);

            vec2 layerUV = uv;

            layerUV *= mix(
                1.34,
                0.95,
                depth
            );

            layerUV.y +=
                (1.0 - depth) *
                0.16;

            layerUV.x +=
                sin(
                    depth * 11.0 +
                    time * 0.22
                ) *
                0.03;

            vec4 smokeSample =
                sampleSmokeScene(
                    layerUV,
                    depth,
                    time
                );

            float opticalDepth =
                smokeSample.a *
                (
                    uSmokeDensity /
                    float(LAYER_COUNT)
                ) *
                0.70;

            opticalDepth =
                max(
                    opticalDepth,
                    0.0
                );

            float layerOpacity =
                1.0 -
                exp(
                    -opticalDepth
                );

            layerOpacity = clamp(
                layerOpacity,
                0.0,
                0.17
            );

            accumulatedColor +=
                transmittance *
                smokeSample.rgb *
                layerOpacity;

            transmittance *=
                1.0 -
                layerOpacity;

            if (transmittance < 0.018)
            {
                break;
            }
        }

        vec3 finalColor =
            accumulatedColor +
            uBackgroundColor *
            transmittance;

        finalColor = clamp(
            finalColor,
            0.0,
            1.0
        );

        finalColor = pow(
            finalColor,
            vec3(1.0 / 2.2)
        );

        gl_FragColor = vec4(
            finalColor,
            1.0
        );
    }
`;

const geometry = new THREE.BufferGeometry();

geometry.setAttribute(
    'position',
    new THREE.Float32BufferAttribute(
        [
            -1, -1, 0,
             3, -1, 0,
            -1,  3, 0
        ],
        3
    )
);

const material = new THREE.RawShaderMaterial({
    uniforms,
    vertexShader,
    fragmentShader,
    depthTest: false,
    depthWrite: false
});

const mesh = new THREE.Mesh(
    geometry,
    material
);

mesh.frustumCulled = false;

scene.add(mesh);

const resolutionBuffer = new THREE.Vector2();

function updateResolution()
{
    renderer.getDrawingBufferSize(
        resolutionBuffer
    );

    uniforms.uResolution.value.copy(
        resolutionBuffer
    );
}

function resizeRenderer()
{
    renderer.setPixelRatio(params.dpr);

    renderer.setSize(
        window.innerWidth,
        window.innerHeight,
        false
    );

    updateResolution();
}

function updateColor(uniform, value)
{
    uniform.value.set(value);
}

const gui = new GUI({
    title: 'Smoke Settings'
});

const animationFolder =
    gui.addFolder('Animation');

animationFolder
    .add(
        params,
        'flowSpeed',
        0.0,
        1.5,
        0.01
    )
    .name('Flow Speed')
    .onChange((value) =>
    {
        uniforms.uFlowSpeed.value = value;
    });

animationFolder
    .add(
        params,
        'colorSpeed',
        0.0,
        0.2,
        0.001
    )
    .name('Color Speed')
    .onChange((value) =>
    {
        uniforms.uColorSpeed.value = value;
    });

animationFolder
    .add(
        params,
        'paused'
    )
    .name('Pause');

const smokeFolder =
    gui.addFolder('Smoke');

smokeFolder
    .add(
        params,
        'smokeDensity',
        1.0,
        80.0,
        0.1
    )
    .name('Density')
    .onChange((value) =>
    {
        uniforms.uSmokeDensity.value = value;
    });

smokeFolder
    .add(
        params,
        'smokeScale',
        0.5,
        7.0,
        0.01
    )
    .name('Scale')
    .onChange((value) =>
    {
        uniforms.uSmokeScale.value = value;
    });

smokeFolder
    .add(
        params,
        'detailScale',
        1.0,
        50.0,
        0.1
    )
    .name('Detail Scale')
    .onChange((value) =>
    {
        uniforms.uDetailScale.value = value;
    });

smokeFolder
    .add(
        params,
        'swirlAmount',
        0.0,
        8.0,
        0.01
    )
    .name('Swirl')
    .onChange((value) =>
    {
        uniforms.uSwirlAmount.value = value;
    });

smokeFolder
    .add(
        params,
        'contrast',
        0.5,
        4.0,
        0.01
    )
    .name('Contrast')
    .onChange((value) =>
    {
        uniforms.uContrast.value = value;
    });

smokeFolder
    .add(
        params,
        'mixingStrength',
        -2.5,
        2.5,
        0.01
    )
    .name('Mixing')
    .onChange((value) =>
    {
        uniforms.uMixingStrength.value = value;
    });

const shapeFolder =
    gui.addFolder('Shape');

shapeFolder
    .add(
        params,
        'groupSpacing',
        0.2,
        2.0,
        0.01
    )
    .name('Group Spacing')
    .onChange((value) =>
    {
        uniforms.uGroupSpacing.value = value;
    });

shapeFolder
    .add(
        params,
        'verticalPosition',
        -0.8,
        0.8,
        0.01
    )
    .name('Vertical Position')
    .onChange((value) =>
    {
        uniforms.uVerticalPosition.value = value;
    });

shapeFolder
    .add(
        params,
        'plumeWidth',
        0.4,
        2.0,
        0.01
    )
    .name('Plume Width')
    .onChange((value) =>
    {
        uniforms.uPlumeWidth.value = value;
    });

shapeFolder
    .add(
        params,
        'plumeHeight',
        0.4,
        2.0,
        0.01
    )
    .name('Plume Height')
    .onChange((value) =>
    {
        uniforms.uPlumeHeight.value = value;
    });

const colorsFolder =
    gui.addFolder('Colors');

colorsFolder
    .add(
        params,
        'colorSaturation',
        0.5,
        2.5,
        0.01
    )
    .name('Saturation')
    .onChange((value) =>
    {
        uniforms.uColorSaturation.value = value;
    });

colorsFolder
    .add(
        params,
        'colorBoost',
        0.7,
        1.8,
        0.01
    )
    .name('Color Boost')
    .onChange((value) =>
    {
        uniforms.uColorBoost.value = value;
    });

colorsFolder
    .addColor(
        params,
        'backgroundColor'
    )
    .name('Background')
    .onChange((value) =>
    {
        updateColor(
            uniforms.uBackgroundColor,
            value
        );
    });

colorsFolder
    .addColor(
        params,
        'groupColor1'
    )
    .name('Group 1')
    .onChange((value) =>
    {
        updateColor(
            uniforms.uGroupColor0,
            value
        );
    });

colorsFolder
    .addColor(
        params,
        'groupColor2'
    )
    .name('Group 2')
    .onChange((value) =>
    {
        updateColor(
            uniforms.uGroupColor1,
            value
        );
    });

colorsFolder
    .addColor(
        params,
        'groupColor3'
    )
    .name('Group 3')
    .onChange((value) =>
    {
        updateColor(
            uniforms.uGroupColor2,
            value
        );
    });

colorsFolder
    .addColor(
        params,
        'groupColor4'
    )
    .name('Group 4')
    .onChange((value) =>
    {
        updateColor(
            uniforms.uGroupColor3,
            value
        );
    });

const performanceFolder =
    gui.addFolder('Performance');

performanceFolder
    .add(
        params,
        'dpr',
        0.5,
        2.0,
        0.1
    )
    .name('DPR')
    .onChange(resizeRenderer);

gui.close();

let elapsedTime = 0;
let previousTime = performance.now();

function animate(currentTime)
{
    requestAnimationFrame(animate);

    const deltaTime = Math.min(
        (
            currentTime -
            previousTime
        ) *
        0.001,
        0.05
    );

    previousTime = currentTime;

    if (!params.paused)
    {
        elapsedTime += deltaTime;

        uniforms.uTime.value =
            params.startTimeOffset +
            elapsedTime;
    }

    renderer.render(
        scene,
        camera
    );
}

window.addEventListener(
    'resize',
    resizeRenderer
);

document.addEventListener(
    'visibilitychange',
    () =>
    {
        previousTime = performance.now();
    }
);

window.addEventListener(
    'beforeunload',
    () =>
    {
        geometry.dispose();
        material.dispose();
        renderer.dispose();
        gui.destroy();
    }
);

resizeRenderer();
requestAnimationFrame(animate);