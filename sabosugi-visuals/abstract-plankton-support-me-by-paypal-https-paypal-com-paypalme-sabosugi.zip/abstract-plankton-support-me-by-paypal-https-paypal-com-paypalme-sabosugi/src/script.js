        // Support me by PayPal: https://paypal.com/paypalme/sabosugi
        // Setup basic Three.js scene
        const scene = new THREE.Scene();
        
        // Use an Orthographic camera for full-screen shaders
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
        camera.position.z = 1;

        const renderer = new THREE.WebGLRenderer({ antialias: false });
        renderer.setSize(window.innerWidth, window.innerHeight);
        // Default DPR is set to 1 for performance
        renderer.setPixelRatio(1.0);
        document.body.appendChild(renderer.domElement);

        // Parameters for lil-gui and uniforms
        const params = {
            dpr: 1.0,
            speed: 0.5,
            amplitude: 0.86,
            thickness: 0.06,
            holeRadius: 1.3,
            warpFrequency: 1.1,
            flowX: 1.7,
            flowY: -0.1,
            flowZ: 0.9,
            glowIntensity: 0.009,
            glowRadius: 7.7,
            colorPhaseR: 0.0,
            colorPhaseG: 2.0,
            colorPhaseB: 4.0
        };

        // Uniforms mapping to the shader
        const uniforms = {
            u_time: { value: 0.0 },
            u_resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            u_speed: { value: params.speed },
            u_amplitude: { value: params.amplitude },
            u_thickness: { value: params.thickness },
            u_holeRadius: { value: params.holeRadius },
            u_warpFrequency: { value: params.warpFrequency },
            u_flowDir: { value: new THREE.Vector3(params.flowX, params.flowY, params.flowZ) },
            u_glowIntensity: { value: params.glowIntensity },
            u_glowRadius: { value: params.glowRadius },
            u_colorOffset: { value: new THREE.Vector3(params.colorPhaseR, params.colorPhaseG, params.colorPhaseB) }
        };

        // Shader Material using your translated GLSL code
        const material = new THREE.ShaderMaterial({
            uniforms: uniforms,
            vertexShader: `
                void main() {
                    gl_Position = vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform float u_time;
                uniform vec2 u_resolution;
                uniform float u_speed;
                uniform float u_amplitude;
                uniform float u_thickness;
                uniform float u_holeRadius;
                uniform float u_warpFrequency;
                uniform vec3 u_flowDir;
                uniform float u_glowIntensity;
                uniform float u_glowRadius;
                uniform vec3 u_colorOffset;

                #define MAX_STEPS 80.0
                #define MAX_DIST 50.0

                // Interleaved Gradient Noise (IGN) - Cinematic standard for soft dithering
                float IGN(vec2 p) {
                    vec3 magic = vec3(0.03711056, 0.00583715, 52.9829189);
                    return fract(magic.z * fract(dot(p, magic.xy)));
                }

                void main() {
                    // Normalize coordinates and adjust for aspect ratio
                    vec2 fragCoord = gl_FragCoord.xy;
                    vec2 uv = (fragCoord * 2.0 - u_resolution.xy) / u_resolution.y;
                    
                    // Apply speed multiplier to time
                    float time = u_time * u_speed;

                    // Infinite forward flight along the Z-axis
                    vec3 ro = vec3(0.0, 0.0, time * 2.0);
                    vec3 rd = normalize(vec3(uv, 1.0));
                    
                    // Smooth camera sway to make the flight feel organic and heavy
                    ro.x += sin(time * 0.5) * 0.6;
                    ro.y += cos(time * 0.3) * 0.6;
                    
                    vec3 col = vec3(0.0);
                    
                    // TEMPORAL DITHERING
                    vec2 noiseCoord = fragCoord + mod(time, 1.0) * 100.0;
                    float t = IGN(noiseCoord) * 0.4; 
                    
                    for(float i = 0.0; i < MAX_STEPS; i++) {
                        vec3 p = ro + rd * t;
                        vec3 q = p;
                        
                        // Flow vector for the liquid distortion
                        vec3 flow = vec3(time * u_flowDir.x, time * u_flowDir.y, time * u_flowDir.z);
                        
                        // Sine-based domain warping for the liquid silk effect
                        for(float n = 0.9; n < 2.5; n += 1.1) {
                            q += u_amplitude * sin((q.yzx + flow) * n * u_warpFrequency) / n;
                        }
                        
                        // Create volumetric hollow shapes
                        float d = length(q.xy) - u_holeRadius;
                        
                        // Absolute value to create structural walls
                        d = max(abs(d), u_thickness); 
                        
                        // Dynamic cosine palette based on gui offsets
                        vec3 baseColor = 0.5 + 0.5 * cos(q.z * 0.15 + u_colorOffset);
                        
                        // Volumetric glow
                        float glow = u_glowIntensity / (d * d * u_glowRadius + 0.05);
                        
                        // Fade near camera
                        float nearFade = smoothstep(0.0, 4.0, t);
                        
                        // Accumulate color
                        col += baseColor * glow * exp(-t * 0.15) * nearFade;
                        
                        // Raymarching step
                        t += d * 0.4; 
                        
                        if(t > MAX_DIST) break;
                    }
                    
                    // ACES filmic tonemapping
                    col = (col * (2.51 * col + 0.03)) / (col * (2.43 * col + 0.59) + 0.14);
                    
                    // Standard gamma correction
                    col = pow(col, vec3(0.4545)); 
                    
                    gl_FragColor = vec4(col, 1.0);
                }
            `
        });

        // Add a fullscreen plane to render the shader on
        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // GUI Setup
        const gui = new lil.GUI({ title: 'Shader Settings' });
        
        // Collapse GUI by default
        gui.close();

        // Screen Settings
        const screenFolder = gui.addFolder('Screen');
        screenFolder.add(params, 'dpr', [0.5, 1.0, 1.5, 2.0]).name('Device Pixel Ratio (DPR)').onChange(value => {
            renderer.setPixelRatio(value);
        });

        // Movement Settings
        const animFolder = gui.addFolder('Animation');
        animFolder.add(params, 'speed', 0.1, 3.0, 0.1).name('Time Speed').onChange(v => uniforms.u_speed.value = v);

        // Flow Direction & Speed
        const flowFolder = gui.addFolder('Liquid Flow');
        flowFolder.add(params, 'flowX', -3.0, 3.0, 0.1).name('Flow X').onChange(v => uniforms.u_flowDir.value.x = v);
        flowFolder.add(params, 'flowY', -3.0, 3.0, 0.1).name('Flow Y').onChange(v => uniforms.u_flowDir.value.y = v);
        flowFolder.add(params, 'flowZ', -3.0, 3.0, 0.1).name('Flow Z').onChange(v => uniforms.u_flowDir.value.z = v);

        // Fractal Shape Settings
        const shapeFolder = gui.addFolder('Fractal Shape');
        shapeFolder.add(params, 'amplitude', 0.1, 2.0, 0.01).name('Distortion Amplitude').onChange(v => uniforms.u_amplitude.value = v);
        shapeFolder.add(params, 'warpFrequency', 0.1, 3.0, 0.1).name('Warp Frequency').onChange(v => uniforms.u_warpFrequency.value = v);
        shapeFolder.add(params, 'thickness', 0.01, 0.2, 0.01).name('Wall Thickness').onChange(v => uniforms.u_thickness.value = v);
        shapeFolder.add(params, 'holeRadius', 0.0, 4.0, 0.1).name('Tunnel Radius').onChange(v => uniforms.u_holeRadius.value = v);

        // Lighting & Glow
        const lightFolder = gui.addFolder('Lighting');
        lightFolder.add(params, 'glowIntensity', 0.001, 0.03, 0.001).name('Glow Intensity').onChange(v => uniforms.u_glowIntensity.value = v);
        lightFolder.add(params, 'glowRadius', 1.0, 12.0, 0.1).name('Glow Sharpness').onChange(v => uniforms.u_glowRadius.value = v);

        // Palette Settings (Cosine wave phases)
        const colorFolder = gui.addFolder('Color Phases');
        colorFolder.add(params, 'colorPhaseR', 0.0, 6.28, 0.1).name('Red Phase').onChange(v => uniforms.u_colorOffset.value.x = v);
        colorFolder.add(params, 'colorPhaseG', 0.0, 6.28, 0.1).name('Green Phase').onChange(v => uniforms.u_colorOffset.value.y = v);
        colorFolder.add(params, 'colorPhaseB', 0.0, 6.28, 0.1).name('Blue Phase').onChange(v => uniforms.u_colorOffset.value.z = v);

        // Animation Loop
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            // Update time
            uniforms.u_time.value = clock.getElapsedTime();
            // Render scene
            renderer.render(scene, camera);
        }
        
        animate();

        // Handle Window Resize
        window.addEventListener('resize', () => {
            const width = window.innerWidth;
            const height = window.innerHeight;
            
            renderer.setSize(width, height);
            uniforms.u_resolution.value.set(width, height);
        });