        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { SVGLoader } from 'three/addons/loaders/SVGLoader.js';
        import GUI from 'lil-gui';

        // --- Core Scene Setup ---
        const scene = new THREE.Scene();
        
        const camera = new THREE.PerspectiveCamera(25, window.innerWidth / window.innerHeight, 0.1, 5000);
        camera.position.set(0, 0, 250);

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.0;
        document.body.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.enableZoom = false;

        // --- Lights ---
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        scene.add(ambientLight);

        const dirLight = new THREE.DirectionalLight(0xffffff, 2);
        dirLight.position.set(50, 50, 50);
        scene.add(dirLight);

        const pointLight = new THREE.PointLight(0xabcdef, 5, 500);
        pointLight.position.set(-50, -50, 50);
        scene.add(pointLight);

        // --- Parameters (Updated as per screenshot) ---
        const params = {
            color: '#ffffff',
            transmission: 1.0,
            opacity: 1.0,
            metalness: 0.1,
            roughness: 0.0,
            ior: 2.33,
            thickness: 90.0,
            extrudeDepth: 150,
            bevelThickness: 50.0,
            bevelSize: 6.5,
            logoSize: 0.1,
            bgScale: 0.5, 
            bgSpeed: 0.14,
            autoRotate: true,
            followCursor: true,
            cameraTiltFreedom: 28, // Limit for vertical camera rotation (0 = locked horizontal, 90 = full freedom)
            // Left empty by default to show the embedded SVG. Enter URL here to override.
            svgUrl: '', 
            uploadBg: () => document.getElementById('bgInput').click(),
            uploadSvg: () => document.getElementById('svgInput').click()
        };

        // --- Apply Camera Limits ---
        function updateCameraLimits() {
            // Convert degrees to radians and constrain OrbitControls polar angles around the equator
            const limitRads = (params.cameraTiltFreedom * Math.PI) / 180;
            controls.minPolarAngle = (Math.PI / 2) - limitRads;
            controls.maxPolarAngle = (Math.PI / 2) + limitRads;
        }
        updateCameraLimits(); // Apply immediately

        // --- Glass Material ---
        const glassMaterial = new THREE.MeshPhysicalMaterial({
            color: new THREE.Color(params.color),
            metalness: params.metalness,
            roughness: params.roughness,
            transmission: params.transmission, 
            ior: params.ior,                   
            thickness: params.thickness,       
            transparent: true,
            opacity: params.opacity,
            side: THREE.DoubleSide,
            clearcoat: 1.0,
            clearcoatRoughness: 0.1
        });

        let logoWrapper = new THREE.Group();
        scene.add(logoWrapper);
        let currentSvgPaths = null;

        const mouse = new THREE.Vector2();
        const targetParallax = new THREE.Vector2();
        const currentParallax = new THREE.Vector2();

        window.addEventListener('mousemove', (event) => {
            mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
            mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
        });

        const bgSphereGeometry = new THREE.SphereGeometry(1500, 60, 40);
        const bgSphereMaterial = new THREE.MeshBasicMaterial({ side: THREE.BackSide, color: 0xffffff });
        const bgSphere = new THREE.Mesh(bgSphereGeometry, bgSphereMaterial);
        scene.add(bgSphere);

        // --- Loading Manager ---
        const loadingManager = new THREE.LoadingManager();
        const hideLoading = () => {
            const el = document.getElementById('loading');
            if (el) {
                el.style.opacity = '0';
                setTimeout(() => { el.style.display = 'none'; }, 500);
            }
        };

        loadingManager.onLoad = hideLoading;
        loadingManager.onError = (url) => {
            console.warn('Loading error at:', url);
            hideLoading();
        };

        const textureLoader = new THREE.TextureLoader(loadingManager);
        const svgLoader = new SVGLoader(loadingManager);

        function updateBgScale() {
            if (bgSphere.material.map) {
                const tex = bgSphere.material.map;
                tex.repeat.set(1 / params.bgScale, 1 / params.bgScale);
                tex.offset.set((1 - 1 / params.bgScale) / 2, (1 - 1 / params.bgScale) / 2);
            }
        }

        function loadBackground(url) {
            textureLoader.load(url, (texture) => {
                texture.colorSpace = THREE.SRGBColorSpace;
                const envTex = texture.clone();
                envTex.mapping = THREE.EquirectangularReflectionMapping;
                scene.environment = envTex; 

                const visTex = texture.clone();
                visTex.mapping = THREE.UVMapping;
                visTex.wrapS = THREE.RepeatWrapping;
                visTex.wrapT = THREE.ClampToEdgeWrapping;
                visTex.minFilter = THREE.LinearFilter;
                visTex.magFilter = THREE.LinearFilter;
                visTex.generateMipmaps = false;
                visTex.anisotropy = renderer.capabilities.getMaxAnisotropy();
                
                if (bgSphere.material.map) bgSphere.material.map.dispose();
                bgSphere.material.map = visTex;
                bgSphere.material.needsUpdate = true;
                updateBgScale();
            });
        }

        function generateLogoGeometry() {
            if (!currentSvgPaths) return;

            while(logoWrapper.children.length > 0) {
                const child = logoWrapper.children[0];
                child.traverse((c) => { if (c.isMesh) c.geometry.dispose(); });
                logoWrapper.remove(child);
            }

            const logoGroup = new THREE.Group();
            const extrudeSettings = {
                depth: params.extrudeDepth,
                bevelEnabled: params.bevelThickness > 0 || params.bevelSize > 0,
                bevelSegments: 4,
                steps: 2,
                bevelSize: params.bevelSize,
                bevelThickness: params.bevelThickness
            };

            const allShapes = [];
            currentSvgPaths.forEach(path => {
                const shapes = SVGLoader.createShapes(path);
                if (shapes.length === 0) {
                    allShapes.push(...path.toShapes(true));
                } else {
                    allShapes.push(...shapes);
                }
            });

            if (allShapes.length > 0) {
                try {
                    const geometry = new THREE.ExtrudeGeometry(allShapes, extrudeSettings);
                    const mesh = new THREE.Mesh(geometry, glassMaterial);
                    logoGroup.add(mesh);
                } catch (e) {
                    console.warn("Bevel calculation failed, falling back to safe settings", e);
                    const safeSettings = { ...extrudeSettings, bevelEnabled: false };
                    const geometry = new THREE.ExtrudeGeometry(allShapes, safeSettings);
                    const mesh = new THREE.Mesh(geometry, glassMaterial);
                    logoGroup.add(mesh);
                }
            }

            // Fixed scaling and Y-flip for proper SVG orientation
            logoGroup.scale.set(0.6, -0.6, 0.6);
            logoGroup.updateMatrixWorld(true);
            const box = new THREE.Box3().setFromObject(logoGroup);
            const center = box.getCenter(new THREE.Vector3());
            logoGroup.position.set(-center.x, -center.y, -center.z);
            logoWrapper.add(logoGroup);
            logoWrapper.scale.setScalar(params.logoSize);
        }

        // --- Default Embedded SVG Definition ---
        const defaultSvg = `<svg width="800" height="800" viewBox="0 0 800 800" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M666.667 533.333H400V800L133.333 533.333V266.667H400L666.667 533.333Z" fill="black"/>
<path d="M666.334 266.667H399.667L133 0H666.334V266.667Z" fill="black"/>
</svg>`;
        const defaultSvgBlob = new Blob([defaultSvg], { type: 'image/svg+xml' });
        const defaultSvgUrl = URL.createObjectURL(defaultSvgBlob);

        // --- High-Priority SVG Loading Logic ---
        function loadSVG(url) {
            loadingManager.itemStart(url);

            const handleSuccess = (text) => {
                try {
                    const data = svgLoader.parse(text);
                    currentSvgPaths = data.paths;
                    generateLogoGeometry();
                    loadingManager.itemEnd(url);
                } catch (err) {
                    console.error("Failed to parse SVG data:", err);
                    loadingManager.itemError(url);
                    if (url !== defaultSvgUrl) loadSVG(defaultSvgUrl);
                }
            };

            const tryFetch = (fetchUrl) => {
                fetch(fetchUrl)
                    .then(response => {
                        if (!response.ok) throw new Error('Network error');
                        return response.text();
                    })
                    .then(handleSuccess)
                    .catch(error => {
                        console.error("SVG load attempt failed:", error);
                        loadingManager.itemError(url);
                        
                        // Fallback to default embedded SVG if the URL fails
                        if (url !== defaultSvgUrl) {
                            console.warn("Falling back to default embedded SVG...");
                            loadSVG(defaultSvgUrl);
                        }
                    });
            };

            if (url.startsWith('blob:')) {
                // For files uploaded via the input panel or the default embedded blob
                svgLoader.load(url, (data) => {
                    currentSvgPaths = data.paths;
                    generateLogoGeometry();
                    loadingManager.itemEnd(url);
                }, undefined, (err) => {
                    loadingManager.itemError(url);
                    if (url !== defaultSvgUrl) loadSVG(defaultSvgUrl);
                });
            } else {
                // For remote URLs provided in params
                tryFetch(url);
            }
        }

        // --- Initialization ---
        
        // 1. Load Background (Standard texture loading)
        const initialBgUrl = 'https://ik.imagekit.io/sqiqig7tz/tr:orig-true,q-100/sky-2.png?ik-pngq=false&updatedAt=1775566717644&ik-attachment=true';
        loadBackground(initialBgUrl);

        // 2. Load SVG with Highest Priority
        if (params.svgUrl && params.svgUrl.trim() !== '') {
            loadSVG(params.svgUrl);
        } else {
            loadSVG(defaultSvgUrl);
        }

        // --- Event Listeners ---
        document.getElementById('bgInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) loadBackground(URL.createObjectURL(file));
        });

        document.getElementById('svgInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) loadSVG(URL.createObjectURL(file));
        });

        // --- GUI ---
        const gui = new GUI({ title: 'Scene Settings' });
        gui.close();
        
        const ioFolder = gui.addFolder('Import Files');
        ioFolder.add(params, 'uploadSvg').name('Upload SVG Logo');
        ioFolder.add(params, 'uploadBg').name('Upload Background');

        const matFolder = gui.addFolder('Glass Properties');
        matFolder.addColor(params, 'color').name('Color').onChange(v => glassMaterial.color.set(v));
        matFolder.add(params, 'transmission', 0, 1, 0.01).name('Transmission').onChange(v => glassMaterial.transmission = v);
        matFolder.add(params, 'roughness', 0, 1, 0.01).name('Roughness').onChange(v => glassMaterial.roughness = v);
        matFolder.add(params, 'ior', 1, 2.33, 0.01).name('Index of Refraction').onChange(v => glassMaterial.ior = v);
        matFolder.add(params, 'thickness', 0, 100, 0.1).name('Glass Thickness').onChange(v => glassMaterial.thickness = v);
        matFolder.add(params, 'extrudeDepth', 1, 500, 1).name('Extrude Depth').onChange(generateLogoGeometry);
        matFolder.add(params, 'bevelThickness', 0, 100, 0.1).name('Bevel Thickness').onChange(generateLogoGeometry);
        matFolder.add(params, 'bevelSize', 0, 100, 0.1).name('Bevel Size').onChange(generateLogoGeometry);
        
        const sceneFolder = gui.addFolder('Environment & Layout');
        sceneFolder.add(params, 'logoSize', 0.01, 5.0, 0.01).name('Logo Size').onChange(v => logoWrapper.scale.setScalar(v));
        sceneFolder.add(params, 'bgScale', 0.1, 5.0, 0.01).name('Background Scale').onChange(updateBgScale);
        sceneFolder.add(params, 'bgSpeed', -0.5, 0.5, 0.01).name('Background Speed');
        sceneFolder.add(params, 'autoRotate').name('Auto-Rotate Logo');
        sceneFolder.add(params, 'followCursor').name('Follow Cursor');
        sceneFolder.add(params, 'cameraTiltFreedom', 0, 90, 1).name('Camera Tilt Freedom').onChange(updateCameraLimits);
        sceneFolder.add(dirLight, 'intensity', 0, 10, 0.1).name('Main Light');

        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });

        const clock = new THREE.Clock();
        function animate() {
            requestAnimationFrame(animate);
            const delta = clock.getDelta();
            if (params.autoRotate && logoWrapper) {
                logoWrapper.rotation.y += 0.3 * delta;
                logoWrapper.rotation.x = Math.sin(clock.getElapsedTime() * 0.5) * 0.2;
            }
            if (bgSphere) {
                bgSphere.rotation.y += params.bgSpeed * delta;
                scene.environmentRotation.y = bgSphere.rotation.y;
            }
            controls.update();
            if (params.followCursor) {
                targetParallax.x = mouse.x * -20; 
                targetParallax.y = mouse.y * -20; 
            } else {
                targetParallax.x = 0; targetParallax.y = 0;
            }
            currentParallax.lerp(targetParallax, 0.05);
            const originalPos = camera.position.clone();
            const originalQuat = camera.quaternion.clone();
            if (currentParallax.lengthSq() > 0.0001) {
                const right = new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld, 0);
                const up = new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld, 1);
                camera.position.addScaledVector(right, currentParallax.x);
                camera.position.addScaledVector(up, currentParallax.y);
                camera.lookAt(controls.target);
            }
            renderer.render(scene, camera);
            camera.position.copy(originalPos);
            camera.quaternion.copy(originalQuat);
        }
        animate();