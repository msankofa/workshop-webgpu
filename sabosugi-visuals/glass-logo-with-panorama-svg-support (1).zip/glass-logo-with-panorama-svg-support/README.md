# Glass Logo with Panorama (SVG Support)

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/bNwjyXP](https://codepen.io/sabosugi/pen/bNwjyXP).

