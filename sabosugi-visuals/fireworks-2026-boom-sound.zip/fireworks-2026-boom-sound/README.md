# Fireworks 2026 + Boom Sound

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/ByzBXQW](https://codepen.io/sabosugi/pen/ByzBXQW).

