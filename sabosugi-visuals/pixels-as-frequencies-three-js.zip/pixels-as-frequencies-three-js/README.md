# Pixels as Frequencies – Three.js

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/azZgYmd](https://codepen.io/sabosugi/pen/azZgYmd).

