        // --- 1. SETTINGS & GUI STATE ---
        const params = {
            // Render
            dpr: 1.0,
            antiAlias: true,
            
            // Animation
            speed: 0.15,
            
            // Camera & Transforms
            perspective: 2.2,
            zoom: 7.0,
            
            // Fractal Properties
            shapeSize: 1.6,
            iterations: 5,
            foldX: 1.7,
            foldY: 0.5,
            foldZ: 0.7,
            
            // Lighting
            glowIntensity: 0.028,
            glowBase: 0.282
        };

        // --- 2. THREE.JS INITIALIZATION ---
        const scene = new THREE.Scene();
        // Use an orthographic camera since we are rendering a full-screen shader quad
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        
        const renderer = new THREE.WebGLRenderer();
        renderer.setPixelRatio(params.dpr);
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // --- 3. SHADER UNIFORMS ---
        const uniforms = {
            u_time: { value: 0.0 },
            u_resolution: { value: new THREE.Vector2(window.innerWidth * params.dpr, window.innerHeight * params.dpr) },
            u_mouse_rot: { value: new THREE.Vector2(0.0, 0.0) }, // X and Y rotation angles
            u_zoom: { value: params.zoom },
            u_perspective: { value: params.perspective },
            u_anim_speed: { value: params.speed },
            u_shape_size: { value: params.shapeSize },
            u_iterations: { value: params.iterations },
            u_fold: { value: new THREE.Vector3(params.foldX, params.foldY, params.foldZ) },
            u_glow_intensity: { value: params.glowIntensity },
            u_glow_base: { value: params.glowBase }
        };

        // --- 4. SHADER MATERIAL ---
        const getFragmentShader = (useAA) => `
            #define MAX_ITERATIONS 10
            ${useAA ? '#define USE_AA' : ''}

            uniform float u_time;
            uniform vec2 u_resolution;
            uniform vec2 u_mouse_rot;
            uniform float u_zoom;
            uniform float u_perspective;
            uniform float u_anim_speed;
            uniform float u_shape_size;
            uniform int u_iterations;
            uniform vec3 u_fold;
            uniform float u_glow_intensity;
            uniform float u_glow_base;

            // Global state for fractal coloring
            vec3 g_fractalTint;
            
            // Precomputed rotation matrices for optimization
            mat2 g_rotAnim;
            mat2 g_rotAnim07;
            mat2 g_rotFractalXY;
            mat2 g_rotFractalXZ;
            mat2 g_camRotX;
            mat2 g_camRotY;

            // Standard 2D rotation matrix
            mat2 rotate2D(float angle) {
                float c = cos(angle);
                float s = sin(angle);
                return mat2(c, -s, s, c);
            }

            // Tetrahedron Signed Distance Field
            float sdTetrahedron(vec3 p, float r) {
                float d = max(
                    max(-p.x - p.y - p.z, p.x + p.y - p.z),
                    max(-p.x + p.y + p.z, p.x - p.y + p.z)
                );
                // Corrected mathematical normalizer for a perfect tetrahedron
                return (d - r) / sqrt(3.0); 
            }

            // Pseudo-random noise for dithering (removes volumetric banding)
            float hash(vec2 p) {
                return fract(sin(dot(p, vec2(12.9098, 78.013))) * 43758.5453);
            }

            // Signed Distance Field evaluation
            float evaluateSceneSDF(vec3 samplePoint) {
                vec3 localPos = samplePoint;
                
                // Apply precomputed rotations (No expensive sin/cos inside the loop!)
                localPos.xz *= g_rotAnim;
                localPos.xy *= g_rotAnim07;

                // Bounding shape: Tetrahedron
                float boundShape = sdTetrahedron(localPos, u_shape_size);
                
                vec4 q = vec4(localPos, 1.0);
                
                // New Fractal Generation: Spherical Inversion Hybrid
                for (int k = 0; k < MAX_ITERATIONS; k++) {
                    if (k >= u_iterations) break;
                    
                    // Spherical fold (creates curved, organic inner structures)
                    float r2 = dot(q.xyz, q.xyz);
                    float sphereFold = max(1.4 / max(r2, -0.8), 1.1);
                    q *= sphereFold;

                    // Space folding with offset from uniforms
                    q.xyz = abs(q.xyz) - u_fold; 
                    
                    // Multi-axis rotation using precomputed matrices
                    q.xy *= g_rotFractalXY; 
                    q.xz *= g_rotFractalXZ;
                    
                    // Scale space
                    q *= 1.4;
                }
                
                // Extract color data before final distance calculation
                g_fractalTint = q.xyz * log(q.w + 1.0);
                
                // Final structural distance
                float fractalSurface = (length(q.xyz) - 1.2) / q.w;
                
                // Intersect the infinite organic fractal with the tetrahedron boundary
                return max(boundShape, fractalSurface);
            }

            // Normal calculation using optimized Tetrahedral method (4 SDF calls instead of 6)
            vec3 estimateNormal(vec3 p) {
                vec2 e = vec2(1.0, -1.0) * 0.501; // Kept original large epsilon for identical smoothed look
                return normalize(
                    e.xyy * evaluateSceneSDF(p + e.xyy) +
                    e.yyx * evaluateSceneSDF(p + e.yyx) +
                    e.yxy * evaluateSceneSDF(p + e.yxy) +
                    e.xxx * evaluateSceneSDF(p + e.xxx)
                );  
            }

            // Core raymarching engine
            vec3 renderRay(vec3 origin, vec3 direction, float jitter) {
                // Apply pixel-based jitter to start distance to break up banding
                float totalDistance = jitter; 
                int bounceCount = 1;
                vec3 accumulatedLight = vec3(0.0); // Removed base fog

                // Normalized loop parameters for smooth rendering
                for(int step = 0; step < 120; step++) {
                    vec3 currentPos = origin + direction * totalDistance;
                    
                    float sceneDist = evaluateSceneSDF(currentPos); 

                    // Perturb and accumulate global tint
                    g_fractalTint = cos(g_fractalTint * u_glow_base);
                    g_fractalTint *= g_fractalTint;

                    // Apply volumetric glow (based on distance from center, not camera)
                    if (step > 1) {
                        float distSq = dot(currentPos, currentPos);
                        float attenuation = exp(-distSq * 0.25);
                        accumulatedLight += u_glow_intensity * g_fractalTint * attenuation;
                    }
                      
                    // Surface intersection & reflection handling
                    if (sceneDist < 0.0002) {
                       if (bounceCount > 1) break; // Limit internal reflections
                       
                       vec3 surfaceNormal = estimateNormal(currentPos);
                       direction = reflect(direction, surfaceNormal);
                       
                       // Multiply accumulated light on bounce
                       accumulatedLight *= (1.1 + 0.1 * exp(float(bounceCount)));
                    
                       // Small push forward along the new reflected direction
                       totalDistance += 0.02; 
                       bounceCount++;  
                    }
                    
                    // Ray advance. Multiplied by 0.8 to prevent stepping through thin surfaces
                    totalDistance += sceneDist * 0.8; 
                    
                    // Stop if we raymarched far past the object
                    if (totalDistance > u_zoom + 4.0) break;
                }
                
                return accumulatedLight;
            }

            // Helper to compute color per pixel or subpixel
            vec3 getPixelColor(vec2 fragCoord) {
                vec2 uv = (2.0 * fragCoord.xy - u_resolution.xy) / u_resolution.y;
                
                float jitter = hash(uv) * 0.1;
                
                // Camera setup with dynamic zoom
                vec3 cameraOrigin = vec3(0.0, 0.0, -u_zoom);
                vec3 rayDirection = normalize(vec3(uv, u_perspective)); 

                // Apply interactive mouse rotation using precomputed matrices
                cameraOrigin.yz *= g_camRotY;
                cameraOrigin.xz *= g_camRotX;
                rayDirection.yz *= g_camRotY;
                rayDirection.xz *= g_camRotX;

                vec3 finalColor = renderRay(cameraOrigin, rayDirection, jitter);  
                return finalColor * finalColor; // contrast curve
            }

            void main() {
                // --- OPTIMIZATION: Precompute all rotation matrices ONCE per pixel ---
                float timeAnim = u_time * u_anim_speed;
                g_rotAnim = rotate2D(timeAnim);
                g_rotAnim07 = rotate2D(timeAnim * 0.7);
                g_rotFractalXY = rotate2D(0.7 + sin(u_time * 0.05) * 0.1);
                g_rotFractalXZ = rotate2D(0.5);
                g_camRotY = rotate2D(-u_mouse_rot.y);
                g_camRotX = rotate2D(-u_mouse_rot.x);
                
                vec3 finalColor = vec3(0.0);

                #ifdef USE_AA
                    // 2x2 Super Sampling Anti-Aliasing (SSAA)
                    for(int m = 0; m < 2; m++) {
                        for(int n = 0; n < 2; n++) {
                            // Subpixel offsets
                            vec2 offset = vec2(float(m), float(n)) / 2.0 - 0.25;
                            finalColor += getPixelColor(gl_FragCoord.xy + offset);
                        }
                    }
                    finalColor /= 4.0;
                #else
                    finalColor = getPixelColor(gl_FragCoord.xy);
                #endif

                gl_FragColor = vec4(finalColor, 1.0);
            }
        `;

        const vertexShader = `
            void main() {
                gl_Position = vec4(position, 1.0);
            }
        `;

        let material = new THREE.ShaderMaterial({
            vertexShader: vertexShader,
            fragmentShader: getFragmentShader(params.antiAlias),
            uniforms: uniforms
        });

        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- 5. LIL-GUI SETUP ---
        const gui = new lil.GUI({ title: 'Scene Settings' });

        // Update function for uniforms
        const updateUniforms = () => {
            uniforms.u_zoom.value = params.zoom;
            uniforms.u_perspective.value = params.perspective;
            uniforms.u_anim_speed.value = params.speed;
            uniforms.u_shape_size.value = params.shapeSize;
            uniforms.u_iterations.value = params.iterations;
            uniforms.u_fold.value.set(params.foldX, params.foldY, params.foldZ);
            uniforms.u_glow_intensity.value = params.glowIntensity;
            uniforms.u_glow_base.value = params.glowBase;
        };

        const renderFolder = gui.addFolder('Render Quality');
        renderFolder.add(params, 'dpr', [0.5, 0.7, 1.0, 1.5, 2.0]).name('DPR').onChange(v => {
            renderer.setPixelRatio(v);
            uniforms.u_resolution.value.set(window.innerWidth * v, window.innerHeight * v);
        });
        renderFolder.add(params, 'antiAlias').name('Anti-Aliasing').onChange(v => {
            // Re-compile shader with or without AA define
            material.fragmentShader = getFragmentShader(v);
            material.needsUpdate = true;
        });

        const camFolder = gui.addFolder('Camera & View');
        const zoomCtrl = camFolder.add(params, 'zoom', 1.0, 15.0).name('Zoom Distance').onChange(updateUniforms);
        camFolder.add(params, 'perspective', 0.5, 4.0).name('Perspective Z').onChange(updateUniforms);

        const animFolder = gui.addFolder('Animation');
        animFolder.add(params, 'speed', 0.0, 1.0).name('Rotation Speed').onChange(updateUniforms);

        const fractalFolder = gui.addFolder('Fractal Parameters');
        fractalFolder.add(params, 'shapeSize', 0.5, 3.0).name('Shape Size').onChange(updateUniforms);
        fractalFolder.add(params, 'iterations', 1, 10, 1).name('Iterations').onChange(updateUniforms);
        fractalFolder.add(params, 'foldX', 0.0, 3.0).name('Fold X').onChange(updateUniforms);
        fractalFolder.add(params, 'foldY', 0.0, 3.0).name('Fold Y').onChange(updateUniforms);
        fractalFolder.add(params, 'foldZ', 0.0, 3.0).name('Fold Z').onChange(updateUniforms);

        const lightFolder = gui.addFolder('Lighting');
        lightFolder.add(params, 'glowIntensity', 0.0, 0.1).name('Glow Intensity').onChange(updateUniforms);
        lightFolder.add(params, 'glowBase', 0.0, 1.0).name('Glow Base (Color)').onChange(updateUniforms);

        // Close GUI by default per instructions
        gui.close();

        // --- 6. MOUSE INTERACTION (DRAG TO ROTATE, SCROLL TO ZOOM) ---
        let isDragging = false;
        let previousMousePosition = { x: 0, y: 0 };
        
        // Target and current rotation for smooth interpolation
        const targetMouseRot = new THREE.Vector2(0, 0);
        const currentMouseRot = new THREE.Vector2(0, 0);
        
        window.addEventListener('mousedown', (e) => {
            if (e.target.tagName !== 'CANVAS') return;
            isDragging = true;
        });

        window.addEventListener('mouseup', () => {
            isDragging = false;
        });

        window.addEventListener('mousemove', (e) => {
            // Only capture movement on the canvas
            if (isDragging) {
                const deltaMove = {
                    x: e.offsetX - previousMousePosition.x,
                    y: e.offsetY - previousMousePosition.y
                };

                // Accumulate target rotation (scaled for sensitivity)
                // Inverted Y axis
                targetMouseRot.x += deltaMove.x * 0.01;
                targetMouseRot.y -= deltaMove.y * 0.01; 
                
                // Clamp Y rotation to avoid flipping the camera completely upside down
                // const maxPi = Math.PI / 2.0 - 0.1;
                // targetMouseRot.y = Math.max(-maxPi, Math.min(maxPi, targetMouseRot.y));
            }

            previousMousePosition = {
                x: e.offsetX,
                y: e.offsetY
            };
        });

        window.addEventListener('wheel', (e) => {
            if (e.target.tagName !== 'CANVAS') return;
            
            // Adjust zoom based on scroll
            params.zoom += e.deltaY * 0.005;
            params.zoom = Math.max(1.0, Math.min(params.zoom, 15.0)); // Clamp zoom
            
            // Sync with GUI and Shader
            zoomCtrl.updateDisplay();
            updateUniforms();
        });

        // --- 7. RESIZE HANDLING ---
        window.addEventListener('resize', () => {
            renderer.setSize(window.innerWidth, window.innerHeight);
            uniforms.u_resolution.value.set(window.innerWidth * params.dpr, window.innerHeight * params.dpr);
        });

        // --- 8. ANIMATION LOOP ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            uniforms.u_time.value = clock.getElapsedTime();
            
            // Smoothly interpolate current rotation towards target rotation
            currentMouseRot.lerp(targetMouseRot, 0.08);
            uniforms.u_mouse_rot.value.copy(currentMouseRot);
            
            renderer.render(scene, camera);
        }

        animate();