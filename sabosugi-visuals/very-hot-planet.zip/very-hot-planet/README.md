# Very Hot Planet

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/RNKpmQj](https://codepen.io/sabosugi/pen/RNKpmQj).

