       import * as THREE from 'three';
        import GUI from 'lil-gui';

        // --- Configuration & Parameters ---
        const params = {
            dpr: 1.0,
            speed: 0.7,
            
            // Colors from the original code
            color1: [0.349, 0.000, 1.000],
            color2: [1.000, 0.251, 0.000],
            color3: [0.000, 0.482, 1.000],
            
            // Global Settings
            globalRotX: 0.1,
            globalRotY: 0.03,
            coreSquash: -0.2,
            coreRadius: 2.8322,
            rayCorrection: 0.35,

            // Layer 1 (Base Gyroid)
            l1Twist: 43.1,
            l1TwistSpeed: 0.2,
            l1Scale: -0.2,
            l1ScaleY: -0.21,
            l1Thickness: 0.1,

            // Layer 2 (Secondary Gyroid)
            l2Twist: 0.3, // mathematically equals -(-0.3)
            l2TwistSpeed: -0.4,
            l2Scale: 1.5,
            l2ScaleY: 0.0,
            l2Thickness: 0.06,

            // Raymarching Steps
            stepMult: 0.48,
            stepMin: 0.017
        };

        // --- Scene Setup ---
        const scene = new THREE.Scene();
        
        // Orthographic camera for full-screen shader rendering
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        
        const renderer = new THREE.WebGLRenderer({ antialias: false });
        renderer.setPixelRatio(params.dpr);
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        // --- Shader Material ---
        const vertexShader = `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = vec4(position, 1.0);
            }
        `;

        const fragmentShader = `
            uniform float iTime;
            uniform vec2 iResolution;
            
            uniform float uSpeed;
            uniform vec3 uColor1;
            uniform vec3 uColor2;
            uniform vec3 uColor3;
            
            uniform float uGlobalRotX;
            uniform float uGlobalRotY;
            uniform float uCoreSquash;
            uniform float uCoreRadius;
            uniform float uRayCorrection;
            
            uniform float uL1Twist;
            uniform float uL1TwistSpeed;
            uniform float uL1Scale;
            uniform float uL1ScaleY;
            uniform float uL1Thickness;
            
            uniform float uL2Twist;
            uniform float uL2TwistSpeed;
            uniform float uL2Scale;
            uniform float uL2ScaleY;
            uniform float uL2Thickness;

            uniform float uStepMult;
            uniform float uStepMin;

            #define MAX_STEPS 42
            #define MAX_DIST 12.8

            mat2 rot(float a) {
                float s = sin(a), c = cos(a);
                return mat2(c, -s, s, c);
            }

            float map(vec3 p) {
                float t = iTime * uSpeed;
                
                // Global continuous rotation of the entire object
                p.xz *= rot(t * uGlobalRotX);
                p.yz *= rot(t * uGlobalRotY);

                // Core boundary: containment field
                float core = length(vec3(p.x, p.y * uCoreSquash, p.z)) - uCoreRadius;

                // --- DOMAIN WARPING & ANISOTROPIC SCALING (Layer 1) ---
                vec3 q = p;
                q.xz *= rot(q.y * uL1Twist + t * uL1TwistSpeed);
                q *= uL1Scale; 
                q.y *= uL1ScaleY; 

                float g1 = dot(sin(q), cos(q.yzx));
                float r1 = abs(g1) - uL1Thickness;

                // --- SECONDARY LAYER (Layer 2) ---
                vec3 q2 = p;
                q2.xz *= rot(q2.y * uL2Twist + t * uL2TwistSpeed);
                q2 *= uL2Scale;
                q2.y *= uL2ScaleY;
                
                float g2 = dot(sin(q2), cos(q2.yzx));
                float r2 = abs(g2) - uL2Thickness;

                // Combine the two gyroids
                float rays = max(r1, r2);
                rays *= uRayCorrection;

                // Confine strictly to the interior of the core boundary
                return max(core, rays); 
            }

            void main() {
                vec2 fragCoord = gl_FragCoord.xy;
                vec2 uv = (fragCoord - 0.5 * iResolution.xy) / iResolution.y;

                vec3 ro = vec3(0.0, 0.0, -4.5);
                vec3 rd = normalize(vec3(uv, 1.0));

                float t = iTime * uSpeed;
                
                // Slight camera wobble (kept minimal as in the provided snippet)
                ro.x += sin(t * 0.25) * 0.0;
                ro.y += cos(t * 0.3) * 0.0;
                rd.xy *= rot(sin(t * 0.15) * 0.00);

                float rayT = 0.0;
                vec3 glow = vec3(0.0);

                for(int i = 0; i < MAX_STEPS; i++) {
                    vec3 p = ro + rd * rayT;
                    float d = map(p);

                    // Spatial color mixing
                    float mixFactor1 = sin(p.y * 2.0 + p.x * 1.5 - t) * 0.5 + 0.5;
                    vec3 rayColor = mix(uColor1, uColor2, mixFactor1);
                    
                    float mixFactor2 = sin(p.z * 3.0 + t * 2.0) * 0.5 + 0.5;
                    rayColor = mix(rayColor, uColor3, mixFactor2);

                    // Volumetric accumulation
                    float intensity = 0.0018 / (abs(d) + 0.005);
                    glow += rayColor * intensity;

                    // Step forward using our custom multipliers
                    rayT += max(abs(d) * uStepMult, uStepMin);

                    if(rayT > MAX_DIST) break;
                }

                // Color grading
                vec3 finalColor = glow * 0.7;
                finalColor = smoothstep(0.0, 1.1, finalColor);
                finalColor = pow(finalColor, vec3(1.05));

                // Vignette effect
                finalColor *= 1.0 - length(uv) * 0.5;

                gl_FragColor = vec4(finalColor, 1.0);
            }
        `;

        const uniforms = {
            iTime: { value: 0.0 },
            iResolution: { value: new THREE.Vector2() },
            
            uSpeed: { value: params.speed },
            uColor1: { value: new THREE.Color().fromArray(params.color1) },
            uColor2: { value: new THREE.Color().fromArray(params.color2) },
            uColor3: { value: new THREE.Color().fromArray(params.color3) },
            
            uGlobalRotX: { value: params.globalRotX },
            uGlobalRotY: { value: params.globalRotY },
            uCoreSquash: { value: params.coreSquash },
            uCoreRadius: { value: params.coreRadius },
            uRayCorrection: { value: params.rayCorrection },
            
            uL1Twist: { value: params.l1Twist },
            uL1TwistSpeed: { value: params.l1TwistSpeed },
            uL1Scale: { value: params.l1Scale },
            uL1ScaleY: { value: params.l1ScaleY },
            uL1Thickness: { value: params.l1Thickness },
            
            uL2Twist: { value: params.l2Twist },
            uL2TwistSpeed: { value: params.l2TwistSpeed },
            uL2Scale: { value: params.l2Scale },
            uL2ScaleY: { value: params.l2ScaleY },
            uL2Thickness: { value: params.l2Thickness },

            uStepMult: { value: params.stepMult },
            uStepMin: { value: params.stepMin }
        };

        const material = new THREE.ShaderMaterial({
            vertexShader,
            fragmentShader,
            uniforms
        });

        // Use a simple plane to render the fragment shader across the entire screen
        const geometry = new THREE.PlaneGeometry(2, 2);
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // --- Resize Handler ---
        function onWindowResize() {
            const width = window.innerWidth;
            const height = window.innerHeight;
            const dpr = renderer.getPixelRatio();
            
            renderer.setSize(width, height);
            uniforms.iResolution.value.set(width * dpr, height * dpr);
        }
        window.addEventListener('resize', onWindowResize);
        
        // Initialize resolution
        onWindowResize();

        // --- GUI Setup ---
        const gui = new GUI({ title: 'Scene Settings' });
        
        gui.add(params, 'dpr', 0.1, 2.0, 0.1).name('DPR (Pixel Ratio)').onChange(v => {
            renderer.setPixelRatio(v);
            onWindowResize(); // Update uniforms and canvas size
        });
        gui.add(params, 'speed', 0.0, 3.0).name('Global Speed').onChange(v => uniforms.uSpeed.value = v);

        // Colors
        const colorsFolder = gui.addFolder('Colors');
        colorsFolder.addColor(params, 'color1').name('Color 1').onChange(v => uniforms.uColor1.value.fromArray(v));
        colorsFolder.addColor(params, 'color2').name('Color 2').onChange(v => uniforms.uColor2.value.fromArray(v));
        colorsFolder.addColor(params, 'color3').name('Color 3').onChange(v => uniforms.uColor3.value.fromArray(v));

        // Global Shape
        const shapeFolder = gui.addFolder('Global Shape');
        shapeFolder.add(params, 'globalRotX', -1.0, 1.0).name('Rotation X').onChange(v => uniforms.uGlobalRotX.value = v);
        shapeFolder.add(params, 'globalRotY', -1.0, 1.0).name('Rotation Y').onChange(v => uniforms.uGlobalRotY.value = v);
        shapeFolder.add(params, 'coreSquash', -2.0, 2.0).name('Core Squash (Y)').onChange(v => uniforms.uCoreSquash.value = v);
        shapeFolder.add(params, 'coreRadius', 0.1, 5.0).name('Core Radius').onChange(v => uniforms.uCoreRadius.value = v);
        shapeFolder.add(params, 'rayCorrection', 0.01, 1.0).name('SDF Correction').onChange(v => uniforms.uRayCorrection.value = v);

        // Layer 1
        const layer1Folder = gui.addFolder('Layer 1 (Main Rays)');
        layer1Folder.add(params, 'l1Twist', -100.0, 100.0).name('Twist Amount').onChange(v => uniforms.uL1Twist.value = v);
        layer1Folder.add(params, 'l1TwistSpeed', -2.0, 2.0).name('Twist Speed').onChange(v => uniforms.uL1TwistSpeed.value = v);
        layer1Folder.add(params, 'l1Scale', -2.0, 2.0).name('Scale Base').onChange(v => uniforms.uL1Scale.value = v);
        layer1Folder.add(params, 'l1ScaleY', -2.0, 2.0).name('Scale Y').onChange(v => uniforms.uL1ScaleY.value = v);
        layer1Folder.add(params, 'l1Thickness', 0.0, 0.5).name('Thickness').onChange(v => uniforms.uL1Thickness.value = v);

        // Layer 2
        const layer2Folder = gui.addFolder('Layer 2 (Detail Cuts)');
        layer2Folder.add(params, 'l2Twist', -5.0, 5.0).name('Twist Amount').onChange(v => uniforms.uL2Twist.value = v);
        layer2Folder.add(params, 'l2TwistSpeed', -2.0, 2.0).name('Twist Speed').onChange(v => uniforms.uL2TwistSpeed.value = v);
        layer2Folder.add(params, 'l2Scale', -5.0, 5.0).name('Scale Base').onChange(v => uniforms.uL2Scale.value = v);
        layer2Folder.add(params, 'l2ScaleY', -5.0, 5.0).name('Scale Y').onChange(v => uniforms.uL2ScaleY.value = v);
        layer2Folder.add(params, 'l2Thickness', 0.0, 0.5).name('Thickness').onChange(v => uniforms.uL2Thickness.value = v);

        // Advanced Raymarching
        const rayFolder = gui.addFolder('Raymarching System');
        rayFolder.add(params, 'stepMult', 0.1, 1.0).name('Step Multiplier').onChange(v => uniforms.uStepMult.value = v);
        rayFolder.add(params, 'stepMin', 0.001, 0.1).name('Min Step Size').onChange(v => uniforms.uStepMin.value = v);

        // Fold the GUI by default as requested
        gui.close();

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            // Update time for shader
            uniforms.iTime.value = clock.getElapsedTime();
            
            renderer.render(scene, camera);
        }

        animate();