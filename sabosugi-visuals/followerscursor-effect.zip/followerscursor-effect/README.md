# Followers - Cursor Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/MYbJQGZ](https://codepen.io/sabosugi/pen/MYbJQGZ).

