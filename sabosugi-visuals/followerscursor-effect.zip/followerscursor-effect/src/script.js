    // ===== Imports =====
    import * as THREE from 'https://esm.sh/three@0.160.0?bundle';

    // ===== Tunables =====
    // Rendering DPI: keep visual size stable across devices
    // Lock pixel ratio to 1 so increasing DPR never scales the scene.
    const DPR_LOCK = 1; // value ignored for sizing; scene is hard-locked to DPR=1

    // Physics grid resolution (cloth)
    const GRID_ROWS = 14;
    const GRID_COLS = 20;

    // Tile sizing and spacing in world units
    const TILE_SIZE = 0.10;      // base tile size before distance scaling
    const GAP       = 0.010;     // base gap between centers at full density
    const STEP      = TILE_SIZE + GAP; // physics rest distance

    // Visible-node decimation into a large chessboard
    // STRIDE must be even. The two phases form an offset chessboard.
    const STRIDE = 4;            // every 4th node, with half-cell offset for the other color

    // Minimal visual gap between neighbor tiles after scaling
    const MIN_GAP = 0.008;

    // Distance → scale mapping (near smaller, far larger)
    const SCALE_NEAR = 0.65;
    const SCALE_FAR  = 1.60;
    const SCALE_LERP = 0.15;    // lower = slower scale changes     // smooth scale changes per frame

    // Smooth motion for tiles (prevents micro jitter)
    const MESH_LERP  = 0.10;     // lower = slower tile motion     // 0..1 higher = snappier

    // Physics (Verlet) parameters
    const CONSTRAINT_ITER = 4;   // more iterations → stiffer cloth
    const DAMPING   = 0.975;    // lower = more damping, slower cloth     // velocity damping 0..1
    const GRAVITY   = new THREE.Vector3(0, -0.003, 0);
    const WIND_STRENGTH = 0.001; // subtle wind

    // Global board tilt
    const GROUP_TILT = new THREE.Euler(-0.12, 0.20, 0.0);

    // Corner follows cursor with small plane-space offset
    const CURSOR_OFFSET_PX  = 20;   // ~20 px offset away from cursor
    const TARGET_LERP_ALPHA = 0.09; // lower = slower cursor response // smooth target for less jitter

    // Example images
    const IMAGE_URLS = [
      'https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1468379/pexels-photo-1468379.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1080213/pexels-photo-1080213.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1704489/pexels-photo-1704489.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=800'
    ];

    // ===== Setup renderer/scene/camera =====
    const canvas = document.getElementById('app');
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(1); // hard lock: DPR never affects size
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x121213);

    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
    camera.position.set(0, 0, 9);

    // Plane to map cursor → world on the same tilt as the board
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    const catchPlane = new THREE.Mesh(new THREE.PlaneGeometry(100, 100), new THREE.MeshBasicMaterial({ visible:false }));
    catchPlane.rotation.copy(GROUP_TILT);
    scene.add(catchPlane);

    const group = new THREE.Group();
    group.rotation.copy(GROUP_TILT);
    scene.add(group);

    // ===== Cloth state (Verlet) =====
    const idx = (r,c)=> r*GRID_COLS + c;
    const pos  = Array(GRID_ROWS*GRID_COLS);
    const prev = Array(GRID_ROWS*GRID_COLS);

    const halfW = (GRID_COLS-1) * STEP * 0.5;
    const halfH = (GRID_ROWS-1) * STEP * 0.5;

    // For distance normalization when scaling by distance
    const SCALE_RADIUS = Math.hypot(halfW, halfH) || 1;

    for(let r=0;r<GRID_ROWS;r++){
      for(let c=0;c<GRID_COLS;c++){
        const p = new THREE.Vector3(-halfW + c*STEP, +halfH - r*STEP, 0);
        pos[idx(r,c)]  = p.clone();
        prev[idx(r,c)] = p.clone();
      }
    }

    // Build springs: structural, bend and shear
    const springs = [];
    const addSpring = (r1,c1,r2,c2,rest)=> springs.push({ a: idx(r1,c1), b: idx(r2,c2), rest });
    for(let r=0;r<GRID_ROWS;r++){
      for(let c=0;c<GRID_COLS;c++){
        if(c+1<GRID_COLS) addSpring(r,c, r,c+1, STEP);
        if(r+1<GRID_ROWS) addSpring(r,c, r+1,c, STEP);
        if(c+2<GRID_COLS) addSpring(r,c, r,c+2, STEP*2);
        if(r+2<GRID_ROWS) addSpring(r,c, r+2,c, STEP*2);
        if(r+1<GRID_ROWS && c+1<GRID_COLS) addSpring(r,c, r+1,c+1, Math.SQRT2*STEP);
        if(r+1<GRID_ROWS && c-1>=0)        addSpring(r,c, r+1,c-1, Math.SQRT2*STEP);
      }
    }

    // ===== Generate visible tiles on a true chessboard pattern =====
    const loader = new THREE.TextureLoader();
    loader.crossOrigin = 'anonymous';
    const tiles = [];
    const planeGeom = new THREE.PlaneGeometry(1,1);

    function applyCover(tex){
      // Make image behave like CSS background-size: cover for a square tile
      const img = tex.image; if(!img || !img.width || !img.height) return;
      const imageAspect = img.width / img.height; // plane aspect is 1
      tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
      tex.center.set(0.5, 0.5);
      if(imageAspect > 1){
        // Wider than tall → crop sides
        tex.repeat.set(1 / imageAspect, 1);
      } else {
        // Taller than wide → crop top/bottom
        tex.repeat.set(1, imageAspect);
      }
      tex.offset.set(0.5 - tex.repeat.x*0.5, 0.5 - tex.repeat.y*0.5);
      tex.needsUpdate = true;
    }

    // Two interleaved phases: phase A at multiples of STRIDE; phase B shifted by STRIDE/2
    if(STRIDE % 2 !== 0) console.warn('STRIDE should be even for proper chessboard.');

    for(let r=0;r<GRID_ROWS;r++){
      for(let c=0;c<GRID_COLS;c++){
        const phaseA = (r % STRIDE === 0) && (c % STRIDE === 0);
        const phaseB = (r % STRIDE === STRIDE/2) && (c % STRIDE === STRIDE/2);
        if(!(phaseA || phaseB)) continue;

        const tex = loader.load(IMAGE_URLS[tiles.length % IMAGE_URLS.length], t=>applyCover(t));
        tex.colorSpace = THREE.SRGBColorSpace;
        const mat = new THREE.MeshBasicMaterial({ map: tex, side: THREE.DoubleSide, color: 0xffffff, transparent: true });
        const m = new THREE.Mesh(planeGeom, mat);
        m.scale.set(TILE_SIZE, TILE_SIZE, 1);
        m.userData.prevScale = 1;
        group.add(m);
        tiles.push({ mesh: m, r, c, prevScale: 1 });
      }
    }

    // ===== Cursor / target handling =====
    function onPointerMove(e){
      const rect = canvas.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      mouse.set(x, y);
    }
    window.addEventListener('pointermove', onPointerMove, { passive:true });

    const targetLocal = new THREE.Vector3(-halfW, +halfH, 0); // start at top-left
    function worldToGroupLocal(v){ return group.worldToLocal(v.clone()); }

    function sampleTarget(){
      raycaster.setFromCamera(mouse, camera);
      const hit = raycaster.intersectObject(catchPlane, false)[0];
      if(!hit) return;

      // Compute ~20px offset along the plane toward bottom-right
      const rect = canvas.getBoundingClientRect();
      const ndcDx = (CURSOR_OFFSET_PX / rect.width) * 2;
      const ndcDy = (CURSOR_OFFSET_PX / rect.height) * 2;
      const mouseOff = new THREE.Vector2(mouse.x + ndcDx, mouse.y - ndcDy);
      raycaster.setFromCamera(mouseOff, camera);
      const hitOff = raycaster.intersectObject(catchPlane, false)[0];

      let desired = hit.point.clone();
      if(hitOff){
        const offset = hitOff.point.clone().sub(hit.point);
        desired.add(offset); // place anchor at bottom-right of cursor
      }
      desired = worldToGroupLocal(desired);
      targetLocal.lerp(desired, TARGET_LERP_ALPHA);
    }

    // ===== Simulation =====
    const tmp = new THREE.Vector3();
    const dt2 = (1/60) * (1/60);

    function integrate(){
      const t = performance.now() * 0.001;
      for(let i=0;i<pos.length;i++){
        const p = pos[i];
        const pp = prev[i];
        const vx = (p.x - pp.x) * DAMPING;
        const vy = (p.y - pp.y) * DAMPING;
        const vz = (p.z - pp.z) * DAMPING;
        pp.set(p.x, p.y, p.z);
        tmp.copy(GRAVITY);
        if(WIND_STRENGTH>0){
          const w = Math.sin(t*1.6 + (i%GRID_COLS)*0.33 + Math.floor(i/GRID_COLS)*0.39) * WIND_STRENGTH;
          tmp.z += w;
        }
        p.x += vx + tmp.x * dt2;
        p.y += vy + tmp.y * dt2;
        p.z += vz + tmp.z * dt2;
      }

      // Pin top-left corner to smoothed target
      const anchor = idx(0,0);
      pos[anchor].copy(targetLocal);
      prev[anchor].copy(targetLocal);

      // Satisfy constraints
      for(let k=0;k<CONSTRAINT_ITER;k++){
        for(const s of springs){
          const a = pos[s.a];
          const b = pos[s.b];
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const dz = b.z - a.z;
          const dist = Math.hypot(dx, dy, dz);
          if(dist === 0) continue;
          const diff = (dist - s.rest) / dist * 0.5;
          if(s.a !== anchor){ a.x += dx*diff; a.y += dy*diff; a.z += dz*diff; }
          if(s.b !== anchor){ b.x -= dx*diff; b.y -= dy*diff; b.z -= dz*diff; }
        }
      }
    }

    function renderTiles(){
      for(const it of tiles){
        const p = pos[idx(it.r, it.c)];
        // Smooth tile positions for visual stability
        if(!it.mesh.userData._inited){
          it.mesh.position.copy(p);
          it.mesh.userData._inited = true;
        } else {
          it.mesh.position.lerp(p, MESH_LERP);
        }

        // Distance-based uniform scale with clamping to keep a minimal gap
        const d = it.mesh.position.distanceTo(targetLocal);
        const t = Math.min(d / SCALE_RADIUS, 1);
        const sNew = THREE.MathUtils.lerp(SCALE_NEAR, SCALE_FAR, t);
        const s = THREE.MathUtils.lerp(it.prevScale, sNew, SCALE_LERP);
        it.prevScale = s;

        // Center-to-center spacing between visible nodes
        const spacing = STEP * STRIDE;
        const maxSize = Math.max(0, spacing - MIN_GAP);
        const size = Math.min(TILE_SIZE * s, maxSize);
        it.mesh.scale.set(size, size, 1);

        it.mesh.lookAt(camera.position);
      }
    }

    // ===== Resize =====
    function onResize(){
      const w = innerWidth, h = innerHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w/h; camera.updateProjectionMatrix();
    }
    addEventListener('resize', onResize); onResize();

    // ===== Loop =====
    function animate(){
      requestAnimationFrame(animate);
      sampleTarget();
      integrate();
      renderTiles();
      renderer.render(scene, camera);
    }
    animate();