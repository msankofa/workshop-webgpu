# Vector Plankton – Three.js (You can load your SVG form ) – Support me by PayPal: https://paypal.com/paypalme/sabosugi

A Pen created on CodePen.

Original URL: [https://codepen.io/sabosugi/pen/pvbKxKQ](https://codepen.io/sabosugi/pen/pvbKxKQ).

