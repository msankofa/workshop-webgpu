       import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
        import { FXAAShader } from 'three/addons/shaders/FXAAShader.js'; // Added FXAA for anti-aliasing
        import GUI from 'lil-gui';

        // --- SCENE SETUP ---
        const scene = new THREE.Scene();
        // Clear sky light blue background
        scene.background = new THREE.Color(0x87CEEB);
        scene.fog = new THREE.FogExp2(0x87CEEB, 0.02);

        // Camera positioned between the two hills
        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100);
        camera.position.set(0, 2.3, 18);
        camera.lookAt(0, 0, 0);

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(1); // Set default DPR to 1
        document.body.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.maxPolarAngle = Math.PI / 2 - 0.05; // Prevent going below ground
        controls.minDistance = 2;
        controls.maxDistance = 40;
        controls.target.set(0, 1, 0);
        controls.autoRotate = true; // Auto-rotate camera enabled
        controls.autoRotateSpeed = 0.5; // Slow and smooth rotation
        controls.enableZoom = false; // Disable zooming with mouse wheel
        controls.enablePan = false; // Disable panning (moving camera position)
        controls.enableRotate = false; // Disable manual rotation with mouse

        // --- POST PROCESSING (DEPTH-AWARE DOF & FXAA) ---
        const renderTarget = new THREE.WebGLRenderTarget(window.innerWidth, window.innerHeight, {
            format: THREE.RGBAFormat,
            depthTexture: new THREE.DepthTexture(),
            depthBuffer: true,
            samples: 16 // Hardware MSAA
        });

        const composer = new EffectComposer(renderer, renderTarget);
        composer.setPixelRatio(1); // Match initial DPR
        
        // 1. Render the main scene
        const renderPass = new RenderPass(scene, camera);
        composer.addPass(renderPass);
        
        // 2. Custom Artifact-Free Depth-Aware Near-Field DoF Shader
        const nearDoFShader = {
            uniforms: {
                tDiffuse: { value: null },
                tDepth: { value: null }, // Handled automatically
                cameraNear: { value: camera.near },
                cameraFar: { value: camera.far },
                focusNear: { value: 0.0 },  // From screenshot
                focusSharp: { value: 6.08 }, // From screenshot
                maxBlur: { value: 0.0 },   // From screenshot
                aspect: { value: window.innerWidth / window.innerHeight }
            },
            vertexShader: `
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                #include <packing>
                
                uniform sampler2D tDiffuse;
                uniform sampler2D tDepth;
                uniform float cameraNear;
                uniform float cameraFar;
                uniform float focusNear;
                uniform float focusSharp;
                uniform float maxBlur;
                uniform float aspect;
                
                varying vec2 vUv;
                
                void main() {
                    vec4 centerColor = texture2D(tDiffuse, vUv);
                    float centerDepth = texture2D(tDepth, vUv).x;
                    float centerDist = -perspectiveDepthToViewZ(centerDepth, cameraNear, cameraFar);
                    
                    // 1.0 means fully blurred (near), 0.0 means sharp (far)
                    float centerBlur = 1.0 - smoothstep(focusNear, focusSharp, centerDist);
                    
                    // Optimization: if the pixel is far away (sharp), skip the heavy blur loop
                    if (centerBlur < 0.005) {
                        gl_FragColor = centerColor;
                        return;
                    }
                    
                    // True Smooth Gaussian Approximation using Vogel Disk
                    // This completely eliminates all grid lines, stalks, and ringing artifacts
                    const int SAMPLES = 150; 
                    const float GOLDEN_ANGLE = 2.39996323;
                    
                    vec4 sum = vec4(0.0);
                    float totalWeight = 0.0;
                    
                    // Scale blur radius based on depth (maxBlur at camera, 0 at focusSharp)
                    vec2 radius = vec2(maxBlur * centerBlur, maxBlur * centerBlur * aspect);
                    
                    for (int i = 0; i < SAMPLES; i++) {
                        float t = float(i) / float(SAMPLES);
                        float r = sqrt(t);
                        float theta = float(i) * GOLDEN_ANGLE;
                        
                        vec2 offset = vec2(cos(theta), sin(theta)) * r * radius;
                        vec2 sampleUv = vUv + offset;
                        
                        // Clamp UVs to avoid edge screen bleeding from outside the canvas
                        sampleUv = clamp(sampleUv, 0.0, 1.0);
                        
                        vec4 sColor = texture2D(tDiffuse, sampleUv);
                        
                        // Pure Gaussian bell curve weight for perfect softness
                        float gaussWeight = exp(-(r * r) * 5.0);
                        
                        sum += sColor * gaussWeight;
                        totalWeight += gaussWeight;
                    }
                    
                    gl_FragColor = sum / totalWeight;
                }
            `
        };

        const dofPass = new ShaderPass(nearDoFShader);
        dofPass.uniforms.tDepth.value = renderTarget.depthTexture;
        composer.addPass(dofPass);

        // 3. FXAA Pass (Fixes the "jaggies" and stepping artifacts on grass edges)
        const fxaaPass = new ShaderPass(FXAAShader);
        fxaaPass.uniforms['resolution'].value.set(1 / window.innerWidth, 1 / window.innerHeight);
        composer.addPass(fxaaPass);

        // --- LIGHTING ---
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
        scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(10, 20, 10);
        scene.add(directionalLight);

        // --- GLOBAL PARAMS ---
        const params = {
            dpr: 1.0, // Default Device Pixel Ratio
            windAngle: 200.52, // Degrees
            hill1Height: 1.1775, 
            hill2Height: 1.2675, 
            groundColor: '#9ebbff', 
            skyColor: '#c7efff', 
            color1: '#3de8ff', 
            color2: '#fff3d1', 
            color3: '#d1b8ff'  
        };

        // --- GRASS (HAIRS) SETUP ---
        const grassWidth = 0.012; 
        const grassHeight = 1.0;
        const grassGeo = new THREE.PlaneGeometry(grassWidth, grassHeight, 1, 8);
        grassGeo.translate(0, grassHeight / 2, 0);

        // Custom Shader Material for Holo effect and Wind
        const grassMaterial = new THREE.ShaderMaterial({
            uniforms: {
                uTime: { value: 0 },
                uWindSpeed: { value: 3.1 }, 
                uWindStrength: { value: 0.624 }, 
                uWindDir: { value: new THREE.Vector2(1, 1).normalize() },
                uHoloScale: { value: 0.05 }, 
                uHoloSpeed: { value: 0.1 }, 
                uColor1: { value: new THREE.Color(params.color1) },
                uColor2: { value: new THREE.Color(params.color2) },
                uColor3: { value: new THREE.Color(params.color3) }
            },
            vertexShader: `
                uniform float uTime;
                uniform float uWindSpeed;
                uniform float uWindStrength;
                uniform vec2 uWindDir;
                
                varying vec2 vUv;
                varying vec3 vWorldPosition;
                
                // Simplex Noise function for more natural wind
                vec3 permute(vec3 x) { return mod(((x*34.0)+1.0)*x, 289.0); }
                float snoise(vec2 v){
                  const vec4 C = vec4(0.211324865405187, 0.366025403784439,
                           -0.577350269189626, 0.024390243902439);
                  vec2 i  = floor(v + dot(v, C.yy) );
                  vec2 x0 = v -   i + dot(i, C.xx);
                  vec2 i1;
                  i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
                  vec4 x12 = x0.xyxy + C.xxzz;
                  x12.xy -= i1;
                  i = mod(i, 289.0);
                  vec3 p = permute( permute( i.y + vec3(0.0, i1.y, 1.0 ))
                  + i.x + vec3(0.0, i1.x, 1.0 ));
                  vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
                  m = m*m ;
                  m = m*m ;
                  vec3 x = 2.0 * fract(p * C.www) - 1.0;
                  vec3 h = abs(x) - 0.5;
                  vec3 ox = floor(x + 0.5);
                  vec3 a0 = x - ox;
                  m *= 1.79284291400159 - 0.85373472095314 * ( a0*a0 + h*h );
                  vec3 g;
                  g.x  = a0.x  * x0.x  + h.x  * x0.y;
                  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
                  return 130.0 * dot(m, g);
                }
                
                void main() {
                    vUv = uv;
                    
                    vec4 worldPositionBase = modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
                    vWorldPosition = worldPositionBase.xyz;
                    
                    vec2 windUv = worldPositionBase.xz * 0.05 + uTime * uWindSpeed * 0.1;
                    float windNoise = snoise(windUv) * 0.5 + 0.5; 
                    
                    float bend = pow(vUv.y, 2.5);
                    float totalBend = bend * (0.4 + windNoise * uWindStrength);
                    
                    vec4 worldPos = modelMatrix * instanceMatrix * vec4(position, 1.0);
                    
                    worldPos.x += uWindDir.x * totalBend;
                    worldPos.z += uWindDir.y * totalBend;
                    
                    gl_Position = projectionMatrix * viewMatrix * worldPos;
                }
            `,
            fragmentShader: `
                uniform float uTime;
                uniform float uHoloScale;
                uniform float uHoloSpeed;
                uniform vec3 uColor1;
                uniform vec3 uColor2;
                uniform vec3 uColor3;
                
                varying vec2 vUv;
                varying vec3 vWorldPosition;
                
                void main() {
                    float t = fract(vWorldPosition.x * uHoloScale + vWorldPosition.z * uHoloScale * 0.5 + uTime * uHoloSpeed);
                    
                    vec3 holoColor;
                    
                    if (t < 0.3333) {
                        holoColor = mix(uColor1, uColor2, t * 3.0);
                    } else if (t < 0.6666) {
                        holoColor = mix(uColor2, uColor3, (t - 0.3333) * 3.0);
                    } else {
                        holoColor = mix(uColor3, uColor1, (t - 0.6666) * 3.0);
                    }
                    
                    float gradient = smoothstep(0.0, 1.0, vUv.y);
                    vec3 finalColor = mix(holoColor * 0.6, holoColor, gradient);
                    
                    gl_FragColor = vec4(finalColor, 1.0);
                }
            `,
            side: THREE.DoubleSide
        });

        const hillObjects = [];
        const dummy = new THREE.Object3D();

        // --- HILL & GRASS CREATION FUNCTION ---
        function createHill(offsetX, offsetZ, heightParamKey) {
            const hillGroup = new THREE.Group();
            hillGroup.position.set(offsetX, 0, offsetZ);

            const currentHeight = params[heightParamKey];

            const groundGeo = new THREE.PlaneGeometry(50, 50, 128, 128);
            groundGeo.rotateX(-Math.PI / 2); 
            
            const posAttrib = groundGeo.attributes.position;
            for (let i = 0; i < posAttrib.count; i++) {
                const x = posAttrib.getX(i);
                const z = posAttrib.getZ(i);
                const distanceSq = x * x + z * z;
                const y = Math.exp(-distanceSq * 0.02) * currentHeight - (currentHeight * 0.25);
                posAttrib.setY(i, y);
            }
            groundGeo.computeVertexNormals();

            const groundMat = new THREE.MeshStandardMaterial({ 
                color: params.groundColor,
                roughness: 1.0,
                metalness: 0.0
            });
            const groundMesh = new THREE.Mesh(groundGeo, groundMat);
            hillGroup.add(groundMesh);

            const grassCount = 250000; 
            const grassMesh = new THREE.InstancedMesh(grassGeo, grassMaterial, grassCount);
            
            const spawnRadius = 20;
            const grassData = []; 

            for (let i = 0; i < grassCount; i++) {
                const r = Math.sqrt(Math.random()) * spawnRadius;
                const theta = Math.random() * 2 * Math.PI;
                
                const x = r * Math.cos(theta);
                const z = r * Math.sin(theta);
                const distanceSq = x * x + z * z;
                const y = Math.exp(-distanceSq * 0.02) * currentHeight - (currentHeight * 0.25);

                const rotY = Math.random() * Math.PI * 2;
                const scale = 0.6 + Math.random() * 0.7;

                grassData.push({ x, z, rot: rotY, scale });

                dummy.position.set(x, y, z);
                dummy.rotation.y = rotY;
                dummy.scale.set(scale, scale, scale);
                
                dummy.updateMatrix();
                grassMesh.setMatrixAt(i, dummy.matrix);
            }
            
            hillGroup.add(grassMesh);
            scene.add(hillGroup);

            hillObjects.push({
                key: heightParamKey,
                groundGeo: groundGeo,
                groundMat: groundMat, 
                grassMesh: grassMesh,
                grassData: grassData
            });
        }

        function updateHills() {
            hillObjects.forEach(hill => {
                const heightMult = params[hill.key];
                
                const posAttrib = hill.groundGeo.attributes.position;
                for(let i = 0; i < posAttrib.count; i++) {
                    const x = posAttrib.getX(i);
                    const z = posAttrib.getZ(i);
                    const distanceSq = x * x + z * z;
                    const y = Math.exp(-distanceSq * 0.02) * heightMult - (heightMult * 0.25);
                    posAttrib.setY(i, y);
                }
                posAttrib.needsUpdate = true;
                hill.groundGeo.computeVertexNormals();

                for(let i = 0; i < hill.grassData.length; i++) {
                    const data = hill.grassData[i];
                    const distanceSq = data.x * data.x + data.z * data.z;
                    const y = Math.exp(-distanceSq * 0.02) * heightMult - (heightMult * 0.25);
                    
                    dummy.position.set(data.x, y, data.z);
                    dummy.rotation.y = data.rot;
                    dummy.scale.set(data.scale, data.scale, data.scale);
                    dummy.updateMatrix();
                    
                    hill.grassMesh.setMatrixAt(i, dummy.matrix);
                }
                hill.grassMesh.instanceMatrix.needsUpdate = true;
            });
        }

        function updateWindDirection() {
            const angleRad = params.windAngle * Math.PI / 180;
            grassMaterial.uniforms.uWindDir.value.set(Math.cos(angleRad), Math.sin(angleRad));
        }

        function updateColors() {
            grassMaterial.uniforms.uColor1.value.set(params.color1);
            grassMaterial.uniforms.uColor2.value.set(params.color2);
            grassMaterial.uniforms.uColor3.value.set(params.color3);
            hillObjects.forEach(hill => {
                hill.groundMat.color.set(params.groundColor);
            });
            scene.background.set(params.skyColor);
            scene.fog.color.set(params.skyColor);
        }

        createHill(-12, 0, 'hill1Height');
        createHill(12, 0, 'hill2Height');
        updateWindDirection();
        updateColors(); 

        // --- GUI SETUP ---
        const gui = new GUI({ title: 'Scene Settings' });
        
        const generalFolder = gui.addFolder('General');
        generalFolder.add(params, 'dpr', 0.1, 3.0).step(0.1).name('Resolution (DPR)').onChange(() => {
            renderer.setPixelRatio(params.dpr);
            composer.setPixelRatio(params.dpr);
        });
        
        const windFolder = gui.addFolder('Wind Controls');
        windFolder.add(grassMaterial.uniforms.uWindSpeed, 'value', 0.0, 5.0).name('Wind Speed');
        windFolder.add(grassMaterial.uniforms.uWindStrength, 'value', 0.0, 2.0).name('Wind Strength');
        const windAngleController = windFolder.add(params, 'windAngle', 0, 360).name('Wind Direction').onChange(updateWindDirection);
        
        const hillsFolder = gui.addFolder('Hills Configuration');
        hillsFolder.add(params, 'hill1Height', 0.5, 8.0).name('Hill 1 Height').onChange(updateHills);
        hillsFolder.add(params, 'hill2Height', 0.5, 8.0).name('Hill 2 Height').onChange(updateHills);

        const holoFolder = gui.addFolder('Holo Gradient');
        holoFolder.add(grassMaterial.uniforms.uHoloScale, 'value', 0.01, 0.2).name('Color Spread');
        holoFolder.add(grassMaterial.uniforms.uHoloSpeed, 'value', 0.0, 1.0).name('Color Shift Speed');

        const colorsFolder = gui.addFolder('Colors');
        colorsFolder.addColor(params, 'skyColor').name('Sky Color').onChange(updateColors);
        colorsFolder.addColor(params, 'groundColor').name('Ground Color').onChange(updateColors);
        colorsFolder.addColor(params, 'color1').name('Gradient Color 1').onChange(updateColors);
        colorsFolder.addColor(params, 'color2').name('Gradient Color 2').onChange(updateColors);
        colorsFolder.addColor(params, 'color3').name('Gradient Color 3').onChange(updateColors);

        const dofFolder = gui.addFolder('Foreground Depth of Field');
        dofFolder.add(dofPass.uniforms.focusNear, 'value', 0.0, 20.0).name('Blurry Distance');
        dofFolder.add(dofPass.uniforms.focusSharp, 'value', 0.0, 40.0).name('Sharp Distance');
        dofFolder.add(dofPass.uniforms.maxBlur, 'value', 0.0, 0.1).name('Max Blur').step(0.001);

        gui.close();

        // --- ANIMATION LOOP ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);
            
            const elapsedTime = clock.getElapsedTime();
            grassMaterial.uniforms.uTime.value = elapsedTime;
            
            params.windAngle = (params.windAngle + 0.4) % 360;
            updateWindDirection();
            if (windAngleController) {
                windAngleController.updateDisplay();
            }
            
            controls.update();
            composer.render();
        }

        // --- RESIZE HANDLER ---
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight); 
            dofPass.uniforms.aspect.value = window.innerWidth / window.innerHeight;
            fxaaPass.uniforms['resolution'].value.set(1 / window.innerWidth, 1 / window.innerHeight); // Update FXAA resolution
        });

        animate();