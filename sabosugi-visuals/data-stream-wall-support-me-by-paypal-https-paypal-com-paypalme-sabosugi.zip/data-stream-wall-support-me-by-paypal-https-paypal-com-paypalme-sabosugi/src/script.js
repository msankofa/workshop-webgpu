        import * as THREE from 'three';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
        import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
        import GUI from 'https://unpkg.com/lil-gui@0.19.1/dist/lil-gui.esm.min.js';

        // --- Core Setup ---
        const scene = new THREE.Scene();
        
        // Settings
        const SETTINGS = {
            curveSoftness: 8.0,
            curveWidth: 0.3024,
            curveDepth: 0.9504,
            height: 1.2936,
            fov: 118.91,
            lineDensity: 1.0, 
            particleSize: 12.0, 
            speed: 6.9,
            bloomStrength: 0.3,
            bloomRadius: 1.198,
            chromaticAberration: 0.01005,
            edgeBlurStrength: 0.0115,
            cameraY: 0.0, 
            cameraSpinSpeed: 0.0, 
            wallTilt: 0.0, 
            dpr: 1.0, // Device Pixel Ratio
            color1: '#00d4ff', 
            color2: '#b32d00', 
            color3: '#2465ff', 
            color4: '#0044ff', 
            bgColor: '#02000a'
        };

        // Standard subtle fog
        scene.fog = new THREE.FogExp2(SETTINGS.bgColor, 0.002);
        scene.background = new THREE.Color(SETTINGS.bgColor);

        const camera = new THREE.PerspectiveCamera(SETTINGS.fov, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, SETTINGS.cameraY, 0);

        const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(SETTINGS.dpr); 
        document.body.appendChild(renderer.domElement);

        document.getElementById('loading').style.display = 'none';

        // --- Generate Data Texture for Numbers ---
        const canvasTexture = document.createElement('canvas');
        canvasTexture.width = 1024;
        canvasTexture.height = 1024;
        const ctx = canvasTexture.getContext('2d');
        
        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, 1024, 1024);
        
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 26px monospace'; 
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Array of Katakana and numbers for Matrix effect
        const chars = 'ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789';
        // Grid size adjusted so it maps perfectly to 1024 (1024 / 32 = 32 cells)
        const gridSize = 32; 
        for(let x = 0; x < 1024; x += gridSize) {
            for(let y = 0; y < 1024; y += gridSize) {
                if(Math.random() > 0.2) {
                    const char = chars[Math.floor(Math.random() * chars.length)];
                    ctx.fillText(char, x + gridSize/2, y + gridSize/2);
                }
            }
        }
        
        const dataTexture = new THREE.CanvasTexture(canvasTexture);
        dataTexture.wrapS = THREE.RepeatWrapping;
        dataTexture.wrapT = THREE.RepeatWrapping;
        dataTexture.minFilter = THREE.LinearMipmapLinearFilter;
        dataTexture.magFilter = THREE.LinearFilter;
        dataTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

        // --- Create a Master Group ---
        const tunnelGroup = new THREE.Group();
        scene.add(tunnelGroup);

        // --- Custom Shader Material for the Data Wall (Cylinder) ---
        const wallVertexShader = `
            varying vec2 vUv;
            varying vec3 vPosition;
            uniform float uCurveSoftness; 
            
            void main() {
                vUv = uv;
                vec3 pos = position; 
                
                // Superellipse deformation using normalized X (cos of angle)
                float angle = atan(pos.z, pos.x);
                float normX = cos(angle);
                float n = uCurveSoftness; 
                
                float absZ = pow(max(0.00001, 1.0 - pow(abs(normX), n)), 1.0 / n) * 100.0;
                pos.z = sign(sin(angle)) * absZ;

                vPosition = pos; 
                gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
            }
        `;

        const wallFragmentShader = `
            varying vec2 vUv;
            varying vec3 vPosition;

            uniform float uTime;
            uniform float uSpeed;
            uniform float uLineDensity; 
            uniform vec3 uColor1;
            uniform vec3 uColor2;
            uniform vec3 uColor3;
            uniform vec3 uColor4;
            uniform vec3 uBgColor;
            uniform sampler2D uDataTexture; 
            
            float random(vec2 st) {
                return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
            }

            float noise(vec2 st) {
                vec2 i = floor(st);
                vec2 f = fract(st);
                float a = random(i);
                float b = random(i + vec2(1.0, 0.0));
                float c = random(i + vec2(0.0, 1.0));
                float d = random(i + vec2(1.0, 1.0));
                vec2 u = f * f * (3.0 - 2.0 * f);
                return mix(a, b, u.x) + (c - a)* u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
            }

            vec3 getLineLayer(vec3 pos, float trackCount, float speedBase, float seed) {
                float trackHeight = 80.0 / trackCount;
                float trackId = floor((pos.y + 40.0) / trackHeight);

                float trackActive = random(vec2(trackId, seed));
                if (trackActive > 0.35) return vec3(0.0); // Empty track

                float trackCenter = -40.0 + (trackId + 0.5) * trackHeight;
                float distY = abs(pos.y - trackCenter);

                float maxThickness = trackHeight * 0.35; 
                float thickness = maxThickness * mix(0.3, 1.0, random(vec2(trackId, seed + 1.0)));

                float aa = 0.03; 
                float profile = smoothstep(thickness + aa, thickness - aa, distY);
                
                if (profile <= 0.0) return vec3(0.0); 

                float speedMult = mix(0.5, 2.0, random(vec2(trackId, seed + 2.0)));
                float angle = atan(pos.z, pos.x);
                float currentAngle = angle + uTime * uSpeed * 0.015 * speedBase * speedMult;

                float isDashed = step(0.1, random(vec2(trackId, seed + 4.0))); 
                float dashPattern = 1.0;
                if (isDashed > 0.0) {
                    float dashScale = mix(3.0, 12.0, random(vec2(trackId, seed + 5.0)));
                    vec2 circlePos = vec2(cos(currentAngle), sin(currentAngle)) * dashScale;
                    float n = noise(circlePos + vec2(seed * 10.0, trackId)); 
                    float threshold = mix(0.4, 0.6, random(vec2(trackId, seed + 6.0)));
                    dashPattern = smoothstep(threshold - 0.05, threshold + 0.05, n);
                }

                // FIXED: Text boosting inside the active neon lines with correct aspect ratio
                float normAngle = (currentAngle + 3.14159265) / 6.2831853;
                // Scale UV properly: 32 repeats horizontally, 0.05 vertically to maintain square aspect
                vec2 textUv = vec2(normAngle * 32.0, pos.y * 0.05);
                float textMask = texture2D(uDataTexture, textUv).r;
                float textBoost = mix(0.6, 2.0, textMask); 

                vec3 color;
                float cRand = random(vec2(trackId, seed + 7.0));
                if (cRand < 0.25) color = uColor1;
                else if (cRand < 0.5) color = uColor2;
                else if (cRand < 0.75) color = uColor3;
                else color = uColor4;

                float core = smoothstep(thickness * 0.5, 0.0, distY);
                
                vec3 finalColor = color * profile * dashPattern * 1.5 * textBoost + vec3(core * dashPattern * 0.8 * textBoost);

                return finalColor;
            }

            vec3 getCompositeLines(vec3 pos, float isReflection) {
                vec3 color = vec3(0.0);
                
                // --- Background small data characters layer ---
                float angle = atan(pos.z, pos.x);
                // Moves at a slightly different speed to create depth parallax
                float bgAngle = angle + uTime * uSpeed * 0.015 * 0.8; 
                float normAngle = (bgAngle + 3.14159265) / 6.2831853;
                
                // FIXED: Perfect 1:1 Aspect Ratio Mapping for characters.
                // 64 repeats horizontally, 0.1 vertically ensures characters are perfectly square
                vec2 bgUv = vec2(normAngle * 64.0, pos.y * 0.1);
                
                // Smoothstep to keep text sharp
                float bgMask = texture2D(uDataTexture, bgUv).r;
                bgMask = smoothstep(0.2, 0.8, bgMask);
                
                // Calculate global cell coordinates (Texture is a 32x32 grid)
                float colId = floor(normAngle * 64.0 * 32.0);
                float rowId = floor(pos.y * 0.1 * 32.0);
                
                // Randomly show only some columns and rows (Matrix effect)
                float bgVisibility = step(0.4, random(vec2(colId, 77.7))); // 60% of columns are visible
                bgVisibility *= step(0.15, random(vec2(colId, rowId))); // Add some gaps
                
                // --- NEW: Dynamic Opacity Flicker for each character ---
                // Generate a unique speed and offset for every single character cell
                float flickerSpeed = mix(1.0, 8.0, random(vec2(colId, rowId + 1.0)));
                float flickerOffset = random(vec2(colId, rowId + 2.0)) * 6.283;
                float flicker = sin(uTime * flickerSpeed + flickerOffset);
                
                // Smoothly interpolate between 15% opacity and 100% opacity
                float pulseVisibility = mix(0.15, 1.0, smoothstep(-0.5, 0.5, flicker));
                bgVisibility *= pulseVisibility;
                // --------------------------------------------------------
                
                vec3 baseBgColor = mix(uColor4, uColor1, random(vec2(colId, 33.3)));
                
                // Add character layer to the background
                color += baseBgColor * bgMask * bgVisibility * 1.8; 
                // ----------------------------------------------

                // Main neon lines
                color += getLineLayer(pos, 30.0 * uLineDensity, 1.0, 11.0);
                color += getLineLayer(pos, 70.0 * uLineDensity, 1.5, 22.0);
                color += getLineLayer(pos, 150.0 * uLineDensity, 2.5, 33.0);
                
                // Fade out edges
                if (isReflection == 1.0) {
                    float fade = smoothstep(-35.0, -12.0, pos.y);
                    color *= 0.4 * fade;
                } else {
                    float fade = smoothstep(40.0, 20.0, pos.y);
                    color *= fade;
                }
                
                return color;
            }

            void main() {
                vec3 color = uBgColor; 
                
                float floorLevel = -12.0; 
                
                if (vPosition.y > floorLevel) {
                    color += getCompositeLines(vPosition, 0.0);
                } else {
                    vec3 reflectedPos = vPosition;
                    reflectedPos.y = floorLevel + (floorLevel - vPosition.y); 
                    color += getCompositeLines(reflectedPos, 1.0);
                    color += vec3(0.0, 0.01, 0.03); 
                }
                
                float horizonGlow = smoothstep(0.5, 0.0, abs(vPosition.y - floorLevel));
                color += uColor1 * horizonGlow * 0.3;

                gl_FragColor = vec4(color, 1.0); 
            }
        `;

        const uniforms = {
            uTime: { value: 0.0 },
            uSpeed: { value: SETTINGS.speed },
            uLineDensity: { value: SETTINGS.lineDensity },
            uCurveSoftness: { value: SETTINGS.curveSoftness }, 
            uColor1: { value: new THREE.Color(SETTINGS.color1) },
            uColor2: { value: new THREE.Color(SETTINGS.color2) },
            uColor3: { value: new THREE.Color(SETTINGS.color3) },
            uColor4: { value: new THREE.Color(SETTINGS.color4) },
            uBgColor: { value: new THREE.Color(SETTINGS.bgColor) },
            uDataTexture: { value: dataTexture }
        };

        const material = new THREE.ShaderMaterial({
            vertexShader: wallVertexShader,
            fragmentShader: wallFragmentShader,
            uniforms: uniforms,
            side: THREE.BackSide,
            transparent: false
        });

        const geometry = new THREE.CylinderGeometry(100, 100, 80, 128, 1, true);
        const wall = new THREE.Mesh(geometry, material);
        tunnelGroup.add(wall);

        // --- White Data Particles ---
        const particleCount = 2000;
        const particleGeometry = new THREE.BufferGeometry();
        const particlePositions = new Float32Array(particleCount * 3);
        const particleSpeeds = new Float32Array(particleCount);

        for(let i=0; i<particleCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const radius = 98.5 + Math.random() * 1.0; 
            const y = -11.0 + Math.random() * 48.0; 
            
            particlePositions[i*3] = Math.cos(angle) * radius; 
            particlePositions[i*3+1] = y; 
            particlePositions[i*3+2] = Math.sin(angle) * radius; 
            particleSpeeds[i] = 0.5 + Math.random() * 2.0; 
        }

        particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
        particleGeometry.setAttribute('aSpeed', new THREE.BufferAttribute(particleSpeeds, 1));

        const particleUniforms = {
            uTime: { value: 0 },
            uSpeed: { value: SETTINGS.speed },
            uCurveSoftness: { value: SETTINGS.curveSoftness },
            uParticleSize: { value: SETTINGS.particleSize }
        };

        const particleMaterial = new THREE.ShaderMaterial({
            uniforms: particleUniforms,
            vertexShader: `
                uniform float uTime;
                uniform float uSpeed;
                uniform float uCurveSoftness;
                uniform float uParticleSize;
                attribute float aSpeed;
                varying float vAlpha;
                
                void main() {
                    vec3 pos = position;
                    
                    float angle = atan(pos.z, pos.x);
                    float radius = length(pos.xz);
                    float currentAngle = angle - uTime * uSpeed * 0.015 * aSpeed;
                    
                    float normX = cos(currentAngle);
                    float n = uCurveSoftness; 
                    float absZ = pow(max(0.00001, 1.0 - pow(abs(normX), n)), 1.0 / n) * radius;
                    
                    pos.x = cos(currentAngle) * radius;
                    pos.z = sign(sin(currentAngle)) * absZ; 
                    
                    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
                    gl_PointSize = (10.0 * uParticleSize / -mvPosition.z); 
                    gl_Position = projectionMatrix * mvPosition;
                    
                    vAlpha = smoothstep(38.0, 25.0, pos.y) * smoothstep(-12.0, -6.0, pos.y);
                }
            `,
            fragmentShader: `
                varying float vAlpha;

                void main() {
                    vec2 xy = gl_PointCoord.xy - vec2(0.5);
                    float ll = length(xy);
                    if (ll > 0.5) discard;
                    
                    float glow = 1.0 - (ll * 2.0);
                    
                    gl_FragColor = vec4(1.0, 1.0, 1.0, vAlpha * glow); 
                }
            `,
            transparent: true,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });

        const particles = new THREE.Points(particleGeometry, particleMaterial);
        tunnelGroup.add(particles);

        // Apply initial shape & scale parameters
        tunnelGroup.scale.set(SETTINGS.curveWidth, SETTINGS.height, SETTINGS.curveDepth);
        tunnelGroup.rotation.z = SETTINGS.wallTilt * Math.PI / 180; 

        // --- Post-Processing ---
        const composer = new EffectComposer(renderer);
        const renderPass = new RenderPass(scene, camera);
        composer.addPass(renderPass);

        // Peripheral Bokeh-style Blur Shader
        const PeripheralBlurShader = {
            uniforms: {
                tDiffuse: { value: null },
                uStrength: { value: SETTINGS.edgeBlurStrength },
                uAspect: { value: window.innerWidth / window.innerHeight }
            },
            vertexShader: `
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform sampler2D tDiffuse;
                uniform float uStrength;
                uniform float uAspect;
                varying vec2 vUv;

                void main() {
                    vec2 center = vec2(0.5, 0.5);
                    vec2 uvCorrection = vec2(uAspect, 1.0);
                    float dist = length((vUv - center) * uvCorrection);
                    
                    float blurMask = smoothstep(0.15, 0.7, dist);
                    
                    if (blurMask <= 0.0) {
                        gl_FragColor = texture2D(tDiffuse, vUv);
                        return;
                    }

                    const int SAMPLES = 32;
                    const float GOLDEN_ANGLE = 2.39996323;
                    vec4 color = vec4(0.0);
                    float radius = uStrength * blurMask;
                    
                    for (int i = 0; i < SAMPLES; i++) {
                        float r = sqrt(float(i) + 0.5) / sqrt(float(SAMPLES));
                        float theta = float(i) * GOLDEN_ANGLE;
                        vec2 offset = vec2(cos(theta), sin(theta)) * r * radius;
                        offset.x /= uAspect; 
                        color += texture2D(tDiffuse, vUv + offset);
                    }
                    gl_FragColor = color / float(SAMPLES);
                }
            `
        };
        const peripheralBlurPass = new ShaderPass(PeripheralBlurShader);
        composer.addPass(peripheralBlurPass);

        const ChromaticAberrationShader = {
            uniforms: {
                tDiffuse: { value: null },
                uAmount: { value: SETTINGS.chromaticAberration } 
            },
            vertexShader: `
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform sampler2D tDiffuse;
                uniform float uAmount;
                varying vec2 vUv;
                
                void main() {
                    vec2 offset = uAmount * (vec2(0.5) - vUv);
                    vec4 cr = texture2D(tDiffuse, vUv + offset);
                    vec4 cga = texture2D(tDiffuse, vUv);
                    vec4 cb = texture2D(tDiffuse, vUv - offset);
                    gl_FragColor = vec4(cr.r, cga.g, cb.b, cga.a);
                }
            `
        };
        const caPass = new ShaderPass(ChromaticAberrationShader);
        composer.addPass(caPass);

        const bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            SETTINGS.bloomStrength,  
            SETTINGS.bloomRadius,    
            0.1   
        );
        composer.addPass(bloomPass);

        // --- GUI Settings ---
        const gui = new GUI({ title: 'Scene Settings' });
        
        const fShape = gui.addFolder('Shape & Scale');
        fShape.add(SETTINGS, 'curveSoftness', 1.0, 10.0).name('Curve Softness').onChange(v => {
            uniforms.uCurveSoftness.value = v; 
            particleUniforms.uCurveSoftness.value = v; 
        });
        fShape.add(SETTINGS, 'curveWidth', 0.2, 5.0).name('Curve Width').onChange(v => {
            tunnelGroup.scale.x = v;
        });
        fShape.add(SETTINGS, 'curveDepth', 0.2, 5.0).name('Curve Depth').onChange(v => {
            tunnelGroup.scale.z = v;
        });
        fShape.add(SETTINGS, 'height', 0.2, 3.0).name('Wall Height').onChange(v => {
            tunnelGroup.scale.y = v;
        });
        fShape.add(SETTINGS, 'fov', 30, 140).name('Camera FOV').onChange(v => {
            camera.fov = v;
            camera.updateProjectionMatrix();
        });
        fShape.add(SETTINGS, 'wallTilt', -180, 180).name('Wall Tilt (deg)').onChange(v => {
            tunnelGroup.rotation.z = v * Math.PI / 180; 
        });
        fShape.add(SETTINGS, 'lineDensity', 0.1, 5.0).name('Line Density').onChange(v => {
            uniforms.uLineDensity.value = v;
        });
        fShape.add(SETTINGS, 'particleSize', 1.0, 20.0).name('Particle Size').onChange(v => {
            particleUniforms.uParticleSize.value = v;
        });
        
        const fMotion = gui.addFolder('Motion');
        fMotion.add(SETTINGS, 'speed', 0, 10).name('Stream Speed').onChange(v => {
            uniforms.uSpeed.value = v;
            particleUniforms.uSpeed.value = v;
        });
        
        const fEffects = gui.addFolder('Post-Processing');
        fEffects.add(SETTINGS, 'bloomStrength', 0, 5).name('Bloom Strength').onChange(v => bloomPass.strength = v);
        fEffects.add(SETTINGS, 'bloomRadius', 0, 2).name('Bloom Radius').onChange(v => bloomPass.radius = v);
        fEffects.add(SETTINGS, 'chromaticAberration', 0, 0.05).name('RGB Shift').onChange(v => caPass.uniforms.uAmount.value = v);
        fEffects.add(SETTINGS, 'dpr', 0.1, 4.0).step(0.1).name('DPR').onChange(v => {
            renderer.setPixelRatio(v);
            composer.setPixelRatio(v);
        });
        
        const fBlur = gui.addFolder('Screen Edge Blur');
        fBlur.add(SETTINGS, 'edgeBlurStrength', 0.0, 0.05).name('Blur Strength').onChange(v => peripheralBlurPass.uniforms.uStrength.value = v);
        
        const fCamera = gui.addFolder('Camera');
        fCamera.add(SETTINGS, 'cameraY', -10.0, 10.0).name('Vertical Pos');
        fCamera.add(SETTINGS, 'cameraSpinSpeed', -2.0, 2.0).name('Pan Speed');

        const fColors = gui.addFolder('Colors');
        const updateColors = () => {
            uniforms.uColor1.value.set(SETTINGS.color1);
            uniforms.uColor2.value.set(SETTINGS.color2);
            uniforms.uColor3.value.set(SETTINGS.color3);
            uniforms.uColor4.value.set(SETTINGS.color4);
            uniforms.uBgColor.value.set(SETTINGS.bgColor);
            scene.background.set(SETTINGS.bgColor);
            scene.fog.color.set(SETTINGS.bgColor);
        };
        fColors.addColor(SETTINGS, 'color1').name('Line Color 1').onChange(updateColors);
        fColors.addColor(SETTINGS, 'color2').name('Line Color 2').onChange(updateColors);
        fColors.addColor(SETTINGS, 'color3').name('Line Color 3').onChange(updateColors);
        fColors.addColor(SETTINGS, 'color4').name('Line Color 4').onChange(updateColors);
        fColors.addColor(SETTINGS, 'bgColor').name('Background Color').onChange(updateColors);

        gui.close();

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);

            const t = clock.getElapsedTime();
            
            uniforms.uTime.value = t;
            particleUniforms.uTime.value = t;

            camera.position.x = 0.0;
            camera.position.y = SETTINGS.cameraY;
            camera.position.z = 0.0;
            camera.rotation.y = (t * SETTINGS.cameraSpinSpeed); 
            
            composer.render();
        }

        animate();

        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
            peripheralBlurPass.uniforms.uAspect.value = window.innerWidth / window.innerHeight;
        });